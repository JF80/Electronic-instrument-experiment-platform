
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/CC');
require('./assets/Script/Label main');
require('./assets/Script/NewScript - 002');
require('./assets/Script/NewScript - 003');
require('./assets/Script/NewScript - 004');
require('./assets/Script/NewScript');
require('./assets/Script/huaxian - 001');
require('./assets/Script/huaxian');
require('./assets/Script/tip');
require('./assets/Script/tip2');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();