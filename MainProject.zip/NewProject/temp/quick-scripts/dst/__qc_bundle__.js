
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/__qc_index__.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}
require('./assets/Script/CC');
require('./assets/Script/Label main');
require('./assets/Script/NewScript - 002');
require('./assets/Script/NewScript - 003');
require('./assets/Script/NewScript - 004');
require('./assets/Script/NewScript');
require('./assets/Script/huaxian - 001');
require('./assets/Script/huaxian');
require('./assets/Script/tip');
require('./assets/Script/tip2');

                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript - 002.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'fe4deiXX7hKn7tXKCEaUMC0', 'NewScript - 002');
// Script/NewScript - 002.ts

"use strict";
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var _a = cc._decorator, ccclass = _a.ccclass, property = _a.property;
var NewClass = /** @class */ (function (_super) {
    __extends(NewClass, _super);
    function NewClass() {
        // LIFE-CYCLE CALLBACKS:
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // onLoad () {}
        _this.touches = [];
        _this.graphics = null;
        return _this;
        // update (dt) {}
    }
    NewClass.prototype.start = function () {
        var canvas = cc.find('Canvas');
        canvas.on(cc.Node.EventType.TOUCH_START, this.onTouchStart, this);
        canvas.on(cc.Node.EventType.TOUCH_MOVE, this.onTouchMove, this);
        canvas.on(cc.Node.EventType.TOUCH_END, this.onTouchEnd, this);
        this.graphics = this.getComponent(cc.Graphics);
        this.graphics.moveTo(0, 0);
        this.graphics.lineTo(0.1, 0);
        this.graphics.lineTo(-0.11, 0);
        this.graphics.stroke();
    };
    NewClass.prototype.onTouchStart = function (event) {
        this.touches.length = 0;
        this.touches.push(event.touch.getLocation());
    };
    NewClass.prototype.onTouchMove = function (event) {
        var touches = this.touches;
        touches.push(event.touch.getLocation());
        var MIN_POINT_DISTANCE = 2;
        this.graphics.clear();
        var worldPos = this.node.convertToWorldSpaceAR(cc.v2());
        this.graphics.moveTo(touches[0].x - worldPos.x, touches[0].y - worldPos.y);
        var lastIndex = 0;
        for (var i = 1, l = touches.length; i < l; i++) {
            if (touches[i].sub(touches[lastIndex]).mag() < MIN_POINT_DISTANCE) {
                continue;
            }
            lastIndex = i;
            this.graphics.lineTo(touches[i].x - worldPos.x, touches[i].y - worldPos.y);
        }
        this.graphics.stroke();
    };
    NewClass.prototype.onTouchEnd = function (event) {
    };
    NewClass = __decorate([
        ccclass
    ], NewClass);
    return NewClass;
}(cc.Component));
exports.default = NewClass;

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQgLSAwMDIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQU0sSUFBQSxLQUFzQixFQUFFLENBQUMsVUFBVSxFQUFsQyxPQUFPLGFBQUEsRUFBRSxRQUFRLGNBQWlCLENBQUM7QUFHMUM7SUFBc0MsNEJBQVk7SUFBbEQ7UUFDSSx3QkFBd0I7UUFENUIscUVBa0RDO1FBL0NHLGVBQWU7UUFFZixhQUFPLEdBQWMsRUFBRSxDQUFBO1FBQ3ZCLGNBQVEsR0FBZ0IsSUFBSSxDQUFDOztRQTJDN0IsaUJBQWlCO0lBQ3JCLENBQUM7SUExQ0csd0JBQUssR0FBTDtRQUNJLElBQUksTUFBTSxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDL0IsTUFBTSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNsRSxNQUFNLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsV0FBVyxFQUFFLElBQUksQ0FBQyxDQUFDO1FBQ2hFLE1BQU0sQ0FBQyxFQUFFLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLENBQUM7UUFFOUQsSUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxRQUFRLENBQUMsQ0FBQztRQUMvQyxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUM7UUFDM0IsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQzdCLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDO1FBQy9CLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUM7SUFDM0IsQ0FBQztJQUVELCtCQUFZLEdBQVosVUFBYyxLQUFLO1FBQ2YsSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFDO1FBQ3hCLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsV0FBVyxFQUFFLENBQUMsQ0FBQztJQUNqRCxDQUFDO0lBRUQsOEJBQVcsR0FBWCxVQUFhLEtBQUs7UUFDZCxJQUFJLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDO1FBQzNCLE9BQU8sQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQyxDQUFDO1FBRXhDLElBQU0sa0JBQWtCLEdBQUcsQ0FBQyxDQUFDO1FBRTdCLElBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUM7UUFDdEIsSUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztRQUN4RCxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7UUFDM0UsSUFBSSxTQUFTLEdBQUcsQ0FBQyxDQUFDO1FBQ2xCLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxPQUFPLENBQUMsTUFBTSxFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxFQUFFLEVBQUU7WUFDNUMsSUFBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxHQUFHLGtCQUFrQixFQUFFO2dCQUMvRCxTQUFTO2FBQ1o7WUFDRCxTQUFTLEdBQUcsQ0FBQyxDQUFDO1lBQ2QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxRQUFRLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQzlFO1FBQ0QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEVBQUUsQ0FBQztJQUMzQixDQUFDO0lBRUQsNkJBQVUsR0FBVixVQUFZLEtBQUs7SUFDakIsQ0FBQztJQS9DZ0IsUUFBUTtRQUQ1QixPQUFPO09BQ2EsUUFBUSxDQWtENUI7SUFBRCxlQUFDO0NBbERELEFBa0RDLENBbERxQyxFQUFFLENBQUMsU0FBUyxHQWtEakQ7a0JBbERvQixRQUFRIiwiZmlsZSI6IiIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiY29uc3Qge2NjY2xhc3MsIHByb3BlcnR5fSA9IGNjLl9kZWNvcmF0b3I7XHJcblxyXG5AY2NjbGFzc1xyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBOZXdDbGFzcyBleHRlbmRzIGNjLkNvbXBvbmVudCB7XHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge31cclxuXHJcbiAgICB0b3VjaGVzOiBjYy5WZWMyW10gPSBbXVxyXG4gICAgZ3JhcGhpY3M6IGNjLkdyYXBoaWNzID0gbnVsbDtcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcbiAgICAgICAgdmFyIGNhbnZhcyA9IGNjLmZpbmQoJ0NhbnZhcycpO1xyXG4gICAgICAgIGNhbnZhcy5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgdGhpcy5vblRvdWNoU3RhcnQsIHRoaXMpO1xyXG4gICAgICAgIGNhbnZhcy5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9NT1ZFLCB0aGlzLm9uVG91Y2hNb3ZlLCB0aGlzKTtcclxuICAgICAgICBjYW52YXMub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELCB0aGlzLm9uVG91Y2hFbmQsIHRoaXMpO1xyXG5cclxuICAgICAgICB0aGlzLmdyYXBoaWNzID0gdGhpcy5nZXRDb21wb25lbnQoY2MuR3JhcGhpY3MpO1xyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubW92ZVRvKDAsIDApO1xyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3MubGluZVRvKDAuMSwgMCk7XHJcbiAgICAgICAgdGhpcy5ncmFwaGljcy5saW5lVG8oLTAuMTEsIDApO1xyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3Muc3Ryb2tlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub3VjaFN0YXJ0IChldmVudCkge1xyXG4gICAgICAgIHRoaXMudG91Y2hlcy5sZW5ndGggPSAwO1xyXG4gICAgICAgIHRoaXMudG91Y2hlcy5wdXNoKGV2ZW50LnRvdWNoLmdldExvY2F0aW9uKCkpO1xyXG4gICAgfVxyXG5cclxuICAgIG9uVG91Y2hNb3ZlIChldmVudCkge1xyXG4gICAgICAgIGxldCB0b3VjaGVzID0gdGhpcy50b3VjaGVzO1xyXG4gICAgICAgIHRvdWNoZXMucHVzaChldmVudC50b3VjaC5nZXRMb2NhdGlvbigpKTtcclxuXHJcbiAgICAgICAgY29uc3QgTUlOX1BPSU5UX0RJU1RBTkNFID0gMjtcclxuXHJcbiAgICAgICAgdGhpcy5ncmFwaGljcy5jbGVhcigpO1xyXG4gICAgICAgIGxldCB3b3JsZFBvcyA9IHRoaXMubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoKSk7XHJcbiAgICAgICAgdGhpcy5ncmFwaGljcy5tb3ZlVG8odG91Y2hlc1swXS54IC0gd29ybGRQb3MueCwgdG91Y2hlc1swXS55IC0gd29ybGRQb3MueSk7XHJcbiAgICAgICAgbGV0IGxhc3RJbmRleCA9IDA7XHJcbiAgICAgICAgZm9yIChsZXQgaSA9IDEsIGwgPSB0b3VjaGVzLmxlbmd0aDsgaSA8IGw7IGkrKykge1xyXG4gICAgICAgICAgICBpZiAodG91Y2hlc1tpXS5zdWIodG91Y2hlc1tsYXN0SW5kZXhdKS5tYWcoKSA8IE1JTl9QT0lOVF9ESVNUQU5DRSkge1xyXG4gICAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgbGFzdEluZGV4ID0gaTtcclxuICAgICAgICAgICAgdGhpcy5ncmFwaGljcy5saW5lVG8odG91Y2hlc1tpXS54IC0gd29ybGRQb3MueCwgdG91Y2hlc1tpXS55IC0gd29ybGRQb3MueSk7XHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRoaXMuZ3JhcGhpY3Muc3Ryb2tlKCk7XHJcbiAgICB9XHJcblxyXG4gICAgb25Ub3VjaEVuZCAoZXZlbnQpIHtcclxuICAgIH1cclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fVxyXG59XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Label main.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '375d9gN9YZAZbZAwd7sVlSv', 'Label main');
// Script/Label main.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    playerred: {
      "default": null,
      type: cc.Node
    },
    playerblack: {
      "default": null,
      type: cc.Node
    },
    playerblack1: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    },
    player3: {
      "default": null,
      type: cc.Node
    },
    player4: {
      "default": null,
      type: cc.Node
    },
    player5: {
      "default": null,
      type: cc.AudioClip
    },
    player6: {
      "default": null,
      type: cc.Node
    },
    player7: {
      "default": null,
      type: cc.Node
    },
    tipp: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  time1: function time1() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '万用表关闭时选择关闭档或者电压最高档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;

    if (G.red == false) {
      console.log("s5sd");

      if (G.dangwei > 9 & G.dangwei < 15) {
        console.log("sadd545sd");
        var pu1 = cc.v2(629, 302);
        var pu2 = cc.v2(G.hongbi);
        var redtox = Math.abs(pu2.x - pu1.x);
        var redtoy = Math.abs(pu2.y - pu1.y);
        console.log("saddasd");
        console.log(pu2);

        if (redtox <= 50 & redtoy <= 50) {
          G.rtr = 1;
        }

        ;
        var py1 = cc.v2(629, 320);
        var py2 = cc.v2(G.heibi);
        var redtpx = Math.abs(py2.x - py1.x);
        var redtpy = Math.abs(py2.y - py1.y);
        console.log("saddasd");

        if (redtpx <= 50 & redtpy <= 50) {
          G.btr = 1;
        }

        ;
        var ps1 = cc.v2(858, 379);
        var ps2 = cc.v2(G.hongbi);
        var redtqx = Math.abs(ps2.x - ps1.x);
        var redtqy = Math.abs(ps2.y - ps1.y);
        console.log("saddasd");

        if (redtqx <= 50 & redtqy <= 50) {
          G.rtb = 1;
        }

        ;
        var pl1 = cc.v2(858, 379);
        var pl2 = cc.v2(G.heibi);
        var redtc = Math.abs(pl2.x - pl1.x);
        var redtg = Math.abs(pl2.y - pl1.y);
        console.log("saddasd");

        if (redtc <= 50 & redtg <= 50) {
          G.btb = 1;
        }

        ;
        console.log(G.rtr);
        console.log(G.btb);

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '数字式万用表的红表笔接正极';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请调至电阻档';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '当前量程档位错误';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将红表笔调至电阻位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前红表笔档位错误';
    }
  },
  time2: function time2() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电流时要和负载串联\n万用表只能测量微小电流';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("99d");

    if (G.dangwei > 2 & G.dangwei < 7) {
      var pu1 = cc.v2(733, 301);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(733, 301);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(762, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 13 & redtpy <= 13) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(762, 303);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 13 & redtqy <= 13) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '25.30mA';
        } else if (G.rtb == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-25.30mA';
        }
      } else if (G.rtr == 1 & G.btb == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '0.025A';
      } else if (G.rtb == 1 & G.btr == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '-0.025A';
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请接触黑红表笔';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '数字式万用表的红表笔接正极';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将调至直流电流档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前量程档位错误';
    }
  },
  time3: function time3() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("85475");

    if (G.dangwei > 16 & G.dangwei < 20) {
      console.log("sadd545sd");
      var pu1 = cc.v2(826, 303);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 30 & redtoy <= 30) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(826, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(766, 261);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(766, 261);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 30 & redtqy <= 30) {
        G.rtr = 1;
      }

      ;
      console.log("55");

      if (G.red == false) {
        console.log("sa55555");

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '6.15V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-6.15V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '将黑红表笔放置到加亮的标记处';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔调至电压位', this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei > 12) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '超量程', this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '低电压档测高电压可能会损坏万用表';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至直流电压位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量电压时使用错误档位会损坏万用表';
    }
  },
  time4: function time4() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '警告：使用万用表测量较高电压时\n必须使用交流档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    G.rtg = 0;
    G.btg = 0;

    if (G.dangwei > 0 & G.dangwei < 2) {
      console.log("sadd545sd");
      var pu1 = cc.v2(740, 345);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtg = 1;
      }

      ;
      var py1 = cc.v2(740, 345);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btg = 1;
      }

      ;
      var py1 = cc.v2(724, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var ps1 = cc.v2(724, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(759, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(759, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.btb == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btg == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.rtg == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '0V';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔接至交流电压位';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei == 2) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '当前量程太小';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '必须使用交流档位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量高电压时使用错误档位会造成危险!\n当前万用表已自动断路';
    }
  },
  time5: function time5() {
    if (G.dangwei == 9) {
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '将红黑表笔短接以测量通路';
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '准备自检';
      console.log("sadd545sd");
      var pu1 = cc.v2(G.hongbi);
      var pu2 = cc.v2(G.heibi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log(G.hongbi);
      console.log(G.heibi);

      if (redtox <= 10 & redtoy <= 10) {
        this.current = cc.audioEngine.play(this.player5, false, 1);
        ;
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '通过';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '仅验证为通路';
      }

      ;
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至自检档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '错误档位红黑表笔短接可能会算坏万用表';
    }
  },
  onLoad: function onLoad() {
    G.dangwei == 0;
    console.log("sad5sd");
    var p = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
    var w = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    this.playerred.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.playerblack.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerred.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pccp");
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;
      var del = t.getDelta();
      this.playerred.x += del.x;
      this.playerred.y += del.y;
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerblack.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pc2cp");
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      var del = t.getDelta();
      this.playerblack.x += del.x;
      this.playerblack.y += del.y;
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player4.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p2ccp");
      this.player7.rotation -= 18;
      G.dangwei -= 1;

      if (G.dangwei == -1) {
        G.dangwei = 19;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    console.log("scccd");
    this.player6.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("pcc5p");
      this.player7.rotation += 18;
      G.dangwei += 1;

      if (G.dangwei == 20) {
        G.dangwei = 0;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxMYWJlbCBtYWluLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwicGxheWVycmVkIiwidHlwZSIsIk5vZGUiLCJwbGF5ZXJibGFjayIsInBsYXllcmJsYWNrMSIsInBsYXllcjIiLCJwbGF5ZXIzIiwicGxheWVyNCIsInBsYXllcjUiLCJBdWRpb0NsaXAiLCJwbGF5ZXI2IiwicGxheWVyNyIsInRpcHAiLCJ0aW1lMSIsIm15TGFiZWwiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIkciLCJidHIiLCJidGIiLCJydHIiLCJydGIiLCJyZWQiLCJjb25zb2xlIiwibG9nIiwiZGFuZ3dlaSIsInB1MSIsInYyIiwicHUyIiwiaG9uZ2JpIiwicmVkdG94IiwiTWF0aCIsImFicyIsIngiLCJyZWR0b3kiLCJ5IiwicHkxIiwicHkyIiwiaGVpYmkiLCJyZWR0cHgiLCJyZWR0cHkiLCJwczEiLCJwczIiLCJyZWR0cXgiLCJyZWR0cXkiLCJwbDEiLCJwbDIiLCJyZWR0YyIsInJlZHRnIiwibm9kZSIsInRpbWUyIiwidGltZTMiLCJ0aW1lNCIsInJ0ZyIsImJ0ZyIsInRpbWU1IiwiY3VycmVudCIsImF1ZGlvRW5naW5lIiwicGxheSIsIm9uTG9hZCIsInAiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJwcCIsInciLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwidCIsInhpYW5nbXUiLCJUT1VDSF9NT1ZFIiwiZGVsIiwiZ2V0RGVsdGEiLCJUT1VDSF9FTkQiLCJyb3RhdGlvbiIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTkMsSUFBQUEsU0FBUyxFQUFFO0FBQ0QsaUJBQVMsSUFEUjtBQUVEQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGUixLQWhCRztBQW9CZEMsSUFBQUEsV0FBVyxFQUFFO0FBQ0gsaUJBQVMsSUFETjtBQUVIRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTixLQXBCQztBQXdCZEUsSUFBQUEsWUFBWSxFQUFFO0FBQ0osaUJBQVMsSUFETDtBQUVKSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTCxLQXhCQTtBQTRCZEcsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQTVCSztBQWdDZEksSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWhDSztBQW9DZEssSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDTixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQXBDSztBQXdDZE0sSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ2E7QUFGVixLQXhDSztBQTRDZEMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDVCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQTVDSztBQWlEZFMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDVixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWpESztBQXNEZFUsSUFBQUEsSUFBSSxFQUFFO0FBQ0ksaUJBQVMsSUFEYjtBQUVJWCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGYjtBQXREUSxHQUhQO0FBaUVMO0FBR0hXLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUtDLE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hCLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixvQkFBdEI7QUFDRkMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNBRCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjs7QUFFRSxRQUFHSixDQUFDLENBQUNLLEdBQUYsSUFBUyxLQUFaLEVBQWtCO0FBQ2pCQyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaOztBQUNELFVBQUdQLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBZVIsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsRUFBNUIsRUFBZ0M7QUFFaENGLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVo7QUFDRCxZQUFJRSxHQUFHLEdBQUcvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVHLFlBQUlDLEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFFSixZQUFJQyxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNLLENBQUosR0FBTVAsR0FBRyxDQUFDTyxDQUFuQixDQUFiO0FBQ0MsWUFBSUMsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDTyxDQUFKLEdBQU1ULEdBQUcsQ0FBQ1MsQ0FBbkIsQ0FBYjtBQUNDWixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0FELFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxHQUFaOztBQUVBLFlBQUlFLE1BQU0sSUFBSSxFQUFWLEdBQWVJLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFDakIsVUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQVEsQ0FBUjtBQUFXOztBQUFBO0FBQzVDLFlBQUlnQixHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVFLFlBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUosWUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNBLFlBQUtPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWQ7QUFFRVosUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixZQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBQ3ZCLFVBQUFBLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVI7QUFBVzs7QUFBQTtBQUU1QyxZQUFJdUIsR0FBRyxHQUFHOUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDRyxZQUFJZSxHQUFHLEdBQUUvQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBQ0gsWUFBSWMsTUFBTSxHQUFHWixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDVCxDQUFKLEdBQU1RLEdBQUcsQ0FBQ1IsQ0FBbkIsQ0FBYjtBQUNDLFlBQUlXLE1BQU0sR0FBR2IsSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1AsQ0FBSixHQUFNTSxHQUFHLENBQUNOLENBQW5CLENBQWI7QUFDQ1osUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFQSxZQUFJbUIsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUMzQixVQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBUSxDQUFSO0FBQVc7O0FBQUE7QUFFOUMsWUFBSXdCLEdBQUcsR0FBR2xELEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csWUFBSW1CLEdBQUcsR0FBRW5ELEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBQ0gsWUFBSVMsS0FBSyxHQUFHaEIsSUFBSSxDQUFDQyxHQUFMLENBQVNjLEdBQUcsQ0FBQ2IsQ0FBSixHQUFNWSxHQUFHLENBQUNaLENBQW5CLENBQVo7QUFDQyxZQUFJZSxLQUFLLEdBQUdqQixJQUFJLENBQUNDLEdBQUwsQ0FBU2MsR0FBRyxDQUFDWCxDQUFKLEdBQU1VLEdBQUcsQ0FBQ1YsQ0FBbkIsQ0FBWjtBQUNDWixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVBLFlBQUl1QixLQUFLLElBQUksRUFBVCxHQUFjQyxLQUFLLElBQUcsRUFBMUIsRUFBOEI7QUFBQy9CLFVBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFRLENBQVI7QUFBVzs7QUFBQTtBQUU1Q0ksUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLENBQUMsQ0FBQ0csR0FBZDtBQUNDRyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVAsQ0FBQyxDQUFDRSxHQUFkOztBQUNBLFlBQUlGLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixRQUF0QjtBQUFnQyxTQURqQyxNQUN1QyxJQUFJQyxDQUFDLENBQUNDLEdBQUYsSUFBTyxDQUFQLEdBQVdELENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQXRCLEVBQXdCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUMvRCxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBZ0MsU0FETSxNQUNGO0FBQUMsZUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNyQyxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsU0FBdEI7QUFBZ0MsZUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDaEMsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGVBQXRCO0FBQXVDO0FBQUMsT0E5Q3hDLE1BZ0RBO0FBQUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixRQUF0QjtBQUErQixhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUMvQixhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsVUFBdEI7QUFBa0M7QUFBQyxLQXBEbkMsTUFxREk7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ04sV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFlBQXRCO0FBQW1DLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixXQUF0QjtBQUFtQztBQUVsQyxHQXBJTTtBQXNJVGtDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUtyQyxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNmLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQiwwQkFBdEI7QUFDREMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNERCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjtBQUNFRSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaOztBQUNBLFFBQUdQLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBZVIsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsQ0FBNUIsRUFBK0I7QUFHaEMsVUFBSUMsR0FBRyxHQUFHL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRyxVQUFJQyxHQUFHLEdBQUVqQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBRUosVUFBSUMsTUFBTSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDSyxDQUFKLEdBQU1QLEdBQUcsQ0FBQ08sQ0FBbkIsQ0FBYjtBQUNDLFVBQUlDLE1BQU0sR0FBR0gsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ08sQ0FBSixHQUFNVCxHQUFHLENBQUNTLENBQW5CLENBQWI7QUFDQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjtBQUNBRCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUksR0FBWjs7QUFFQSxVQUFJRSxNQUFNLElBQUksRUFBVixHQUFlSSxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRWpCLFFBQUFBLENBQUMsQ0FBQ0ksR0FBRixHQUFPLENBQVA7QUFBUzs7QUFBQTtBQUMzQyxVQUFJZSxHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVFLFVBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUosVUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNDLFVBQUlPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWI7QUFFQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixVQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRXZCLFFBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFPLENBQVA7QUFBUzs7QUFBQTtBQUMxQyxVQUFJaUIsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDQyxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVGLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQyxVQUFJTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFiO0FBRUNaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNDLEdBQUYsR0FBTyxDQUFQO0FBQVM7O0FBQUE7QUFDM0MsVUFBSXVCLEdBQUcsR0FBRzlDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csVUFBSWUsR0FBRyxHQUFFL0MsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUNILFVBQUljLE1BQU0sR0FBR1osSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1QsQ0FBSixHQUFNUSxHQUFHLENBQUNSLENBQW5CLENBQWI7QUFDQyxVQUFJVyxNQUFNLEdBQUdiLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNQLENBQUosR0FBTU0sR0FBRyxDQUFDTixDQUFuQixDQUFiO0FBQ0NaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUEsVUFBSW1CLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFM0IsUUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQU8sQ0FBUDtBQUFTOztBQUFBOztBQUk1QyxVQUFJSCxDQUFDLENBQUNLLEdBQUYsSUFBUSxLQUFaLEVBQWtCO0FBQ2xCLFlBQUlMLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFpQyxTQURsQyxNQUVNLElBQUdDLENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQVAsR0FBV0osQ0FBQyxDQUFDQyxHQUFGLElBQU8sQ0FBckIsRUFBdUI7QUFBQyxlQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzlCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQztBQUFDLE9BSmxDLE1BTUEsSUFBSUMsQ0FBQyxDQUFDRyxHQUFGLElBQU8sQ0FBUCxHQUFXSCxDQUFDLENBQUNFLEdBQUYsSUFBTyxDQUF0QixFQUF3QjtBQUFDLGFBQUtOLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDekIsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQStCLE9BRC9CLE1BQ29DLElBQUdDLENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQVAsR0FBV0osQ0FBQyxDQUFDQyxHQUFGLElBQU8sQ0FBckIsRUFBdUI7QUFBQyxhQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzVELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFnQyxPQURJLE1BQ0U7QUFBQyxhQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3RDLGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFnQyxhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNqQyxhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsZUFBdEI7QUFBc0M7QUFBQyxLQXBEdEMsTUFxREc7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0wsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFdBQXRCO0FBQWtDLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQztBQUUvQixHQXRNTTtBQXlNVG1DLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUt0QyxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNoQixTQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IscUJBQXRCO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsR0FBRixHQUFNLENBQU47QUFDREQsSUFBQUEsQ0FBQyxDQUFDRSxHQUFGLEdBQU0sQ0FBTjtBQUNBRixJQUFBQSxDQUFDLENBQUNHLEdBQUYsR0FBTSxDQUFOO0FBQ0FILElBQUFBLENBQUMsQ0FBQ0ksR0FBRixHQUFNLENBQU47QUFDQUUsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjs7QUFDRSxRQUFHUCxDQUFDLENBQUNRLE9BQUYsR0FBVyxFQUFYLEdBQWdCUixDQUFDLENBQUNRLE9BQUYsR0FBVSxFQUE3QixFQUFpQztBQUVqQ0YsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWjtBQUNELFVBQUlFLEdBQUcsR0FBRy9CLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBRUcsVUFBSUMsR0FBRyxHQUFFakMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ0ssQ0FBSixHQUFNUCxHQUFHLENBQUNPLENBQW5CLENBQWI7QUFDQyxVQUFJQyxNQUFNLEdBQUdILElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNPLENBQUosR0FBTVQsR0FBRyxDQUFDUyxDQUFuQixDQUFiO0FBQ0NaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7QUFDQUQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlJLEdBQVo7O0FBRUEsVUFBSUUsTUFBTSxJQUFJLEVBQVYsR0FBY0ksTUFBTSxJQUFHLEVBQTNCLEVBQStCO0FBQUVqQixRQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBTSxDQUFOO0FBQVE7O0FBQUE7QUFDekMsVUFBSWUsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRSxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQyxVQUFJTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFiO0FBRUNaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFJLEVBQTdCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQVE7O0FBQUE7QUFDekMsVUFBSWlCLEdBQUcsR0FBR3pDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0MsVUFBSVUsR0FBRyxHQUFFMUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNxQixLQUFSLENBQVQ7QUFFRixVQUFJQyxNQUFNLEdBQUdSLElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNKLENBQUosR0FBTUcsR0FBRyxDQUFDSCxDQUFuQixDQUFiO0FBQ0MsVUFBSU8sTUFBTSxHQUFHVCxJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDRixDQUFKLEdBQU1DLEdBQUcsQ0FBQ0QsQ0FBbkIsQ0FBYjtBQUVDWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVGLFVBQUllLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFdkIsUUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUFROztBQUFBO0FBQzFDLFVBQUl1QixHQUFHLEdBQUc5QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUNHLFVBQUllLEdBQUcsR0FBRS9DLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFDSCxVQUFJYyxNQUFNLEdBQUdaLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNULENBQUosR0FBTVEsR0FBRyxDQUFDUixDQUFuQixDQUFiO0FBQ0MsVUFBSVcsTUFBTSxHQUFHYixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDUCxDQUFKLEdBQU1NLEdBQUcsQ0FBQ04sQ0FBbkIsQ0FBYjtBQUNDWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVBLFVBQUltQixNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRTNCLFFBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFBUTs7QUFBQTtBQUV6Q0csTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjs7QUFDRixVQUFJUCxDQUFDLENBQUNLLEdBQUYsSUFBTyxLQUFYLEVBQWlCO0FBQUVDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBQ25CLFlBQUlQLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixPQUF0QjtBQUErQixTQURoQyxNQUNxQyxJQUFHQyxDQUFDLENBQUNDLEdBQUYsSUFBTyxDQUFQLEdBQVdELENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQXJCLEVBQXVCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUM1RCxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBK0IsU0FESyxNQUNBO0FBQUMsZUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNyQyxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsU0FBdEI7QUFBZ0MsZUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDakMsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGdCQUF0QjtBQUF1QztBQUFDLE9BTHhDLE1BT0E7QUFBQyxhQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0EsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFlBQXRCLEVBQW1DLEtBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFsRDtBQUNELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixxQkFBdEI7QUFBNEM7QUFBRSxLQWxEN0MsTUFtREksSUFBR0MsQ0FBQyxDQUFDUSxPQUFGLEdBQVcsRUFBZCxFQUFpQjtBQUFDLFdBQUtaLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDdkIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLEtBQXRCLEVBQTRCLEtBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUEzQztBQUNBLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixrQkFBdEI7QUFBMEMsS0FGckMsTUFFMkM7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xELFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQyxXQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNoQyxXQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsbUJBQXRCO0FBQTJDO0FBRXpDLEdBelFNO0FBNFFUb0MsRUFBQUEsS0FBSyxFQUFDLGlCQUFVO0FBQUMsU0FBS3ZDLE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hCLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQiwwQkFBdEI7QUFDQUMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNERCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjtBQUFRSixJQUFBQSxDQUFDLENBQUNvQyxHQUFGLEdBQU0sQ0FBTjtBQUFRcEMsSUFBQUEsQ0FBQyxDQUFDcUMsR0FBRixHQUFNLENBQU47O0FBQ2QsUUFBR3JDLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBY1IsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsQ0FBM0IsRUFBNkI7QUFFN0JGLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVo7QUFDRCxVQUFJRSxHQUFHLEdBQUcvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVHLFVBQUlDLEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFFSixVQUFJQyxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNLLENBQUosR0FBTVAsR0FBRyxDQUFDTyxDQUFuQixDQUFiO0FBQ0EsVUFBS0MsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDTyxDQUFKLEdBQU1ULEdBQUcsQ0FBQ1MsQ0FBbkIsQ0FBZDtBQUNFWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0FELE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxHQUFaOztBQUVBLFVBQUlFLE1BQU0sSUFBSSxFQUFWLEdBQWNJLE1BQU0sSUFBRyxFQUEzQixFQUErQjtBQUFFakIsUUFBQUEsQ0FBQyxDQUFDb0MsR0FBRixHQUFNLENBQU47QUFBUTs7QUFBQTtBQUN6QyxVQUFJakIsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRSxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQSxVQUFLTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFkO0FBRUVaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNxQyxHQUFGLEdBQU0sQ0FBTjtBQUFROztBQUFBO0FBQ3pDLFVBQUlsQixHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUNDLFVBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUYsVUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNBLFVBQUtPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWQ7QUFFRVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixVQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBQ3ZCLFFBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFNLENBQU47QUFBUzs7QUFBQTtBQUMxQyxVQUFJc0IsR0FBRyxHQUFHOUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDRyxVQUFJZSxHQUFHLEdBQUUvQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBQ0gsVUFBSWMsTUFBTSxHQUFHWixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDVCxDQUFKLEdBQU1RLEdBQUcsQ0FBQ1IsQ0FBbkIsQ0FBYjtBQUNBLFVBQUtXLE1BQU0sR0FBR2IsSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1AsQ0FBSixHQUFNTSxHQUFHLENBQUNOLENBQW5CLENBQWQ7QUFDRVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFQSxVQUFJbUIsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUUzQixRQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBTSxDQUFOO0FBQVM7O0FBQUE7QUFDNUMsVUFBSWUsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDQyxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVGLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQSxVQUFLTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFkO0FBRUVaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNDLEdBQUYsR0FBTyxDQUFQO0FBQVM7O0FBQUE7QUFDM0MsVUFBSXVCLEdBQUcsR0FBRzlDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csVUFBSWUsR0FBRyxHQUFFL0MsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUNILFVBQUljLE1BQU0sR0FBR1osSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1QsQ0FBSixHQUFNUSxHQUFHLENBQUNSLENBQW5CLENBQWI7QUFDQSxVQUFLVyxNQUFNLEdBQUdiLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNQLENBQUosR0FBTU0sR0FBRyxDQUFDTixDQUFuQixDQUFkO0FBQ0VaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUEsVUFBSW1CLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFM0IsUUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQU8sQ0FBUDtBQUFTOztBQUFBOztBQUU1QyxVQUFJSCxDQUFDLENBQUNLLEdBQUYsSUFBUSxLQUFaLEVBQWtCO0FBQ2xCLFlBQUlMLENBQUMsQ0FBQ0UsR0FBRixJQUFTLENBQVQsR0FBYUYsQ0FBQyxDQUFDRyxHQUFGLElBQVEsQ0FBekIsRUFBNEI7QUFBQyxlQUFLUCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzVCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFrQyxTQURuQyxNQUN3QyxJQUFJQyxDQUFDLENBQUNDLEdBQUYsSUFBUyxDQUFULEdBQWFELENBQUMsQ0FBQ0ksR0FBRixJQUFRLENBQXpCLEVBQTRCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNwRSxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsVUFBdEI7QUFBa0MsU0FESyxNQUNBLElBQUlDLENBQUMsQ0FBQ3FDLEdBQUYsSUFBUyxDQUFULEdBQWFyQyxDQUFDLENBQUNHLEdBQUYsSUFBUSxDQUF6QixFQUE0QjtBQUFDLGVBQUtQLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDcEUsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFVBQXRCO0FBQWtDLFNBREssTUFDQSxJQUFJQyxDQUFDLENBQUNvQyxHQUFGLElBQVMsQ0FBVCxHQUFhcEMsQ0FBQyxDQUFDQyxHQUFGLElBQVEsQ0FBekIsRUFBNEI7QUFBQyxlQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3BFLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFrQyxTQURLLE1BQ0Q7QUFBQyxlQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3ZDLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixJQUF0QjtBQUEyQjtBQUFFLE9BTjlCLE1BTWtDO0FBQUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNwQyxhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsY0FBdEI7QUFBcUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDcEMsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLHFCQUF0QjtBQUE2QztBQUFDLEtBaEU3QyxNQWlFSSxJQUFHQyxDQUFDLENBQUNRLE9BQUYsSUFBYSxDQUFoQixFQUFtQjtBQUFDLFdBQUtaLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDeEIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQ0MsS0FGRyxNQUdMO0FBQUMsV0FBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNBLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQyxXQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNsQyxXQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsZ0NBQXRCO0FBQXdEO0FBSXRELEdBNVZNO0FBOFZUdUMsRUFBQUEsS0FBSyxFQUFDLGlCQUFVO0FBQ2hCLFFBQUd0QyxDQUFDLENBQUNRLE9BQUYsSUFBWSxDQUFmLEVBQWtCO0FBQUMsV0FBS1osT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDbEIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGNBQXRCO0FBQ0MsV0FBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNELFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixNQUF0QjtBQUNDTyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaO0FBQ0QsVUFBSUUsR0FBRyxHQUFHL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVjtBQUVFLFVBQUlELEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUgsVUFBSVIsTUFBTSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDSyxDQUFKLEdBQU1QLEdBQUcsQ0FBQ08sQ0FBbkIsQ0FBYjtBQUNDLFVBQUlDLE1BQU0sR0FBR0gsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ08sQ0FBSixHQUFNVCxHQUFHLENBQUNTLENBQW5CLENBQWI7QUFDQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLENBQUMsQ0FBQ1ksTUFBZDtBQUNBTixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVAsQ0FBQyxDQUFDcUIsS0FBZDs7QUFFQSxVQUFJUixNQUFNLElBQUksRUFBVixHQUFlSSxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFDbEMsYUFBS3NCLE9BQUwsR0FBZTdELEVBQUUsQ0FBQzhELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLbkQsT0FBekIsRUFBa0MsS0FBbEMsRUFBeUMsQ0FBekMsQ0FBZjtBQUNBO0FBQUMsYUFBS00sT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNDLGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixJQUF0QjtBQUEyQixhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUM1QixhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBZ0M7O0FBQUE7QUFFaEMsS0FwQkQsTUFzQks7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0osV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQStCLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixvQkFBdEI7QUFBNEM7QUFDNUMsR0F4WFE7QUEyWFIyQyxFQUFBQSxNQUFNLEVBQUMsa0JBQVU7QUFBQzFDLElBQUFBLENBQUMsQ0FBQ1EsT0FBRixJQUFhLENBQWI7QUFDakJGLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDQSxRQUFJb0MsQ0FBQyxHQUFFLEtBQUs3RCxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBQ0MsUUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLElBQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLElBQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLElBQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUNELFFBQUlHLENBQUMsR0FBRSxLQUFLN0QsV0FBTCxDQUFpQjJELHFCQUFqQixDQUF1Q2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUF2QyxDQUFQO0FBRUNvQyxJQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsSUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUO0FBQ0YsU0FBS2hFLFNBQUwsQ0FBZWlFLEVBQWYsQ0FBa0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JDLFdBQXBDLEVBQWlELFVBQVNDLENBQVQsRUFBVztBQUFDLFVBQUlsRCxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ2pHLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSWxDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2hCLEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUR4RyxFQUN5RyxJQUR6RztBQUdBLFNBQUtyRCxXQUFMLENBQWlCOEQsRUFBakIsQ0FBb0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JDLFdBQXRDLEVBQW1ELFVBQVNDLENBQVQsRUFBVztBQUFDLFVBQUlsRCxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ25HLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBRnBFLEVBRXFFLElBRnJFO0FBSUFoQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsU0FBS3pCLFNBQUwsQ0FBZWlFLEVBQWYsQ0FBa0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JJLFVBQXBDLEVBQStDLFVBQVNGLENBQVQsRUFBVztBQUFDNUMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUczRCxVQUFJdUMsQ0FBQyxHQUFFLEtBQUtoRSxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBRUVvQyxNQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsTUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUO0FBRUEsVUFBSU8sR0FBRyxHQUFHSCxDQUFDLENBQUNJLFFBQUYsRUFBVjtBQUNBLFdBQUt4RSxTQUFMLENBQWVrQyxDQUFmLElBQW9CcUMsR0FBRyxDQUFDckMsQ0FBeEI7QUFDQSxXQUFLbEMsU0FBTCxDQUFlb0MsQ0FBZixJQUFvQm1DLEdBQUcsQ0FBQ25DLENBQXhCO0FBTUYsVUFBSXlCLENBQUMsR0FBRSxLQUFLMUQsV0FBTCxDQUFpQjJELHFCQUFqQixDQUF1Q2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUF2QyxDQUFQO0FBQ0UsVUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLE1BQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLE1BQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLE1BQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUNGOztBQUFDLFVBQUkzQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ3JDLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBeEJwRSxFQXdCcUUsSUF4QnJFO0FBeUJBaEMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVBLFNBQUt0QixXQUFMLENBQWlCOEQsRUFBakIsQ0FBb0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JJLFVBQXRDLEVBQWlELFVBQVNGLENBQVQsRUFBVztBQUFDNUMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUFxQixVQUFJb0MsQ0FBQyxHQUFFLEtBQUsxRCxXQUFMLENBQWlCMkQscUJBQWpCLENBQXVDbEUsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQXZDLENBQVA7QUFDaEYsVUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLE1BQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLE1BQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLE1BQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUVBLFVBQUlVLEdBQUcsR0FBR0gsQ0FBQyxDQUFDSSxRQUFGLEVBQVY7QUFDQSxXQUFLckUsV0FBTCxDQUFpQitCLENBQWpCLElBQXNCcUMsR0FBRyxDQUFDckMsQ0FBMUI7QUFDQSxXQUFLL0IsV0FBTCxDQUFpQmlDLENBQWpCLElBQXNCbUMsR0FBRyxDQUFDbkMsQ0FBMUI7QUFDQSxVQUFJNEIsQ0FBQyxHQUFFLEtBQUtoRSxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBRUFvQyxNQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsTUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUOztBQUNGLFVBQUk5QyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ3BDLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBaEJwRSxFQWdCcUUsSUFoQnJFO0FBaUJBLFNBQUtuRCxPQUFMLENBQWE0RCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCQyxXQUFsQyxFQUE4QyxVQUFTQyxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQzFELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtuRCxPQUFMLENBQWE0RCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQ3hELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtsRCxPQUFMLENBQWEyRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCQyxXQUFsQyxFQUE4QyxVQUFTQyxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQzFELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtsRCxPQUFMLENBQWEyRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQ3hELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFFcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUxoQyxFQUtpQyxJQUxqQztBQU1BLFNBQUtqRCxPQUFMLENBQWEwRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFBcUIsV0FBS2QsT0FBTCxDQUFhK0QsUUFBYixJQUF5QixFQUF6QjtBQUMzRXhELE1BQUFBLENBQUMsQ0FBQ1EsT0FBRixJQUFZLENBQVo7O0FBQ0EsVUFBR1IsQ0FBQyxDQUFDUSxPQUFGLElBQWEsQ0FBQyxDQUFqQixFQUFtQjtBQUFDUixRQUFBQSxDQUFDLENBQUNRLE9BQUYsR0FBVSxFQUFWO0FBQWM7O0FBQUE7O0FBQ3BDLFVBQUlSLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQU5oQyxFQU1pQyxJQU5qQztBQU9BaEMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsU0FBS2YsT0FBTCxDQUFhdUQsRUFBYixDQUFnQnJFLEVBQUUsQ0FBQ00sSUFBSCxDQUFRZ0UsU0FBUixDQUFrQk8sU0FBbEMsRUFBNEMsVUFBU0wsQ0FBVCxFQUFXO0FBQUM1QyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQXNCLFdBQUtkLE9BQUwsQ0FBYStELFFBQWIsSUFBeUIsRUFBekI7QUFDNUV4RCxNQUFBQSxDQUFDLENBQUNRLE9BQUYsSUFBWSxDQUFaOztBQUNBLFVBQUdSLENBQUMsQ0FBQ1EsT0FBRixJQUFhLEVBQWhCLEVBQW1CO0FBQUNSLFFBQUFBLENBQUMsQ0FBQ1EsT0FBRixHQUFVLENBQVY7QUFBYTs7QUFBQTs7QUFDbkMsVUFBSVIsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLeEQsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUlLLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2xCLEtBQUw7QUFBYSxPQUEvQixNQUNwQyxJQUFJakMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLakIsS0FBTDtBQUFhLE9BQS9CLE1BQ0EsSUFBSWxDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2hCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBTmhDLEVBTWlDLElBTmpDO0FBUUMsR0FsZU87QUFtZUxtQixFQUFBQSxLQW5lSyxtQkFtZUksQ0FFUixDQXJlSSxDQXVlTDs7QUF2ZUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxyXG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIGJhcjoge1xyXG4gICAgICAgIC8vICAgICBnZXQgKCkge1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuIHRoaXMuX2JhcjtcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fYmFyID0gdmFsdWU7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9LFxyXG5cdFx0cGxheWVycmVkOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyYmxhY2s6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXJibGFjazE6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXI1OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXI2OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuXHRcdFx0XHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjc6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG5cdFx0XHRcclxuICAgICAgICB9LFxyXG5cdFx0dGlwcDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcblx0XHRcdFxyXG4gICAgICAgIH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgXHJcbiB0aW1lMTpmdW5jdGlvbigpe3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+S4h+eUqOihqOWFs+mXreaXtumAieaLqeWFs+mXreaho+aIluiAheeUteWOi+acgOmrmOahoyc7XHJcbkcuYnRyPTA7XHJcbkcuYnRiPTA7XHJcbkcucnRyPTA7XHJcbkcucnRiPTA7XHJcblx0IFxyXG5cdCBpZihHLnJlZCA9PSBmYWxzZSl7XHJcblx0ICBjb25zb2xlLmxvZyhcInM1c2RcIik7XHJcblx0IGlmKEcuZGFuZ3dlaSA+OSAmIEcuZGFuZ3dlaTwxNSApe1xyXG5cdFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGQ1NDVzZFwiKTtcclxuXHR2YXIgcHUxID0gY2MudjIoNjI5LDMwMik7XHJcblx0ICBcclxuXHQgICB2YXIgcHUyID1jYy52MihHLmhvbmdiaSk7XHJcblx0ICAgXHJcbnZhciByZWR0b3ggPSBNYXRoLmFicyhwdTIueC1wdTEueCk7IFxyXG4gdmFyIHJlZHRveSA9KE1hdGguYWJzKHB1Mi55LXB1MS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgY29uc29sZS5sb2cocHUyKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gNTAgJiByZWR0b3kgPD01MCApe0cucnRyID0gMTt9O1xyXG5cdCB2YXIgcHkxID0gY2MudjIoNjI5LDMyMCk7XHJcblx0ICBcclxuXHQgICB2YXIgcHkyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRweCA9IE1hdGguYWJzKHB5Mi54LXB5MS54KTsgXHJcbnZhciAgcmVkdHB5ID0oTWF0aC5hYnMocHkyLnktcHkxLnkpKTtcclxuXHQgXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgXHJcbmlmIChyZWR0cHggPD0gNTAgJiByZWR0cHkgPD01MCApe0cuYnRyID0gMTt9O1xyXG5cclxudmFyIHBzMSA9IGNjLnYyKDg1OCwzNzkpO1xyXG5cdCAgdmFyIHBzMiA9Y2MudjIoRy5ob25nYmkpO1xyXG52YXIgcmVkdHF4ID0gTWF0aC5hYnMocHMyLngtcHMxLngpOyBcclxuIHZhciByZWR0cXkgPShNYXRoLmFicyhwczIueS1wczEueSkpO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblxyXG5cdCBpZiAocmVkdHF4IDw9IDUwICYgcmVkdHF5IDw9NTAgKXtHLnJ0YiA9IDE7fTtcclxuXHJcbnZhciBwbDEgPSBjYy52Mig4NTgsMzc5KTtcclxuXHQgIHZhciBwbDIgPWNjLnYyKEcuaGVpYmkpO1xyXG52YXIgcmVkdGMgPSBNYXRoLmFicyhwbDIueC1wbDEueCk7IFxyXG4gdmFyIHJlZHRnID0oTWF0aC5hYnMocGwyLnktcGwxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdFxyXG5cdCBpZiAocmVkdGMgPD0gNTAgJiByZWR0ZyA8PTUwICl7Ry5idGIgPSAxO307XHJcblxyXG5jb25zb2xlLmxvZyhHLnJ0cik7XHJcbiBjb25zb2xlLmxvZyhHLmJ0Yik7XHJcbiBpZiAoRy5ydHI9PTEgJiBHLmJ0Yj09MSl7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAnNTAuMDDOqSc7fSBlbHNlIGlmIChHLmJ0cj09MSAmIEcucnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICc1MC4wMM6pJzt9ZWxzZXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+aVsOWtl+W8j+S4h+eUqOihqOeahOe6ouihqOeslOaOpeato+aegSc7fX1cclxuIGVsc2VcclxuXHQge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+iwg+iHs+eUtemYu+ahoyc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJzt9fVxyXG5cdCBlbHNle3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7flsIbnuqLooajnrJTosIPoh7PnlLXpmLvkvY0nO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+W9k+WJjee6ouihqOeslOaho+S9jemUmeivryc7fVxyXG5cdCBcclxuXHQgfSxcclxuXHQgXHJcbnRpbWUyOmZ1bmN0aW9uKCl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5rWL6YeP55S15rWB5pe26KaB5ZKM6LSf6L295Liy6IGUXFxu5LiH55So6KGo5Y+q6IO95rWL6YeP5b6u5bCP55S15rWBJztcclxuXHRHLmJ0cj0wO1xyXG5HLmJ0Yj0wO1xyXG5HLnJ0cj0wO1xyXG5HLnJ0Yj0wO1xyXG5cdCBjb25zb2xlLmxvZyhcIjk5ZFwiKTtcclxuXHQgaWYoRy5kYW5nd2VpID4yICYgRy5kYW5nd2VpPDcgKXtcclxuXHRcdFxyXG5cdCBcclxuXHR2YXIgcHUxID0gY2MudjIoNzMzLDMwMSk7XHJcblx0ICBcclxuXHQgICB2YXIgcHUyID1jYy52MihHLmhvbmdiaSk7XHJcblx0ICAgXHJcbnZhciByZWR0b3ggPSBNYXRoLmFicyhwdTIueC1wdTEueCk7IFxyXG4gdmFyIHJlZHRveSA9KE1hdGguYWJzKHB1Mi55LXB1MS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgY29uc29sZS5sb2cocHUyKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gMTAgJiByZWR0b3kgPD0xMCApeyBHLnJ0YiA9MX07XHJcblx0IHZhciBweTEgPSBjYy52Mig3MzMsMzAxKTtcclxuXHQgIFxyXG5cdCAgIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxuIHZhciByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7IEcuYnRiID0xfTtcclxuIHZhciBweTEgPSBjYy52Mig3NjIsMzAzKTtcclxuICB2YXIgcHkyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRweCA9IE1hdGguYWJzKHB5Mi54LXB5MS54KTsgXHJcbiB2YXIgcmVkdHB5ID0oTWF0aC5hYnMocHkyLnktcHkxLnkpKTtcclxuXHQgXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgXHJcbmlmIChyZWR0cHggPD0gMTMgJiByZWR0cHkgPD0xMyApeyBHLmJ0ciA9MX07XHJcbnZhciBwczEgPSBjYy52Mig3NjIsMzAzKTtcclxuXHQgIHZhciBwczIgPWNjLnYyKEcuaG9uZ2JpKTtcclxudmFyIHJlZHRxeCA9IE1hdGguYWJzKHBzMi54LXBzMS54KTsgXHJcbiB2YXIgcmVkdHF5ID0oTWF0aC5hYnMocHMyLnktcHMxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cclxuXHQgaWYgKHJlZHRxeCA8PSAxMyAmIHJlZHRxeSA8PTEzICl7IEcucnRyID0xfTtcclxuXHJcblxyXG5cclxuXHRpZiAoRy5yZWQgPT1mYWxzZSl7XHJcblx0aWYgKEcucnRyPT0xICYgRy5idGI9PTEpe3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJzI1LjMwbUEnO31cclxuXHQgZWxzZSBpZihHLnJ0Yj09MSAmIEcuYnRyPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJy0yNS4zMG1BJ319IFxyXG4gZWxzZVxyXG5cdGlmIChHLnJ0cj09MSAmIEcuYnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJzAuMDI1QSd9ZWxzZSBpZihHLnJ0Yj09MSAmIEcuYnRyPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJy0wLjAyNUEnfSBlbHNlIHt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5pWw5a2X5byP5LiH55So6KGo55qE57qi6KGo56yU5o6l5q2j5p6BJ319IFxyXG5cdGVsc2V7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7flsIbosIPoh7Pnm7TmtYHnlLXmtYHmoaMnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJ31cclxuXHRcclxuXHQgfSxcclxuXHQgXHRcclxuXHRcdFxyXG50aW1lMzpmdW5jdGlvbigpe3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5rWL6YeP55S15Y6L5pe257qi6KGo56yU6YCJ5oup55S15rWB5qGj5Lya5o2f5Z2P5LiH55So6KGoJztcclxuXHRHLmJ0cj0wO1xyXG5HLmJ0Yj0wO1xyXG5HLnJ0cj0wO1xyXG5HLnJ0Yj0wO1xyXG5jb25zb2xlLmxvZyhcIjg1NDc1XCIpO1xyXG5cdCBpZihHLmRhbmd3ZWkgPjE2ICYgRy5kYW5nd2VpPDIwICl7XHJcblx0XHRcclxuXHQgY29uc29sZS5sb2coXCJzYWRkNTQ1c2RcIik7XHJcblx0dmFyIHB1MSA9IGNjLnYyKDgyNiwzMDMpO1xyXG5cdCAgXHJcblx0ICAgdmFyIHB1MiA9Y2MudjIoRy5ob25nYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdG94ID0gTWF0aC5hYnMocHUyLngtcHUxLngpOyBcclxuIHZhciByZWR0b3kgPShNYXRoLmFicyhwdTIueS1wdTEueSkpO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IGNvbnNvbGUubG9nKHB1Mik7XHJcblx0IFxyXG5cdCBpZiAocmVkdG94IDw9IDMwJiByZWR0b3kgPD0zMCApeyBHLnJ0Yj0xfTtcclxuXHQgdmFyIHB5MSA9IGNjLnYyKDgyNiwzMDMpO1xyXG5cdCAgXHJcblx0ICAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG4gdmFyIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDMwICYgcmVkdHB5IDw9IDMwKXsgRy5idGI9MX07XHJcbiB2YXIgcHkxID0gY2MudjIoNzY2LDI2MSk7XHJcbiAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG4gdmFyIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDMwICYgcmVkdHB5IDw9MzAgKXsgRy5idHI9MX07XHJcbnZhciBwczEgPSBjYy52Mig3NjYsMjYxKTtcclxuXHQgIHZhciBwczIgPWNjLnYyKEcuaG9uZ2JpKTtcclxudmFyIHJlZHRxeCA9IE1hdGguYWJzKHBzMi54LXBzMS54KTsgXHJcbiB2YXIgcmVkdHF5ID0oTWF0aC5hYnMocHMyLnktcHMxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cclxuXHQgaWYgKHJlZHRxeCA8PSAzMCAmIHJlZHRxeSA8PTMwICl7IEcucnRyPTF9O1xyXG5cclxuICAgY29uc29sZS5sb2coXCI1NVwiKTtcclxuXHRpZiAoRy5yZWQ9PWZhbHNlKXsgY29uc29sZS5sb2coXCJzYTU1NTU1XCIpO1xyXG5cdGlmIChHLnJ0cj09MSAmIEcuYnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICc2LjE1Vic7fWVsc2UgaWYoRy5idHI9PTEgJiBHLnJ0Yj09MSl7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAnLTYuMTVWJ31lbHNlIHt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5bCG6buR57qi6KGo56yU5pS+572u5Yiw5Yqg5Lqu55qE5qCH6K6w5aSEJ319XHJcbiBlbHNlXHJcblx0e3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+Wwhue6ouihqOeslOiwg+iHs+eUteWOi+S9jScsdGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bnuqLooajnrJTpgInmi6nnlLXmtYHmoaPkvJrmjZ/lnY/kuIfnlKjooagnfSB9XHJcbiBlbHNlIGlmKEcuZGFuZ3dlaSA+MTIpe3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gdGhpcy5teUxhYmVsLnN0cmluZyA9ICfotoXph4/nqIsnLHRoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5L2O55S15Y6L5qGj5rWL6auY55S15Y6L5Y+v6IO95Lya5o2f5Z2P5LiH55So6KGoJzt9IGVsc2Uge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG50aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+iwg+iHs+ebtOa1geeUteWOi+S9jSc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bkvb/nlKjplJnor6/moaPkvY3kvJrmjZ/lnY/kuIfnlKjooagnO31cclxuXHRcclxuXHQgfSxcclxuXHQgICBcclxuXHQgXHJcbnRpbWU0OmZ1bmN0aW9uKCl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICforablkYrvvJrkvb/nlKjkuIfnlKjooajmtYvph4/ovoPpq5jnlLXljovml7ZcXG7lv4Xpobvkvb/nlKjkuqTmtYHmoaMnO1xyXG5cdEcuYnRyPTA7XHJcbkcuYnRiPTA7XHJcbkcucnRyPTA7XHJcbkcucnRiPTA7Ry5ydGc9MDtHLmJ0Zz0wO1xyXG5cdCBpZihHLmRhbmd3ZWkgPjAmIEcuZGFuZ3dlaTwyKXtcclxuXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZDU0NXNkXCIpO1xyXG5cdHZhciBwdTEgPSBjYy52Mig3NDAsMzQ1KTtcclxuXHQgIFxyXG5cdCAgIHZhciBwdTIgPWNjLnYyKEcuaG9uZ2JpKTtcclxuXHQgICBcclxudmFyIHJlZHRveCA9IE1hdGguYWJzKHB1Mi54LXB1MS54KTsgXHJcbnZhciAgcmVkdG95ID0oTWF0aC5hYnMocHUyLnktcHUxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBjb25zb2xlLmxvZyhwdTIpO1xyXG5cdCBcclxuXHQgaWYgKHJlZHRveCA8PSAxMCYgcmVkdG95IDw9MTAgKXsgRy5ydGc9MX07XHJcblx0IHZhciBweTEgPSBjYy52Mig3NDAsMzQ1KTtcclxuXHQgIFxyXG5cdCAgIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxudmFyICByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7IEcuYnRnPTF9O1xyXG4gdmFyIHB5MSA9IGNjLnYyKDcyNCwzMTkpO1xyXG4gIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxudmFyICByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7Ry5idGI9MTt9O1xyXG52YXIgcHMxID0gY2MudjIoNzI0LDMxOSk7XHJcblx0ICB2YXIgcHMyID1jYy52MihHLmhvbmdiaSk7XHJcbnZhciByZWR0cXggPSBNYXRoLmFicyhwczIueC1wczEueCk7IFxyXG52YXIgIHJlZHRxeSA9KE1hdGguYWJzKHBzMi55LXBzMS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHJcblx0IGlmIChyZWR0cXggPD0gMTAgJiByZWR0cXkgPD0xMCApeyBHLnJ0Yj0xO307XHJcbiB2YXIgcHkxID0gY2MudjIoNzU5LDMxOSk7XHJcbiAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG52YXIgIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDEwICYgcmVkdHB5IDw9MTAgKXsgRy5idHIgPTF9O1xyXG52YXIgcHMxID0gY2MudjIoNzU5LDMxOSk7XHJcblx0ICB2YXIgcHMyID1jYy52MihHLmhvbmdiaSk7XHJcbnZhciByZWR0cXggPSBNYXRoLmFicyhwczIueC1wczEueCk7IFxyXG52YXIgIHJlZHRxeSA9KE1hdGguYWJzKHBzMi55LXBzMS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHJcblx0IGlmIChyZWR0cXggPD0gMTAgJiByZWR0cXkgPD0xMCApeyBHLnJ0ciA9MX07XHJcblxyXG5cdGlmIChHLnJlZCA9PWZhbHNlKXtcclxuXHRpZiAoRy5idGIgPT0gMSAmIEcucnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5idHIgPT0gMSAmIEcucnRiID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5idGcgPT0gMSAmIEcucnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5ydGcgPT0gMSAmIEcuYnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICcwVid9IH1lbHNle3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG50aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+Wwhue6ouihqOeslOaOpeiHs+S6pOa1geeUteWOi+S9jSc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bnuqLooajnrJTpgInmi6nnlLXmtYHmoaPkvJrmjZ/lnY/kuIfnlKjooagnO319XHJcbiBlbHNlIGlmKEcuZGFuZ3dlaSA9PSAyKSB7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5aSq5bCPJztcclxuXHQgfWVsc2VcclxuXHR7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b+F6aG75L2/55So5Lqk5rWB5qGj5L2NJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+a1i+mHj+mrmOeUteWOi+aXtuS9v+eUqOmUmeivr+aho+S9jeS8mumAoOaIkOWNsemZqSFcXG7lvZPliY3kuIfnlKjooajlt7Loh6rliqjmlq3ot68nO30gXHJcblx0IFxyXG4gXHJcblx0XHJcblx0IH0sXHJcblxyXG50aW1lNTpmdW5jdGlvbigpe1xyXG5pZihHLmRhbmd3ZWkgPT05ICl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICflsIbnuqLpu5HooajnrJTnn63mjqXku6XmtYvph4/pgJrot68nO1xyXG5cdFx0dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICflh4blpIfoh6rmo4AnO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGQ1NDVzZFwiKTtcclxuXHR2YXIgcHUxID0gY2MudjIoRy5ob25nYmkpO1xyXG5cdCAgXHJcblx0ICB2YXIgcHUyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRveCA9IE1hdGguYWJzKHB1Mi54LXB1MS54KTsgXHJcbiB2YXIgcmVkdG95ID0oTWF0aC5hYnMocHUyLnktcHUxLnkpKTtcclxuXHQgY29uc29sZS5sb2coRy5ob25nYmkpO1xyXG5cdCBjb25zb2xlLmxvZyhHLmhlaWJpKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gMTAgJiByZWR0b3kgPD0xMCApe1xyXG50aGlzLmN1cnJlbnQgPSBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMucGxheWVyNSwgZmFsc2UsIDEpO1xyXG47dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn6YCa6L+HJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+S7hemqjOivgeS4uumAmui3ryc7fTtcclxuXHRcclxufVxyXG5cclxuZWxzZSB7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn6K+36LCD6Iez6Ieq5qOA5qGjJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+mUmeivr+aho+S9jee6oum7keihqOeslOefreaOpeWPr+iDveS8mueul+Wdj+S4h+eUqOihqCc7fVxyXG59LFxyXG5cclxuIFxyXG4gb25Mb2FkOmZ1bmN0aW9uKCl7Ry5kYW5nd2VpID09IDA7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkNXNkXCIpO1xyXG5cdCB2YXIgcCA9dGhpcy5wbGF5ZXJyZWQuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0dmFyIHBwID0gY2MudjIoNDUuNCwtNDUuNSk7XHJcblx0XHQgICAgcC54ICs9IHBwLng7XHJcblx0XHRcdHAueSArPSBwcC55O1xyXG5cdFx0XHRcclxuXHRcdFx0Ry5oZWliaT0gY2MudjIocCk7XHJcblx0XHR2YXIgdyA9dGhpcy5wbGF5ZXJibGFjay5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHRcclxuXHRcdFx0dy55ID0gdy55KzY1LjI3O1xyXG5cdFx0XHRHLmhvbmdiaT13O1x0XHJcblx0dGhpcy5wbGF5ZXJyZWQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uKHQpe2lmIChHLnhpYW5nbXU9PTEpe3RoaXMudGltZTEoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTIpe3RoaXMudGltZTIoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09Myl7dGhpcy50aW1lMygpfWVsc2UgaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0XHJcblx0dGhpcy5wbGF5ZXJibGFjay5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgZnVuY3Rpb24odCl7aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuXHRpZiAoRy54aWFuZ211PT00KXt0aGlzLnRpbWU0KCl9ZWxzZSBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHRcclxuXHRjb25zb2xlLmxvZyhcInNjY2NkXCIpO1xyXG5cdHRoaXMucGxheWVycmVkLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwY2NwXCIpO1xyXG5cdFxyXG5cdFxyXG5cdHZhciB3ID10aGlzLnBsYXllcnJlZC5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHRcclxuXHRcdFx0dy55ID0gdy55KzY1LjI3O1xyXG5cdFx0XHRHLmhvbmdiaT13O1xyXG5cdFx0XHRcclxuXHRcdFx0dmFyIGRlbCA9IHQuZ2V0RGVsdGEoKTtcclxuXHRcdFx0dGhpcy5wbGF5ZXJyZWQueCArPSBkZWwueDtcclxuXHRcdFx0dGhpcy5wbGF5ZXJyZWQueSArPSBkZWwueTtcclxuXHRcclxuXHRcclxuXHRcclxuXHRcclxuXHRcclxuIHZhciBwID10aGlzLnBsYXllcmJsYWNrLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLCAwKSk7XHJcblx0XHRcdHZhciBwcCA9IGNjLnYyKDQ1LjQsLTQ1LjUpO1xyXG5cdFx0ICAgIHAueCArPSBwcC54O1xyXG5cdFx0XHRwLnkgKz0gcHAueTtcclxuXHRcdFx0XHJcblx0XHRcdEcuaGVpYmk9IGNjLnYyKHApO1xyXG5cdDtpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG5cdGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTUpe3RoaXMudGltZTUoKX19LHRoaXMpO1xyXG5cdGNvbnNvbGUubG9nKFwic2NjY2RcIik7XHJcblx0XHJcbiB0aGlzLnBsYXllcmJsYWNrLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwYzJjcFwiKTt2YXIgcCA9dGhpcy5wbGF5ZXJibGFjay5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHR2YXIgcHAgPSBjYy52Mig0NS40LC00NS41KTtcclxuXHRcdCAgICBwLnggKz0gcHAueDtcclxuXHRcdFx0cC55ICs9IHBwLnk7XHJcblx0XHRcdFxyXG5cdFx0XHRHLmhlaWJpPSBjYy52MihwKTtcclxuXHRcdCAgXHJcblx0XHRcdHZhciBkZWwgPSB0LmdldERlbHRhKCk7XHJcblx0XHRcdHRoaXMucGxheWVyYmxhY2sueCArPSBkZWwueDtcclxuXHRcdFx0dGhpcy5wbGF5ZXJibGFjay55ICs9IGRlbC55O1xyXG5cdFx0XHR2YXIgdyA9dGhpcy5wbGF5ZXJyZWQuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0dGhpcy5wbGF5ZXIyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDVjY3BcIik7XHJcblx0aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcbiB0aGlzLnBsYXllcjIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDVjY3BcIik7ICBcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHR0aGlzLnBsYXllcjMub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwM2NjcFwiKTtcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuIHRoaXMucGxheWVyMy5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwM2NjcFwiKTtcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuXHRcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHR0aGlzLnBsYXllcjQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDJjY3BcIik7dGhpcy5wbGF5ZXI3LnJvdGF0aW9uIC09IDE4O1xyXG5cdCAgRy5kYW5nd2VpIC09MTtcclxuXHQgIGlmKEcuZGFuZ3dlaSA9PSAtMSl7Ry5kYW5nd2VpPTE5O307XHJcblx0aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0Y29uc29sZS5sb2coXCJzY2NjZFwiKTtcclxuXHRcclxuXHRjb25zb2xlLmxvZyhcInNjY2NkXCIpO1xyXG4gdGhpcy5wbGF5ZXI2Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCxmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcInBjYzVwXCIpOyB0aGlzLnBsYXllcjcucm90YXRpb24gKz0gMTg7XHJcblx0ICBHLmRhbmd3ZWkgKz0xO1xyXG5cdCAgaWYoRy5kYW5nd2VpID09IDIwKXtHLmRhbmd3ZWk9MDt9O1xyXG5cdGlmIChHLnhpYW5nbXU9PTEpe3RoaXMudGltZTEoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTIpe3RoaXMudGltZTIoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09Myl7dGhpcy50aW1lMygpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT00KXt0aGlzLnRpbWU0KCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTUpe3RoaXMudGltZTUoKX19LHRoaXMpO1xyXG4gXHJcblx0fSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHRcdFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript - 003.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '335b8Zf3VZEo6BPG9iAFSw5', 'NewScript - 003');
// Script/NewScript - 003.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    }
  },
  ontm: function ontm(t) {
    var p = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
    var del = t.getDelta();
    this.node.x += del.x;
    this.node.y += del.y;
  },
  ontm2: function ontm2(t) {
    var p = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.node.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("1");
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.ontm, this);
    this.player.on(cc.Node.EventType.TOUCH_MOVE, this.ontm2, this);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQgLSAwMDMuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiTm9kZSIsIm9udG0iLCJ0IiwicCIsIm5vZGUiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJ2MiIsInBwIiwieCIsInkiLCJHIiwiaGVpYmkiLCJkZWwiLCJnZXREZWx0YSIsIm9udG0yIiwib25Mb2FkIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImNvbnNvbGUiLCJsb2ciLCJUT1VDSF9NT1ZFIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNOQyxJQUFBQSxNQUFNLEVBQUU7QUFDRSxpQkFBUyxJQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZYO0FBaEJNLEdBSFA7QUF5QlRDLEVBQUFBLElBQUksRUFBQyxjQUFTQyxDQUFULEVBQVc7QUFDYixRQUFJQyxDQUFDLEdBQUUsS0FBS0MsSUFBTCxDQUFVQyxxQkFBVixDQUFnQ1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBaEMsQ0FBUDtBQUNBLFFBQUlDLEVBQUUsR0FBR2IsRUFBRSxDQUFDWSxFQUFILENBQU0sSUFBTixFQUFXLENBQUMsSUFBWixDQUFUO0FBQ0dILElBQUFBLENBQUMsQ0FBQ0ssQ0FBRixJQUFPRCxFQUFFLENBQUNDLENBQVY7QUFDSEwsSUFBQUEsQ0FBQyxDQUFDTSxDQUFGLElBQU9GLEVBQUUsQ0FBQ0UsQ0FBVjtBQUVBQyxJQUFBQSxDQUFDLENBQUNDLEtBQUYsR0FBU2pCLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNSCxDQUFOLENBQVQ7QUFFQSxRQUFJUyxHQUFHLEdBQUdWLENBQUMsQ0FBQ1csUUFBRixFQUFWO0FBQ0EsU0FBS1QsSUFBTCxDQUFVSSxDQUFWLElBQWVJLEdBQUcsQ0FBQ0osQ0FBbkI7QUFDQSxTQUFLSixJQUFMLENBQVVLLENBQVYsSUFBZUcsR0FBRyxDQUFDSCxDQUFuQjtBQUNBLEdBcENNO0FBcUNUSyxFQUFBQSxLQUFLLEVBQUMsZUFBU1osQ0FBVCxFQUFXO0FBQ2QsUUFBSUMsQ0FBQyxHQUFFLEtBQUtDLElBQUwsQ0FBVUMscUJBQVYsQ0FBZ0NYLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQWhDLENBQVA7QUFDQSxRQUFJQyxFQUFFLEdBQUdiLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLElBQU4sRUFBVyxDQUFDLElBQVosQ0FBVDtBQUNHSCxJQUFBQSxDQUFDLENBQUNLLENBQUYsSUFBT0QsRUFBRSxDQUFDQyxDQUFWO0FBQ0hMLElBQUFBLENBQUMsQ0FBQ00sQ0FBRixJQUFPRixFQUFFLENBQUNFLENBQVY7QUFFQUMsSUFBQUEsQ0FBQyxDQUFDQyxLQUFGLEdBQVNqQixFQUFFLENBQUNZLEVBQUgsQ0FBTUgsQ0FBTixDQUFUO0FBR0EsR0E5Q007QUErQ0w7QUFDSFksRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2xCLFNBQUtYLElBQUwsQ0FBVVksRUFBVixDQUFhdEIsRUFBRSxDQUFDTSxJQUFILENBQVFpQixTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxVQUFTaEIsQ0FBVCxFQUFXO0FBQUNpQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxHQUFaO0FBQWtCLEtBQTFFLEVBQTJFLElBQTNFO0FBQ0EsU0FBS2hCLElBQUwsQ0FBVVksRUFBVixDQUFhdEIsRUFBRSxDQUFDTSxJQUFILENBQVFpQixTQUFSLENBQWtCSSxVQUEvQixFQUEyQyxLQUFLcEIsSUFBaEQsRUFBcUQsSUFBckQ7QUFDQSxTQUFLSCxNQUFMLENBQVlrQixFQUFaLENBQWV0QixFQUFFLENBQUNNLElBQUgsQ0FBUWlCLFNBQVIsQ0FBa0JJLFVBQWpDLEVBQTZDLEtBQUtQLEtBQWxELEVBQXdELElBQXhEO0FBRUssR0FyREk7QUFzREw7QUFFQVEsRUFBQUEsS0F4REssbUJBd0RJLENBRVIsQ0ExREksQ0E0REw7O0FBNURLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuXHRcdHBsYXllcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdFxyXG4gICAgfSxcclxub250bTpmdW5jdGlvbih0KXtcclxuXHRcdCB2YXIgcCA9dGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLCAwKSk7XHJcblx0XHRcdHZhciBwcCA9IGNjLnYyKDQ1LjQsLTQ1LjUpO1xyXG5cdFx0ICAgIHAueCArPSBwcC54O1xyXG5cdFx0XHRwLnkgKz0gcHAueTtcclxuXHRcdFx0XHJcblx0XHRcdEcuaGVpYmk9IGNjLnYyKHApO1xyXG5cdFx0ICBcclxuXHRcdFx0dmFyIGRlbCA9IHQuZ2V0RGVsdGEoKTtcclxuXHRcdFx0dGhpcy5ub2RlLnggKz0gZGVsLng7XHJcblx0XHRcdHRoaXMubm9kZS55ICs9IGRlbC55O1xyXG5cdFx0fSxcclxub250bTI6ZnVuY3Rpb24odCl7XHJcblx0XHQgdmFyIHAgPXRoaXMubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHR2YXIgcHAgPSBjYy52Mig0NS40LC00NS41KTtcclxuXHRcdCAgICBwLnggKz0gcHAueDtcclxuXHRcdFx0cC55ICs9IHBwLnk7XHJcblx0XHRcdFxyXG5cdFx0XHRHLmhlaWJpPSBjYy52MihwKTtcclxuXHRcdCAgXHJcblx0XHRcdFxyXG5cdFx0fSxcdFxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcbiBvbkxvYWQ6ZnVuY3Rpb24oKXtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcIjFcIik7fSx0aGlzKTtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub250bSx0aGlzKTtcclxudGhpcy5wbGF5ZXIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vbnRtMix0aGlzKTtcclxuXHJcbiAgICB9LFxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/tip.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'daf93JwsK5KwLD8srSWa0z7', 'tip');
// Script/tip.js

"use strict";

var _properties;

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Global = require("tip2");

cc.Class({
  "extends": cc.Component,
  Global: Global,
  properties: (_properties = {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties),
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  start: function start() {
    var tipObj = new Global();
    this.myLabel = this.node.getComponent(cc.Label);
    this.myLabel.string = G.xianshi;
    tipObj.ts();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFx0aXAuanMiXSwibmFtZXMiOlsiR2xvYmFsIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwicGxheWVyIiwidHlwZSIsIk5vZGUiLCJwbGF5ZXIyIiwib25Mb2FkIiwic3RhcnQiLCJ0aXBPYmoiLCJteUxhYmVsIiwibm9kZSIsImdldENvbXBvbmVudCIsIkxhYmVsIiwic3RyaW5nIiwiRyIsInhpYW5zaGkiLCJ0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlBLE1BQU0sR0FBRUMsT0FBTyxDQUFDLE1BQUQsQ0FBbkI7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBQ2lCSixFQUFBQSxNQUFNLEVBQU5BLE1BRGpCO0FBR0xLLEVBQUFBLFVBQVU7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDTEMsSUFBQUEsTUFBTSxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWpCRztBQXFCWkMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVjtBQXJCRyw4QkF5Qkg7QUFDQyxlQUFTLElBRFY7QUFFQ0QsSUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlYsR0F6QkcsMkJBNkJIO0FBQ0MsZUFBUyxJQURWO0FBRUNELElBQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZWLEdBN0JHLDJCQWlDSDtBQUNDLGVBQVMsSUFEVjtBQUVDRCxJQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixHQWpDRyxjQUhMO0FBMENMO0FBS0FFLEVBQUFBLE1BL0NLLG9CQStDSyxDQUVaLENBakRPO0FBb0RMQyxFQUFBQSxLQXBESyxtQkFvREk7QUFDYixRQUFJQyxNQUFNLEdBQUcsSUFBSVosTUFBSixFQUFiO0FBR0csU0FBS2EsT0FBTCxHQUFlLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmIsRUFBRSxDQUFDYyxLQUExQixDQUFmO0FBQ0YsU0FBS0gsT0FBTCxDQUFhSSxNQUFiLEdBQXNCQyxDQUFDLENBQUNDLE9BQXhCO0FBRURQLElBQUFBLE1BQU0sQ0FBQ1EsRUFBUDtBQUVLLEdBN0RJLENBK0RMOztBQS9ESyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIEdsb2JhbCA9cmVxdWlyZShcInRpcDJcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsR2xvYmFsLFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcblx0XHRcclxuICAgICAgICAvLyB9LFxyXG5cdCAgcGxheWVyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cclxuXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHRcclxuXHR9LFxyXG5cdFxyXG4gXHJcbiAgICBzdGFydCAoKSB7XHJcbmxldCB0aXBPYmogPSBuZXcgR2xvYmFsKCk7XHJcblxyXG5cclxuXHQgIHRoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSBHLnhpYW5zaGk7XHJcblx0XHJcbnRpcE9iai50cygpO1xyXG5cdFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/huaxian - 001.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '20d046SKC1Gn43MsFVxQimR', 'huaxian - 001');
// Script/huaxian - 001.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    mainCanvas: cc.Node,
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    },
    player3: {
      "default": null,
      type: cc.Node
    },
    player4: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
    this.player3.on(cc.Node.EventType.TOUCH_END, function (t) {
      this.fu1();
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      this.fu();
    }, this);
    this.player4.on(cc.Node.EventType.TOUCH_END, function (t) {
      this.fu2();
    }, this);
  },
  start: function start() {//console.log(tmpPath)
  },
  fu: function fu() {
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  },
  fu1: function fu1() {
    G.red = true;
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  },
  fu2: function fu2() {
    G.red = false;
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxodWF4aWFuIC0gMDAxLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibWFpbkNhbnZhcyIsIk5vZGUiLCJwbGF5ZXIiLCJ0eXBlIiwicGxheWVyMiIsInBsYXllcjMiLCJwbGF5ZXI0Iiwib25Mb2FkIiwibWFpbkNvbnRleHQiLCJnZXRDb21wb25lbnQiLCJHcmFwaGljcyIsImNvbnNvbGUiLCJsb2ciLCJhMnAiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJ2MiIsImIycCIsImEycHgiLCJ4IiwiYTJweSIsIkciLCJyZWQiLCJtb3ZlVG8iLCJiMnB4IiwiYjJweSIsInkiLCJsaW5lVG8iLCJzdHJva2UiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX0VORCIsInQiLCJmdTEiLCJUT1VDSF9NT1ZFIiwiZnUiLCJmdTIiLCJzdGFydCIsImNsZWFyIl0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUkMsSUFBQUEsVUFBVSxFQUFFSixFQUFFLENBQUNLLElBRFA7QUFFZEMsSUFBQUEsTUFBTSxFQUFFO0FBQ0UsaUJBQVMsSUFEWDtBQUVFQyxNQUFBQSxJQUFJLEVBQUVQLEVBQUUsQ0FBQ0s7QUFGWCxLQUZNO0FBTWRHLElBQUFBLE9BQU8sRUFBRTtBQUNDLGlCQUFTLElBRFY7QUFFQ0QsTUFBQUEsSUFBSSxFQUFFUCxFQUFFLENBQUNLO0FBRlYsS0FOSztBQVVkSSxJQUFBQSxPQUFPLEVBQUU7QUFDQyxpQkFBUyxJQURWO0FBRUNGLE1BQUFBLElBQUksRUFBRVAsRUFBRSxDQUFDSztBQUZWLEtBVks7QUFlZEssSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDSCxNQUFBQSxJQUFJLEVBQUVQLEVBQUUsQ0FBQ0s7QUFGVjtBQWZLLEdBSFA7QUF5Qkw7QUFFQU0sRUFBQUEsTUEzQkssb0JBMkJLO0FBRVosU0FBS0MsV0FBTCxHQUFtQixLQUFLUixVQUFMLENBQWdCUyxZQUFoQixDQUE2QmIsRUFBRSxDQUFDYyxRQUFoQyxDQUFuQjtBQUVBQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsUUFBSUMsR0FBRyxHQUFHLEtBQUtYLE1BQUwsQ0FBWVkscUJBQVosQ0FBa0NsQixFQUFFLENBQUNtQixFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbEMsQ0FBVjtBQUNBLFFBQUlDLEdBQUcsR0FBRyxLQUFLWixPQUFMLENBQWFVLHFCQUFiLENBQW1DbEIsRUFBRSxDQUFDbUIsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQW5DLENBQVY7QUFDQUosSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNHLFFBQUlLLElBQUksR0FBR0osR0FBRyxDQUFDSyxDQUFmO0FBQ0gsUUFBSUMsSUFBSSxHQUFHLEdBQVg7O0FBQ00sUUFBR0MsQ0FBQyxDQUFDQyxHQUFGLElBQVMsSUFBWixFQUFpQjtBQUFDVixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaO0FBQWtCTyxNQUFBQSxJQUFJLEdBQUcsR0FBUDtBQUFXUixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaO0FBQW1CLEtBQWxFLE1BQXVFLElBQUdRLENBQUMsQ0FBQ0MsR0FBRixJQUFTLEtBQVosRUFBa0I7QUFBQ0YsTUFBQUEsSUFBSSxHQUFHLEdBQVA7QUFBV1IsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUFrQjs7QUFBQTtBQUV2SCxTQUFLSixXQUFMLENBQWlCYyxNQUFqQixDQUF3QkwsSUFBeEIsRUFBNkJFLElBQTdCO0FBQ05SLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFHQSxRQUFJVyxJQUFJLEdBQUdQLEdBQUcsQ0FBQ0UsQ0FBSixHQUFPLEVBQWxCO0FBQ0EsUUFBSU0sSUFBSSxHQUFHUixHQUFHLENBQUNTLENBQUosR0FBTyxFQUFsQjtBQUVNLFNBQUtqQixXQUFMLENBQWlCa0IsTUFBakIsQ0FBd0JILElBQXhCLEVBQTZCQyxJQUE3QjtBQUNOYixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0MsUUFBSWhCLEVBQUUsQ0FBQ2MsUUFBUCxHQUFrQmdCLE1BQWxCO0FBQ0MsU0FBS2xCLFdBQUwsQ0FBaUJtQixNQUFqQjtBQUNILFNBQUt0QixPQUFMLENBQWF1QixFQUFiLENBQWdCaEMsRUFBRSxDQUFDSyxJQUFILENBQVE0QixTQUFSLENBQWtCQyxTQUFsQyxFQUE0QyxVQUFTQyxDQUFULEVBQVk7QUFDeEQsV0FBS0MsR0FBTDtBQUFZLEtBRFosRUFDYyxJQURkO0FBRUEsU0FBSzVCLE9BQUwsQ0FBYXdCLEVBQWIsQ0FBZ0JoQyxFQUFFLENBQUNLLElBQUgsQ0FBUTRCLFNBQVIsQ0FBa0JJLFVBQWxDLEVBQThDLFVBQVNGLENBQVQsRUFBWTtBQUMxRCxXQUFLRyxFQUFMO0FBQ0EsS0FGQSxFQUVFLElBRkY7QUFHQyxTQUFLNUIsT0FBTCxDQUFhc0IsRUFBYixDQUFnQmhDLEVBQUUsQ0FBQ0ssSUFBSCxDQUFRNEIsU0FBUixDQUFrQkMsU0FBbEMsRUFBNEMsVUFBU0MsQ0FBVCxFQUFZO0FBQ3pELFdBQUtJLEdBQUw7QUFDQSxLQUZDLEVBRUMsSUFGRDtBQUtBLEdBNURPO0FBOERMQyxFQUFBQSxLQTlESyxtQkE4REksQ0FHWDtBQUNHLEdBbEVJO0FBbUVSRixFQUFBQSxFQW5FUSxnQkFtRUo7QUFDRixTQUFLMUIsV0FBTCxDQUFpQjZCLEtBQWpCO0FBQ0QxQixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsUUFBSUMsR0FBRyxHQUFHLEtBQUtYLE1BQUwsQ0FBWVkscUJBQVosQ0FBa0NsQixFQUFFLENBQUNtQixFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbEMsQ0FBVjtBQUNBLFFBQUlDLEdBQUcsR0FBRyxLQUFLWixPQUFMLENBQWFVLHFCQUFiLENBQW1DbEIsRUFBRSxDQUFDbUIsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQW5DLENBQVY7QUFDQUosSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNHLFFBQUlLLElBQUksR0FBR0osR0FBRyxDQUFDSyxDQUFmO0FBQ0gsUUFBSUMsSUFBSSxHQUFHLEdBQVg7O0FBQ00sUUFBR0MsQ0FBQyxDQUFDQyxHQUFGLElBQVMsSUFBWixFQUFpQjtBQUFDVixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaO0FBQWtCTyxNQUFBQSxJQUFJLEdBQUcsR0FBUDtBQUFXUixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaO0FBQW1CLEtBQWxFLE1BQXVFLElBQUdRLENBQUMsQ0FBQ0MsR0FBRixJQUFTLEtBQVosRUFBa0I7QUFBQ0YsTUFBQUEsSUFBSSxHQUFHLEdBQVA7QUFBV1IsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUFrQjs7QUFBQTtBQUN2SCxTQUFLSixXQUFMLENBQWlCYyxNQUFqQixDQUF3QkwsSUFBeEIsRUFBNkJFLElBQTdCO0FBQ05SLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFFQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlJLEdBQUcsQ0FBQ0UsQ0FBaEI7QUFDQSxRQUFJSyxJQUFJLEdBQUdQLEdBQUcsQ0FBQ0UsQ0FBSixHQUFPLEVBQWxCO0FBQ0EsUUFBSU0sSUFBSSxHQUFHUixHQUFHLENBQUNTLENBQUosR0FBTyxFQUFsQjtBQUNNLFNBQUtqQixXQUFMLENBQWlCa0IsTUFBakIsQ0FBd0JILElBQXhCLEVBQTZCQyxJQUE3QjtBQUNOYixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBRUMsUUFBSWhCLEVBQUUsQ0FBQ2MsUUFBUCxHQUFrQmdCLE1BQWxCO0FBQ0MsU0FBS2xCLFdBQUwsQ0FBaUJtQixNQUFqQjtBQUNGLEdBdkZPO0FBd0ZSSyxFQUFBQSxHQXhGUSxpQkF3Rkg7QUFDSlosSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsSUFBUjtBQUNDLFNBQUtiLFdBQUwsQ0FBaUI2QixLQUFqQjtBQUNEMUIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBLFFBQUlDLEdBQUcsR0FBRyxLQUFLWCxNQUFMLENBQVlZLHFCQUFaLENBQWtDbEIsRUFBRSxDQUFDbUIsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQWxDLENBQVY7QUFDQSxRQUFJQyxHQUFHLEdBQUcsS0FBS1osT0FBTCxDQUFhVSxxQkFBYixDQUFtQ2xCLEVBQUUsQ0FBQ21CLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUFuQyxDQUFWO0FBQ0FKLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDRyxRQUFJSyxJQUFJLEdBQUdKLEdBQUcsQ0FBQ0ssQ0FBZjtBQUNILFFBQUlDLElBQUksR0FBRyxHQUFYOztBQUNNLFFBQUdDLENBQUMsQ0FBQ0MsR0FBRixJQUFTLElBQVosRUFBaUI7QUFBQ1YsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUFrQk8sTUFBQUEsSUFBSSxHQUFHLEdBQVA7QUFBV1IsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjtBQUFtQixLQUFsRSxNQUF1RSxJQUFHUSxDQUFDLENBQUNDLEdBQUYsSUFBUyxLQUFaLEVBQWtCO0FBQUNGLE1BQUFBLElBQUksR0FBRyxHQUFQO0FBQVdSLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFBa0I7O0FBQUE7QUFDdkgsU0FBS0osV0FBTCxDQUFpQmMsTUFBakIsQ0FBd0JMLElBQXhCLEVBQTZCRSxJQUE3QjtBQUNOUixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBRUFELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxHQUFHLENBQUNFLENBQWhCO0FBQ0EsUUFBSUssSUFBSSxHQUFHUCxHQUFHLENBQUNFLENBQUosR0FBTyxFQUFsQjtBQUNBLFFBQUlNLElBQUksR0FBR1IsR0FBRyxDQUFDUyxDQUFKLEdBQU8sRUFBbEI7QUFDTSxTQUFLakIsV0FBTCxDQUFpQmtCLE1BQWpCLENBQXdCSCxJQUF4QixFQUE2QkMsSUFBN0I7QUFDTmIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVDLFFBQUloQixFQUFFLENBQUNjLFFBQVAsR0FBa0JnQixNQUFsQjtBQUNDLFNBQUtsQixXQUFMLENBQWlCbUIsTUFBakI7QUFDRixHQTdHTztBQThHUlEsRUFBQUEsR0E5R1EsaUJBOEdIO0FBQ0pmLElBQUFBLENBQUMsQ0FBQ0MsR0FBRixHQUFRLEtBQVI7QUFDQyxTQUFLYixXQUFMLENBQWlCNkIsS0FBakI7QUFDRDFCLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDQSxRQUFJQyxHQUFHLEdBQUcsS0FBS1gsTUFBTCxDQUFZWSxxQkFBWixDQUFrQ2xCLEVBQUUsQ0FBQ21CLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUFsQyxDQUFWO0FBQ0EsUUFBSUMsR0FBRyxHQUFHLEtBQUtaLE9BQUwsQ0FBYVUscUJBQWIsQ0FBbUNsQixFQUFFLENBQUNtQixFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbkMsQ0FBVjtBQUNBSixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0csUUFBSUssSUFBSSxHQUFHSixHQUFHLENBQUNLLENBQWY7QUFDSCxRQUFJQyxJQUFJLEdBQUcsR0FBWDs7QUFDTSxRQUFHQyxDQUFDLENBQUNDLEdBQUYsSUFBUyxJQUFaLEVBQWlCO0FBQUNWLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFBa0JPLE1BQUFBLElBQUksR0FBRyxHQUFQO0FBQVdSLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLElBQVo7QUFBbUIsS0FBbEUsTUFBdUUsSUFBR1EsQ0FBQyxDQUFDQyxHQUFGLElBQVMsS0FBWixFQUFrQjtBQUFDRixNQUFBQSxJQUFJLEdBQUcsR0FBUDtBQUFXUixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxJQUFaO0FBQWtCOztBQUFBO0FBQ3ZILFNBQUtKLFdBQUwsQ0FBaUJjLE1BQWpCLENBQXdCTCxJQUF4QixFQUE2QkUsSUFBN0I7QUFDTlIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUVBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUksR0FBRyxDQUFDRSxDQUFoQjtBQUNBLFFBQUlLLElBQUksR0FBR1AsR0FBRyxDQUFDRSxDQUFKLEdBQU8sRUFBbEI7QUFDQSxRQUFJTSxJQUFJLEdBQUdSLEdBQUcsQ0FBQ1MsQ0FBSixHQUFPLEVBQWxCO0FBQ00sU0FBS2pCLFdBQUwsQ0FBaUJrQixNQUFqQixDQUF3QkgsSUFBeEIsRUFBNkJDLElBQTdCO0FBQ05iLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFFQyxRQUFJaEIsRUFBRSxDQUFDYyxRQUFQLEdBQWtCZ0IsTUFBbEI7QUFDQyxTQUFLbEIsV0FBTCxDQUFpQm1CLE1BQWpCO0FBQ0YsR0FuSU8sQ0FvSUw7O0FBcElLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbImNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgbWFpbkNhbnZhczogY2MuTm9kZSxcclxuXHRcdHBsYXllcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIzOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuXHRcdFx0XHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcbiAgICB9LFxyXG5cdFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcblx0XHRcclxuXHRcdHRoaXMubWFpbkNvbnRleHQgPSB0aGlzLm1haW5DYW52YXMuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcclxuXHRcdFxyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhMnAgPSB0aGlzLnBsYXllci5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHR2YXIgYjJwID0gdGhpcy5wbGF5ZXIyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdGNvbnNvbGUubG9nKCflvIDlp4vnlLvnur84Jyk7XHJcblx0ICAgIHZhciBhMnB4ID0gYTJwLng7XHJcblx0XHR2YXIgYTJweSA9IDE2OTtcclxuICAgICAgICBpZihHLnJlZCA9PSB0cnVlKXtjb25zb2xlLmxvZyhcIjExXCIpO2EycHkgPSAxNjk7Y29uc29sZS5sb2coXCIxMVwiKTt9ZWxzZSBpZihHLnJlZCA9PSBmYWxzZSl7YTJweSA9IDEzMjtjb25zb2xlLmxvZyhcIjExXCIpfTtcclxuXHRcdFxyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGEycHgsYTJweSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/Jyk7XHJcblx0XHRcclxuXHRcclxuXHRcdHZhciBiMnB4ID0gYjJwLnggLTI2O1xyXG5cdFx0dmFyIGIycHkgPSBiMnAueSAtNjMgO1xyXG5cdFx0XHJcbiAgICAgICAgdGhpcy5tYWluQ29udGV4dC5saW5lVG8oYjJweCxiMnB5KTtcclxuXHRcdGNvbnNvbGUubG9nKCflvIDlp4vnlLvnur8yJyk7XHJcblx0XHQgbmV3IGNjLkdyYXBoaWNzKCkubGluZVRvKCk7XHJcbiAgICB0aGlzLm1haW5Db250ZXh0LnN0cm9rZSgpO1xyXG5cdHRoaXMucGxheWVyMy5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsZnVuY3Rpb24odCkge1xyXG5cdHRoaXMuZnUxKCk7fSwgdGhpcyk7XHJcbiB0aGlzLnBsYXllcjIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgZnVuY3Rpb24odCkge1xyXG5cdHRoaXMuZnUoKTtcclxufSwgdGhpcyk7XHJcblx0XHR0aGlzLnBsYXllcjQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKHQpIHtcclxuXHR0aGlzLmZ1MigpO1xyXG59LCB0aGlzKTtcclxuXHRcdFxyXG5cdFx0XHJcblx0fSxcclxuXHJcbiAgICBzdGFydCAoKSB7XHJcblx0XHRcclxuXHJcblx0XHQvL2NvbnNvbGUubG9nKHRtcFBhdGgpXHJcbiAgICB9LFxyXG5cdGZ1KCl7XHJcblx0XHQgdGhpcy5tYWluQ29udGV4dC5jbGVhcigpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhMnAgPSB0aGlzLnBsYXllci5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHR2YXIgYjJwID0gdGhpcy5wbGF5ZXIyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdGNvbnNvbGUubG9nKCflvIDlp4vnlLvnur84Jyk7XHJcblx0ICAgIHZhciBhMnB4ID0gYTJwLng7XHJcblx0XHR2YXIgYTJweSA9IDE2OTtcclxuICAgICAgICBpZihHLnJlZCA9PSB0cnVlKXtjb25zb2xlLmxvZyhcIjExXCIpO2EycHkgPSAxNjk7Y29uc29sZS5sb2coXCIxMVwiKTt9ZWxzZSBpZihHLnJlZCA9PSBmYWxzZSl7YTJweSA9IDEzMjtjb25zb2xlLmxvZyhcIjExXCIpfTtcclxuICAgICAgICB0aGlzLm1haW5Db250ZXh0Lm1vdmVUbyhhMnB4LGEycHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vycpO1xyXG5cdFx0XHJcblx0XHRjb25zb2xlLmxvZyhiMnAueCk7XHJcblx0XHR2YXIgYjJweCA9IGIycC54IC0yNjtcclxuXHRcdHZhciBiMnB5ID0gYjJwLnkgLTYzIDtcclxuICAgICAgICB0aGlzLm1haW5Db250ZXh0LmxpbmVUbyhiMnB4LGIycHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzInKTtcclxuICAgIFxyXG4gICBuZXcgY2MuR3JhcGhpY3MoKS5saW5lVG8oKTtcclxuICAgIHRoaXMubWFpbkNvbnRleHQuc3Ryb2tlKCk7XHJcblx0fSxcclxuXHRmdTEoKXtcclxuXHRcdEcucmVkID0gdHJ1ZTtcclxuXHRcdCB0aGlzLm1haW5Db250ZXh0LmNsZWFyKCk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/NycpO1xyXG5cdFx0dmFyIGEycCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBiMnAgPSB0aGlzLnBsYXllcjIuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsMCkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzgnKTtcclxuXHQgICAgdmFyIGEycHggPSBhMnAueDtcclxuXHRcdHZhciBhMnB5ID0gMTY5O1xyXG4gICAgICAgIGlmKEcucmVkID09IHRydWUpe2NvbnNvbGUubG9nKFwiMTFcIik7YTJweSA9IDE2OTtjb25zb2xlLmxvZyhcIjExXCIpO31lbHNlIGlmKEcucmVkID09IGZhbHNlKXthMnB5ID0gMTMyO2NvbnNvbGUubG9nKFwiMTFcIil9O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGEycHgsYTJweSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/Jyk7XHJcblx0XHRcclxuXHRcdGNvbnNvbGUubG9nKGIycC54KTtcclxuXHRcdHZhciBiMnB4ID0gYjJwLnggLTI2O1xyXG5cdFx0dmFyIGIycHkgPSBiMnAueSAtNjMgO1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGIycHgsYjJweSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/MicpO1xyXG4gICAgXHJcbiAgIG5ldyBjYy5HcmFwaGljcygpLmxpbmVUbygpO1xyXG4gICAgdGhpcy5tYWluQ29udGV4dC5zdHJva2UoKTtcclxuXHR9LFxyXG5cdGZ1Migpe1xyXG5cdFx0Ry5yZWQgPSBmYWxzZTtcclxuXHRcdCB0aGlzLm1haW5Db250ZXh0LmNsZWFyKCk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/NycpO1xyXG5cdFx0dmFyIGEycCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBiMnAgPSB0aGlzLnBsYXllcjIuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsMCkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzgnKTtcclxuXHQgICAgdmFyIGEycHggPSBhMnAueDtcclxuXHRcdHZhciBhMnB5ID0gMTY5O1xyXG4gICAgICAgIGlmKEcucmVkID09IHRydWUpe2NvbnNvbGUubG9nKFwiMTFcIik7YTJweSA9IDE2OTtjb25zb2xlLmxvZyhcIjExXCIpO31lbHNlIGlmKEcucmVkID09IGZhbHNlKXthMnB5ID0gMTMyO2NvbnNvbGUubG9nKFwiMTFcIil9O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGEycHgsYTJweSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/Jyk7XHJcblx0XHRcclxuXHRcdGNvbnNvbGUubG9nKGIycC54KTtcclxuXHRcdHZhciBiMnB4ID0gYjJwLnggLTI2O1xyXG5cdFx0dmFyIGIycHkgPSBiMnAueSAtNjMgO1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGIycHgsYjJweSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/MicpO1xyXG4gICAgXHJcbiAgIG5ldyBjYy5HcmFwaGljcygpLmxpbmVUbygpO1xyXG4gICAgdGhpcy5tYWluQ29udGV4dC5zdHJva2UoKTtcclxuXHR9LFxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcblx0XHJcblxyXG5cdFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/huaxian.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ff717BZCpMQZb6oaFScaaP', 'huaxian');
// Script/huaxian.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    mainCanvas: cc.Node,
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {//var apx = 1;
    //console.log(tmpPath)
  },
  start: function start() {
    console.log("SASDA");
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
    this.player2.on(cc.Node.EventType.START, function (t) {
      this.fu();
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      this.fu();
    }, this);
  },
  fu: function fu() {
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    this.mainContext.clear();
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxodWF4aWFuLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibWFpbkNhbnZhcyIsIk5vZGUiLCJwbGF5ZXIiLCJ0eXBlIiwicGxheWVyMiIsIm9uTG9hZCIsInN0YXJ0IiwiY29uc29sZSIsImxvZyIsIm1haW5Db250ZXh0IiwiZ2V0Q29tcG9uZW50IiwiR3JhcGhpY3MiLCJhcCIsImNvbnZlcnRUb1dvcmxkU3BhY2VBUiIsInYyIiwiYnAiLCJhcHgiLCJ4IiwiYXB5IiwieSIsIm1vdmVUbyIsImJweCIsImJweSIsImxpbmVUbyIsInN0cm9rZSIsIm9uIiwiRXZlbnRUeXBlIiwiU1RBUlQiLCJ0IiwiZnUiLCJUT1VDSF9NT1ZFIiwiY2xlYXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUVKLEVBQUUsQ0FBQ0ssSUFEUDtBQUVkQyxJQUFBQSxNQUFNLEVBQUU7QUFDRSxpQkFBUyxJQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRVAsRUFBRSxDQUFDSztBQUZYLEtBRk07QUFNZEcsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDRCxNQUFBQSxJQUFJLEVBQUVQLEVBQUUsQ0FBQ0s7QUFGVjtBQU5LLEdBSFA7QUFpQkw7QUFFQUksRUFBQUEsTUFuQkssb0JBbUJLLENBRVo7QUFJQTtBQUVBLEdBM0JPO0FBNkJMQyxFQUFBQSxLQTdCSyxtQkE2Qkk7QUFBQ0MsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUFzQixTQUFLQyxXQUFMLEdBQW1CLEtBQUtULFVBQUwsQ0FBZ0JVLFlBQWhCLENBQTZCZCxFQUFFLENBQUNlLFFBQWhDLENBQW5CO0FBRWxDSixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsUUFBSUksRUFBRSxHQUFHLEtBQUtWLE1BQUwsQ0FBWVcscUJBQVosQ0FBa0NqQixFQUFFLENBQUNrQixFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbEMsQ0FBVDtBQUNBLFFBQUlDLEVBQUUsR0FBRyxLQUFLWCxPQUFMLENBQWFTLHFCQUFiLENBQW1DakIsRUFBRSxDQUFDa0IsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQW5DLENBQVQ7QUFDQVAsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNHLFFBQUlRLEdBQUcsR0FBR0osRUFBRSxDQUFDSyxDQUFiO0FBQ0gsUUFBSUMsR0FBRyxHQUFHTixFQUFFLENBQUNPLENBQWI7QUFDTSxTQUFLVixXQUFMLENBQWlCVyxNQUFqQixDQUF3QkosR0FBeEIsRUFBNEJFLEdBQTVCO0FBQ05YLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFFQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlPLEVBQUUsQ0FBQ0UsQ0FBZjtBQUNBLFFBQUlJLEdBQUcsR0FBR04sRUFBRSxDQUFDRSxDQUFILEdBQU0sRUFBaEI7QUFFQSxRQUFJSyxHQUFHLEdBQUdQLEVBQUUsQ0FBQ0ksQ0FBSCxHQUFNLEVBQWhCO0FBQ00sU0FBS1YsV0FBTCxDQUFpQmMsTUFBakIsQ0FBd0JGLEdBQXhCLEVBQTRCQyxHQUE1QjtBQUNOZixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0MsUUFBSVosRUFBRSxDQUFDZSxRQUFQLEdBQWtCWSxNQUFsQjtBQUNDLFNBQUtkLFdBQUwsQ0FBaUJlLE1BQWpCO0FBQ0osU0FBS3BCLE9BQUwsQ0FBYXFCLEVBQWIsQ0FBZ0I3QixFQUFFLENBQUNLLElBQUgsQ0FBUXlCLFNBQVIsQ0FBa0JDLEtBQWxDLEVBQXlDLFVBQVNDLENBQVQsRUFBWTtBQUNwRCxXQUFLQyxFQUFMO0FBQVcsS0FEWixFQUNjLElBRGQ7QUFFRyxTQUFLekIsT0FBTCxDQUFhcUIsRUFBYixDQUFnQjdCLEVBQUUsQ0FBQ0ssSUFBSCxDQUFReUIsU0FBUixDQUFrQkksVUFBbEMsRUFBOEMsVUFBU0YsQ0FBVCxFQUFZO0FBQzVELFdBQUtDLEVBQUw7QUFDQSxLQUZFLEVBRUEsSUFGQTtBQUdFLEdBckRJO0FBc0RSQSxFQUFBQSxFQXREUSxnQkFzREo7QUFDSCxTQUFLcEIsV0FBTCxHQUFtQixLQUFLVCxVQUFMLENBQWdCVSxZQUFoQixDQUE2QmQsRUFBRSxDQUFDZSxRQUFoQyxDQUFuQjtBQUNBLFNBQUtGLFdBQUwsQ0FBaUJzQixLQUFqQjtBQUNBeEIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBLFFBQUlJLEVBQUUsR0FBRyxLQUFLVixNQUFMLENBQVlXLHFCQUFaLENBQWtDakIsRUFBRSxDQUFDa0IsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQWxDLENBQVQ7QUFDQSxRQUFJQyxFQUFFLEdBQUcsS0FBS1gsT0FBTCxDQUFhUyxxQkFBYixDQUFtQ2pCLEVBQUUsQ0FBQ2tCLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUFuQyxDQUFUO0FBQ0FQLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDRyxRQUFJUSxHQUFHLEdBQUdKLEVBQUUsQ0FBQ0ssQ0FBYjtBQUNILFFBQUlDLEdBQUcsR0FBR04sRUFBRSxDQUFDTyxDQUFiO0FBQ00sU0FBS1YsV0FBTCxDQUFpQlcsTUFBakIsQ0FBd0JKLEdBQXhCLEVBQTRCRSxHQUE1QjtBQUNOWCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBRUFELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZTyxFQUFFLENBQUNFLENBQWY7QUFDQSxRQUFJSSxHQUFHLEdBQUdOLEVBQUUsQ0FBQ0UsQ0FBSCxHQUFNLEVBQWhCO0FBRUEsUUFBSUssR0FBRyxHQUFHUCxFQUFFLENBQUNJLENBQUgsR0FBTSxFQUFoQjtBQUNNLFNBQUtWLFdBQUwsQ0FBaUJjLE1BQWpCLENBQXdCRixHQUF4QixFQUE0QkMsR0FBNUI7QUFDTmYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVDLFFBQUlaLEVBQUUsQ0FBQ2UsUUFBUCxHQUFrQlksTUFBbEI7QUFDQyxTQUFLZCxXQUFMLENBQWlCZSxNQUFqQjtBQUNGLEdBM0VPLENBNkVMOztBQTdFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG1haW5DYW52YXM6IGNjLk5vZGUsXHJcblx0XHRwbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0XHJcbiAgICB9LFxyXG5cdFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcblx0XHRcclxuXHRcdC8vdmFyIGFweCA9IDE7XHJcblx0XHJcblx0XHJcblxyXG5cdFx0Ly9jb25zb2xlLmxvZyh0bXBQYXRoKVxyXG5cdFx0XHJcblx0fSxcclxuXHJcbiAgICBzdGFydCAoKSB7Y29uc29sZS5sb2coXCJTQVNEQVwiKTtcdHRoaXMubWFpbkNvbnRleHQgPSB0aGlzLm1haW5DYW52YXMuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcclxuXHRcdFxyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhcCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBicCA9IHRoaXMucGxheWVyMi5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/OCcpO1xyXG5cdCAgICB2YXIgYXB4ID0gYXAueDtcclxuXHRcdHZhciBhcHkgPSBhcC55O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGFweCxhcHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vycpO1xyXG5cdFx0XHJcblx0XHRjb25zb2xlLmxvZyhicC54KTtcclxuXHRcdHZhciBicHggPSBicC54IC02NjtcclxuXHRcdFxyXG5cdFx0dmFyIGJweSA9IGJwLnkgKzQ1O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGJweCxicHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzInKTtcclxuXHRcdCBuZXcgY2MuR3JhcGhpY3MoKS5saW5lVG8oKTtcclxuICAgIHRoaXMubWFpbkNvbnRleHQuc3Ryb2tlKCk7XHJcbnRoaXMucGxheWVyMi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5TVEFSVCwgZnVuY3Rpb24odCkge1xyXG5cdHRoaXMuZnUoKTt9LCB0aGlzKTtcclxuXHRcdFx0dGhpcy5wbGF5ZXIyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIGZ1bmN0aW9uKHQpIHtcclxuXHR0aGlzLmZ1KCk7XHJcbn0sIHRoaXMpO1xyXG4gICAgfSxcclxuXHRmdSgpe1xyXG5cdFx0dGhpcy5tYWluQ29udGV4dCA9IHRoaXMubWFpbkNhbnZhcy5nZXRDb21wb25lbnQoY2MuR3JhcGhpY3MpO1xyXG5cdFx0dGhpcy5tYWluQ29udGV4dC5jbGVhcigpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhcCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBicCA9IHRoaXMucGxheWVyMi5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/OCcpO1xyXG5cdCAgICB2YXIgYXB4ID0gYXAueDtcclxuXHRcdHZhciBhcHkgPSBhcC55O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGFweCxhcHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vycpO1xyXG5cdFx0XHJcblx0XHRjb25zb2xlLmxvZyhicC54KTtcclxuXHRcdHZhciBicHggPSBicC54IC02NjtcclxuXHRcdFxyXG5cdFx0dmFyIGJweSA9IGJwLnkgKzQ1O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGJweCxicHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzInKTtcclxuICAgIFxyXG4gICBuZXcgY2MuR3JhcGhpY3MoKS5saW5lVG8oKTtcclxuICAgIHRoaXMubWFpbkNvbnRleHQuc3Ryb2tlKCk7XHJcblx0fSxcclxuXHRcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG5cdFxyXG5cclxuXHRcclxufSk7XHJcbiJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/CC.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '00fa9yqF9lNM7oBcwMsQ59b', 'CC');
// Script/CC.js

"use strict";

var _window$G;

window.G = (_window$G = {
  red: true,
  xiangmu: 1,
  dangwei: 0,
  xianshi: 1,
  tip: 1,
  hongbi: null,
  heibi: null,
  hongbiyes: 0,
  heibiyes: 0,
  btr: 0,
  btb: 0,
  rtr: 0,
  rtb: 0,
  xls: 0,
  rtg: 0,
  btg: 0,
  mode: 1,
  source: 1,
  ch1: true,
  ch2: false
}, _window$G["xianshi"] = '万用表关闭时选择关闭档或者电压最高档', _window$G);

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDQy5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJHIiwicmVkIiwieGlhbmdtdSIsImRhbmd3ZWkiLCJ4aWFuc2hpIiwidGlwIiwiaG9uZ2JpIiwiaGVpYmkiLCJob25nYml5ZXMiLCJoZWliaXllcyIsImJ0ciIsImJ0YiIsInJ0ciIsInJ0YiIsInhscyIsInJ0ZyIsImJ0ZyIsIm1vZGUiLCJzb3VyY2UiLCJjaDEiLCJjaDIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxDQUFQO0FBRUFDLEVBQUFBLEdBQUcsRUFBRyxJQUZOO0FBR0FDLEVBQUFBLE9BQU8sRUFBQyxDQUhSO0FBSUFDLEVBQUFBLE9BQU8sRUFBQyxDQUpSO0FBS0FDLEVBQUFBLE9BQU8sRUFBQyxDQUxSO0FBTUFDLEVBQUFBLEdBQUcsRUFBQyxDQU5KO0FBT0FDLEVBQUFBLE1BQU0sRUFBQyxJQVBQO0FBUUFDLEVBQUFBLEtBQUssRUFBQyxJQVJOO0FBU0FDLEVBQUFBLFNBQVMsRUFBQyxDQVRWO0FBVUFDLEVBQUFBLFFBQVEsRUFBQyxDQVZUO0FBV0FDLEVBQUFBLEdBQUcsRUFBQyxDQVhKO0FBWUFDLEVBQUFBLEdBQUcsRUFBQyxDQVpKO0FBYUFDLEVBQUFBLEdBQUcsRUFBQyxDQWJKO0FBY0FDLEVBQUFBLEdBQUcsRUFBQyxDQWRKO0FBZUFDLEVBQUFBLEdBQUcsRUFBQyxDQWZKO0FBZ0JBQyxFQUFBQSxHQUFHLEVBQUMsQ0FoQko7QUFpQkFDLEVBQUFBLEdBQUcsRUFBQyxDQWpCSjtBQWtCQUMsRUFBQUEsSUFBSSxFQUFDLENBbEJMO0FBbUJBQyxFQUFBQSxNQUFNLEVBQUMsQ0FuQlA7QUFvQkFDLEVBQUFBLEdBQUcsRUFBQyxJQXBCSjtBQXFCQUMsRUFBQUEsR0FBRyxFQUFDO0FBckJKLDBCQXdCUSxvQkF4QlIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HID0ge1xyXG5cclxucmVkIDogdHJ1ZSxcclxueGlhbmdtdToxLFxyXG5kYW5nd2VpOjAsXHJcbnhpYW5zaGk6MSxcclxudGlwOjEsXHJcbmhvbmdiaTpudWxsLFxyXG5oZWliaTpudWxsLFxyXG5ob25nYml5ZXM6MCxcclxuaGVpYml5ZXM6MCxcclxuYnRyOjAsXHJcbmJ0YjowLFxyXG5ydHI6MCxcclxucnRiOjAsXHJcbnhsczowLFxyXG5ydGc6MCxcclxuYnRnOjAsXHJcbm1vZGU6MSxcclxuc291cmNlOjEsXHJcbmNoMTp0cnVlLFxyXG5jaDI6ZmFsc2UsXHJcblxyXG5cclxueGlhbnNoaTon5LiH55So6KGo5YWz6Zet5pe26YCJ5oup5YWz6Zet5qGj5oiW6ICF55S15Y6L5pyA6auY5qGjJyxcclxufSJdfQ==
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript - 004.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7d6c2wC1hBPsrSw5gT7LMCf', 'NewScript - 004');
// Script/NewScript - 004.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    }
  },
  ontm: function ontm(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    var del = t.getDelta();
    this.node.x += del.x;
    this.node.y += del.y;
  },
  ontm2: function ontm2(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.node.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("1");
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.ontm, this);
    this.player.on(cc.Node.EventType.TOUCH_MOVE, this.ontm2, this);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQgLSAwMDQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiTm9kZSIsIm9udG0iLCJ0IiwidyIsIm5vZGUiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJ2MiIsInkiLCJHIiwiaG9uZ2JpIiwiZGVsIiwiZ2V0RGVsdGEiLCJ4Iiwib250bTIiLCJvbkxvYWQiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiY29uc29sZSIsImxvZyIsIlRPVUNIX01PVkUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ05DLElBQUFBLE1BQU0sRUFBRTtBQUNFLGlCQUFTLElBRFg7QUFFRUMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlg7QUFoQk0sR0FIUDtBQXlCVEMsRUFBQUEsSUFBSSxFQUFDLGNBQVNDLENBQVQsRUFBVztBQUNiLFFBQUlDLENBQUMsR0FBRSxLQUFLQyxJQUFMLENBQVVDLHFCQUFWLENBQWdDWCxFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFoQyxDQUFQO0FBRUFILElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNSixDQUFDLENBQUNJLENBQUYsR0FBSSxLQUFWO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsTUFBRixHQUFTTixDQUFUO0FBRUEsUUFBSU8sR0FBRyxHQUFHUixDQUFDLENBQUNTLFFBQUYsRUFBVjtBQUNBLFNBQUtQLElBQUwsQ0FBVVEsQ0FBVixJQUFlRixHQUFHLENBQUNFLENBQW5CO0FBQ0EsU0FBS1IsSUFBTCxDQUFVRyxDQUFWLElBQWVHLEdBQUcsQ0FBQ0gsQ0FBbkI7QUFFQSxHQW5DTTtBQW9DVE0sRUFBQUEsS0FBSyxFQUFDLGVBQVNYLENBQVQsRUFBVztBQUNkLFFBQUlDLENBQUMsR0FBRSxLQUFLQyxJQUFMLENBQVVDLHFCQUFWLENBQWdDWCxFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFoQyxDQUFQO0FBRUFILElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNSixDQUFDLENBQUNJLENBQUYsR0FBSSxLQUFWO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsTUFBRixHQUFTTixDQUFUO0FBSUEsR0E1Q007QUE2Q0w7QUFDSFcsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2xCLFNBQUtWLElBQUwsQ0FBVVcsRUFBVixDQUFhckIsRUFBRSxDQUFDTSxJQUFILENBQVFnQixTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxVQUFTZixDQUFULEVBQVc7QUFBQ2dCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVo7QUFBa0IsS0FBMUUsRUFBMkUsSUFBM0U7QUFDQSxTQUFLZixJQUFMLENBQVVXLEVBQVYsQ0FBYXJCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRZ0IsU0FBUixDQUFrQkksVUFBL0IsRUFBMkMsS0FBS25CLElBQWhELEVBQXFELElBQXJEO0FBQ0EsU0FBS0gsTUFBTCxDQUFZaUIsRUFBWixDQUFlckIsRUFBRSxDQUFDTSxJQUFILENBQVFnQixTQUFSLENBQWtCSSxVQUFqQyxFQUE2QyxLQUFLUCxLQUFsRCxFQUF3RCxJQUF4RDtBQUVLLEdBbkRJO0FBb0RMO0FBRUFRLEVBQUFBLEtBdERLLG1CQXNESSxDQUVSLENBeERJLENBMERMOztBQTFESyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsICAgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgICBzZXJpYWxpemFibGU6IHRydWUsICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gYmFyOiB7XHJcbiAgICAgICAgLy8gICAgIGdldCAoKSB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xyXG4gICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgIC8vICAgICBzZXQgKHZhbHVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0sXHJcblx0XHRwbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRcclxuICAgIH0sXHJcbm9udG06ZnVuY3Rpb24odCl7XHJcblx0XHRcdHZhciB3ID10aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRcdFx0XHJcblx0XHRcdHZhciBkZWwgPSB0LmdldERlbHRhKCk7XHJcblx0XHRcdHRoaXMubm9kZS54ICs9IGRlbC54O1xyXG5cdFx0XHR0aGlzLm5vZGUueSArPSBkZWwueTtcclxuXHRcdFxyXG5cdFx0fSxcclxub250bTI6ZnVuY3Rpb24odCl7XHJcblx0XHRcdHZhciB3ID10aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0XHJcblx0XHR9LFxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcbiBvbkxvYWQ6ZnVuY3Rpb24oKXtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcIjFcIik7fSx0aGlzKTtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub250bSx0aGlzKTtcclxudGhpcy5wbGF5ZXIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vbnRtMix0aGlzKTtcclxuXHJcbiAgICB9LFxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '2c7b6SXE6tBlok4qo2BwaWS', 'NewScript');
// Script/NewScript.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Sprite
    },
    player2: {
      "default": null,
      type: cc.Sprite
    },
    player3: {
      "default": null,
      type: cc.Sprite
    },
    player4: {
      "default": null,
      type: cc.Sprite
    },
    player5: {
      "default": null,
      type: cc.Sprite
    },
    player6: {
      "default": null,
      type: cc.WebView
    },
    imgIdx: 1,
    sprArray: {
      "default": [],
      type: cc.Sprite
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    G.pt = 1;
  },
  tonew: function tonew() {
    if (G.pt == 1) {
      cc.director.loadScene("New Scene");
    } else {
      if (G.pt == 2) {
        cc.director.loadScene("os");
      }
    }

    ;
  },
  toch1: function toch1() {
    G.ch2 = false;
    G.ch1 = true;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  toch2: function toch2() {
    G.ch1 = false;
    G.ch2 = true;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tomode1: function tomode1() {
    G.mode = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tomode2: function tomode2() {
    G.mode = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo1: function tovo1() {
    G.VO = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo2: function tovo2() {
    G.VO = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo3: function tovo3() {
    G.VO = 3;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tosou1: function tosou1() {
    G.source = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      console.log("dasdas");

      if (G.VO == 1) {
        console.log("dasdas");
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  slider: function slider() {},
  tosou2: function tosou2() {
    G.source = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  newos: function newos() {
    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tologo: function tologo() {
    cc.director.loadScene("helloworld");
    G.red = true;
    G.xiangmu = 1;
    G.dangwei = 0;
    G.xianshi = 1;
    G.tip = 1;
    G.hongbi = null;
    G.heibi = null;
    G.hongbiyes = 0;
    G.heibiyes = 0;
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    G.xls = 0;
    G.rtg = 0;
    G.btgV0;
    G.mode = 1;
    G.sourceV1;
    G.ch1 = true;
    G.ch2 = false;
    G.pp = 0;
    G.VO = 1;
    G.pt = 1;
  },
  tohelp: function tohelp() {
    cc.director.loadScene("help");
  },
  tomili: function tomili() {
    G.pt = 1;
  },
  toos: function toos() {
    G.pt = 2;
  },
  toweb1: function toweb1() {
    this.player6.Url = "https://www.bilibili.com/video/BV1Gx411z7x2?from=search&seid=14704342665083105122";
  },
  toweb2: function toweb2() {
    this.player6.Url = "https://www.bilibili.com/video/BV1Q4411f7QR?from=search&seid=10660677663550777909";
  },
  toweb3: function toweb3() {
    this.player6.Url = "https://www.bilibili.com/video/BV1uW411g76V?from=search&seid=10660677663550777909";
  },
  toro: function toro() {
    this.player.angel -= 18;
    G.dangwei -= 1;

    if (G.dangwei == -1) {
      G.dangwei = 19;
    }
  },
  tored1: function tored1() {
    G.red = true;
  },
  tored2: function tored2() {
    G.red = false;
    console.log("shi");
  },
  tox1: function tox1() {
    G.xiangmu = 1;
    this.player.spriteFrame = this.sprArray[0].spriteFrame;
  },
  tox2: function tox2() {
    G.xiangmu = 2;
    this.player.spriteFrame = this.sprArray[1].spriteFrame;
  },
  tox3: function tox3() {
    G.xiangmu = 3;
    this.player.spriteFrame = this.sprArray[2].spriteFrame;
  },
  tox4: function tox4() {
    G.xiangmu = 4;
    this.player.spriteFrame = this.sprArray[3].spriteFrame;
  },
  tox5: function tox5() {
    G.xiangmu = 5;
    this.player.spriteFrame = this.sprArray[4].spriteFrame;
  },
  toro2: function toro2() {
    this.player.angel += 18;
    G.dangwei += 1;

    if (G.dangwei == 20) {
      G.dangwei = 0;
    }
  },
  tohelp2: function tohelp2() {
    cc.director.loadScene("help-22");
  } // update (dt) {},
  // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiU3ByaXRlIiwicGxheWVyMiIsInBsYXllcjMiLCJwbGF5ZXI0IiwicGxheWVyNSIsInBsYXllcjYiLCJXZWJWaWV3IiwiaW1nSWR4Iiwic3ByQXJyYXkiLCJzdGFydCIsIkciLCJwdCIsInRvbmV3IiwiZGlyZWN0b3IiLCJsb2FkU2NlbmUiLCJ0b2NoMSIsImNoMiIsImNoMSIsIm1vZGUiLCJzb3VyY2UiLCJWTyIsInNwcml0ZUZyYW1lIiwidG9jaDIiLCJ0b21vZGUxIiwidG9tb2RlMiIsInRvdm8xIiwidG92bzIiLCJ0b3ZvMyIsInRvc291MSIsImNvbnNvbGUiLCJsb2ciLCJzbGlkZXIiLCJ0b3NvdTIiLCJuZXdvcyIsInRvbG9nbyIsInJlZCIsInhpYW5nbXUiLCJkYW5nd2VpIiwieGlhbnNoaSIsInRpcCIsImhvbmdiaSIsImhlaWJpIiwiaG9uZ2JpeWVzIiwiaGVpYml5ZXMiLCJidHIiLCJidGIiLCJydHIiLCJydGIiLCJ4bHMiLCJydGciLCJidGdWMCIsInNvdXJjZVYxIiwicHAiLCJ0b2hlbHAiLCJ0b21pbGkiLCJ0b29zIiwidG93ZWIxIiwiVXJsIiwidG93ZWIyIiwidG93ZWIzIiwidG9ybyIsImFuZ2VsIiwidG9yZWQxIiwidG9yZWQyIiwidG94MSIsInRveDIiLCJ0b3gzIiwidG94NCIsInRveDUiLCJ0b3JvMiIsInRvaGVscDIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBSVJDLEVBQUFBLFVBQVUsRUFBRTtBQUNMO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVOQyxJQUFBQSxNQUFNLEVBQUU7QUFDRSxpQkFBUyxJQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZYLEtBakJHO0FBcUJYQyxJQUFBQSxPQUFPLEVBQUU7QUFDQyxpQkFBUyxJQURWO0FBRUNGLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZWLEtBckJFO0FBeUJWRSxJQUFBQSxPQUFPLEVBQUU7QUFDQSxpQkFBUyxJQURUO0FBRUFILE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZULEtBekJDO0FBNkJWRyxJQUFBQSxPQUFPLEVBQUU7QUFDQSxpQkFBUyxJQURUO0FBRUFKLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZULEtBN0JDO0FBaUNWSSxJQUFBQSxPQUFPLEVBQUU7QUFDQSxpQkFBUyxJQURUO0FBRUFMLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZULEtBakNDO0FBcUNYSyxJQUFBQSxPQUFPLEVBQUU7QUFDQyxpQkFBUyxJQURWO0FBRUNOLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDWTtBQUZWLEtBckNFO0FBeUNWQyxJQUFBQSxNQUFNLEVBQUcsQ0F6Q0M7QUEwQ1pDLElBQUFBLFFBQVEsRUFBRTtBQUNDLGlCQUFRLEVBRFQ7QUFFQ1QsTUFBQUEsSUFBSSxFQUFDTCxFQUFFLENBQUNNO0FBRlQ7QUExQ0UsR0FKSjtBQXFETDtBQUVBO0FBRUFTLEVBQUFBLEtBekRLLG1CQXlESTtBQUNiQyxJQUFBQSxDQUFDLENBQUNDLEVBQUYsR0FBTSxDQUFOO0FBQ0csR0EzRE07QUE0RE5DLEVBQUFBLEtBQUssRUFBRSxpQkFBWTtBQUNkLFFBQUdGLENBQUMsQ0FBQ0MsRUFBRixJQUFNLENBQVQsRUFBVztBQUFDakIsTUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFdBQXRCO0FBQW1DLEtBQS9DLE1BQW1EO0FBQUMsVUFBR0osQ0FBQyxDQUFDQyxFQUFGLElBQU0sQ0FBVCxFQUFXO0FBQUNqQixRQUFBQSxFQUFFLENBQUNtQixRQUFILENBQVlDLFNBQVosQ0FBc0IsSUFBdEI7QUFBNEI7QUFBQzs7QUFBQTtBQUNoRyxHQTlESTtBQStEUEMsRUFBQUEsS0FBSyxFQUFFLGlCQUFZO0FBRWxCTCxJQUFBQSxDQUFDLENBQUNNLEdBQUYsR0FBUSxLQUFSO0FBQ0NOLElBQUFBLENBQUMsQ0FBQ08sR0FBRixHQUFRLElBQVI7O0FBQ0MsUUFBS1AsQ0FBQyxDQUFDUSxJQUFGLElBQVMsQ0FBVCxHQUFhUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF4QixHQUEyQlQsQ0FBQyxDQUFDTyxHQUFGLElBQVEsSUFBeEMsRUFBNkM7QUFBQyxVQUFHUCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQVc7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBcEUsTUFBeUUsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUN6SDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURnRSxNQUMzRCxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUMsS0FGeEQsTUFFNkQ7QUFBQyxVQUFLWCxDQUFDLENBQUNRLElBQUYsSUFBVSxDQUFWLEdBQWNSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXpCLEdBQTRCVCxDQUFDLENBQUNPLEdBQUYsSUFBUyxJQUExQyxFQUErQztBQUFDLGFBQUtoQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUF4RyxNQUE2RyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzdLO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRG9ILE1BQy9HLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQzs7QUFBQTtBQUN4RCxHQXhFSTtBQXlFUEMsRUFBQUEsS0FBSyxFQUFFLGlCQUFZO0FBRWxCWixJQUFBQSxDQUFDLENBQUNPLEdBQUYsR0FBUSxLQUFSO0FBQ0NQLElBQUFBLENBQUMsQ0FBQ00sR0FBRixHQUFRLElBQVI7O0FBQ0MsUUFBS04sQ0FBQyxDQUFDUSxJQUFGLElBQVMsQ0FBVCxHQUFhUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF4QixHQUEyQlQsQ0FBQyxDQUFDTyxHQUFGLElBQVEsSUFBeEMsRUFBNkM7QUFBQyxVQUFHUCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQVc7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBcEUsTUFBeUUsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUN6SDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURnRSxNQUMzRCxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUMsS0FGeEQsTUFFNkQ7QUFBQyxVQUFLWCxDQUFDLENBQUNRLElBQUYsSUFBVSxDQUFWLEdBQWNSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXpCLEdBQTRCVCxDQUFDLENBQUNPLEdBQUYsSUFBUyxJQUExQyxFQUErQztBQUFDLGFBQUtoQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUF4RyxNQUE2RyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzdLO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRG9ILE1BQy9HLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQzs7QUFBQTtBQUN4RCxHQWxGSTtBQW1GUEUsRUFBQUEsT0FBTyxFQUFFLG1CQUFZO0FBRXBCYixJQUFBQSxDQUFDLENBQUNRLElBQUYsR0FBUyxDQUFUOztBQUNFLFFBQUtSLENBQUMsQ0FBQ1EsSUFBRixJQUFTLENBQVQsR0FBYVIsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBeEIsR0FBMkJULENBQUMsQ0FBQ08sR0FBRixJQUFRLElBQXhDLEVBQTZDO0FBQUMsVUFBR1AsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUFXO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXBFLE1BQXlFLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDekg7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEZ0UsTUFDM0QsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDLEtBRnhELE1BRTZEO0FBQUMsVUFBS1gsQ0FBQyxDQUFDUSxJQUFGLElBQVUsQ0FBVixHQUFjUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF6QixHQUE0QlQsQ0FBQyxDQUFDTyxHQUFGLElBQVMsSUFBMUMsRUFBK0M7QUFBQyxhQUFLaEIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBeEcsTUFBNkcsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM3SztBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURvSCxNQUMvRyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUM7O0FBQUE7QUFDeEQsR0EzRkk7QUE0RlBHLEVBQUFBLE9BQU8sRUFBRSxtQkFBWTtBQUVwQmQsSUFBQUEsQ0FBQyxDQUFDUSxJQUFGLEdBQVMsQ0FBVDs7QUFDRSxRQUFLUixDQUFDLENBQUNRLElBQUYsSUFBUyxDQUFULEdBQWFSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXhCLEdBQTJCVCxDQUFDLENBQUNPLEdBQUYsSUFBUSxJQUF4QyxFQUE2QztBQUFDLFVBQUdQLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFBVztBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUFwRSxNQUF5RSxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQ3pIO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRGdFLE1BQzNELElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQyxLQUZ4RCxNQUU2RDtBQUFDLFVBQUtYLENBQUMsQ0FBQ1EsSUFBRixJQUFVLENBQVYsR0FBY1IsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBekIsR0FBNEJULENBQUMsQ0FBQ08sR0FBRixJQUFTLElBQTFDLEVBQStDO0FBQUMsYUFBS2hCLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXhHLE1BQTZHLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDN0s7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEb0gsTUFDL0csSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDOztBQUFBO0FBRXhELEdBckdJO0FBc0dSSSxFQUFBQSxLQUFLLEVBQUUsaUJBQVk7QUFFakJmLElBQUFBLENBQUMsQ0FBQ1UsRUFBRixHQUFPLENBQVA7O0FBQ0csUUFBS1YsQ0FBQyxDQUFDUSxJQUFGLElBQVMsQ0FBVCxHQUFhUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF4QixHQUEyQlQsQ0FBQyxDQUFDTyxHQUFGLElBQVEsSUFBeEMsRUFBNkM7QUFBQyxVQUFHUCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQVc7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBcEUsTUFBeUUsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUMxSDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURpRSxNQUM1RCxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUMsS0FGdkQsTUFFNEQ7QUFBQyxVQUFLWCxDQUFDLENBQUNRLElBQUYsSUFBVSxDQUFWLEdBQWNSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXpCLEdBQTRCVCxDQUFDLENBQUNPLEdBQUYsSUFBUyxJQUExQyxFQUErQztBQUFDLGFBQUtoQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUF4RyxNQUE2RyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzdLO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRG9ILE1BQy9HLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQzs7QUFBQTtBQUV4RCxHQS9HSTtBQWdIUkssRUFBQUEsS0FBSyxFQUFFLGlCQUFZO0FBRWpCaEIsSUFBQUEsQ0FBQyxDQUFDVSxFQUFGLEdBQU8sQ0FBUDs7QUFDRSxRQUFLVixDQUFDLENBQUNRLElBQUYsSUFBUyxDQUFULEdBQWFSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXhCLEdBQTJCVCxDQUFDLENBQUNPLEdBQUYsSUFBUSxJQUF4QyxFQUE2QztBQUFDLFVBQUdQLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFBVztBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUFwRSxNQUF5RSxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQ3pIO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRGdFLE1BQzNELElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQyxLQUZ4RCxNQUU2RDtBQUFDLFVBQUtYLENBQUMsQ0FBQ1EsSUFBRixJQUFVLENBQVYsR0FBY1IsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBekIsR0FBNEJULENBQUMsQ0FBQ08sR0FBRixJQUFTLElBQTFDLEVBQStDO0FBQUMsYUFBS2hCLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXhHLE1BQTZHLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDN0s7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEb0gsTUFDL0csSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDOztBQUFBO0FBRXhELEdBekhJO0FBMEhSTSxFQUFBQSxLQUFLLEVBQUUsaUJBQVk7QUFFakJqQixJQUFBQSxDQUFDLENBQUNVLEVBQUYsR0FBTyxDQUFQOztBQUNHLFFBQUtWLENBQUMsQ0FBQ1EsSUFBRixJQUFTLENBQVQsR0FBYVIsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBeEIsR0FBMkJULENBQUMsQ0FBQ08sR0FBRixJQUFRLElBQXhDLEVBQTZDO0FBQUMsVUFBR1AsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUFXO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXBFLE1BQXlFLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDMUg7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEaUUsTUFDNUQsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDLEtBRnZELE1BRTREO0FBQUMsVUFBS1gsQ0FBQyxDQUFDUSxJQUFGLElBQVUsQ0FBVixHQUFjUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF6QixHQUE0QlQsQ0FBQyxDQUFDTyxHQUFGLElBQVMsSUFBMUMsRUFBK0M7QUFBQyxhQUFLaEIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBeEcsTUFBNkcsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM3SztBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURvSCxNQUMvRyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUM7O0FBQUE7QUFDeEQsR0FsSUk7QUFtSVBPLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUVuQmxCLElBQUFBLENBQUMsQ0FBQ1MsTUFBRixHQUFXLENBQVg7O0FBQ0UsUUFBS1QsQ0FBQyxDQUFDUSxJQUFGLElBQVMsQ0FBVCxHQUFhUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF4QixHQUEyQlQsQ0FBQyxDQUFDTyxHQUFGLElBQVEsSUFBeEMsRUFBNkM7QUFBQ1ksTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksUUFBWjs7QUFBc0IsVUFBR3BCLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFBVztBQUFDUyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxRQUFaO0FBQXNCLGFBQUs3QixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUExRixNQUErRixJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQ3JLO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRDRHLE1BQ3ZHLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQyxLQUZ4RCxNQUU2RDtBQUFDLFVBQUtYLENBQUMsQ0FBQ1EsSUFBRixJQUFVLENBQVYsR0FBY1IsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBekIsR0FBNEJULENBQUMsQ0FBQ08sR0FBRixJQUFTLElBQTFDLEVBQStDO0FBQUMsYUFBS2hCLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXhHLE1BQTZHLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDN0s7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEb0gsTUFDL0csSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDOztBQUFBO0FBQ3hELEdBM0lJO0FBNElSVSxFQUFBQSxNQUFNLEVBQUUsa0JBQVksQ0FHaEIsQ0EvSUk7QUFnSlBDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUVuQnRCLElBQUFBLENBQUMsQ0FBQ1MsTUFBRixHQUFXLENBQVg7O0FBQ0UsUUFBS1QsQ0FBQyxDQUFDUSxJQUFGLElBQVMsQ0FBVCxHQUFhUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF4QixHQUEyQlQsQ0FBQyxDQUFDTyxHQUFGLElBQVEsSUFBeEMsRUFBNkM7QUFBQyxVQUFHUCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQVc7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBcEUsTUFBeUUsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUN6SDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURnRSxNQUMzRCxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUMsS0FGeEQsTUFFNkQ7QUFBQyxVQUFLWCxDQUFDLENBQUNRLElBQUYsSUFBVSxDQUFWLEdBQWNSLENBQUMsQ0FBQ1MsTUFBRixJQUFXLENBQXpCLEdBQTRCVCxDQUFDLENBQUNPLEdBQUYsSUFBUyxJQUExQyxFQUErQztBQUFDLGFBQUtoQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQUF4RyxNQUE2RyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzdLO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BRG9ILE1BQy9HLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDOUQ7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0Q7QUFBQzs7QUFBQTtBQUV4RCxHQXpKSTtBQTBKUlksRUFBQUEsS0FBSyxFQUFFLGlCQUFZO0FBQ2QsUUFBS3ZCLENBQUMsQ0FBQ1EsSUFBRixJQUFTLENBQVQsR0FBYVIsQ0FBQyxDQUFDUyxNQUFGLElBQVcsQ0FBeEIsR0FBMkJULENBQUMsQ0FBQ08sR0FBRixJQUFRLElBQXhDLEVBQTZDO0FBQUMsVUFBR1AsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUFXO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdELE9BQXBFLE1BQXlFLElBQUdYLENBQUMsQ0FBQ1UsRUFBRixJQUFNLENBQVQsRUFDMUg7QUFBQyxhQUFLbkIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FEaUUsTUFDNUQsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM5RDtBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RDtBQUFDLEtBRnZELE1BRTREO0FBQUMsVUFBS1gsQ0FBQyxDQUFDUSxJQUFGLElBQVUsQ0FBVixHQUFjUixDQUFDLENBQUNTLE1BQUYsSUFBVyxDQUF6QixHQUE0QlQsQ0FBQyxDQUFDTyxHQUFGLElBQVMsSUFBMUMsRUFBK0M7QUFBQyxhQUFLaEIsT0FBTCxDQUFhb0IsV0FBYixHQUEyQixLQUFLYixRQUFMLENBQWMsQ0FBZCxFQUFpQmEsV0FBNUM7QUFBd0QsT0FBeEcsTUFBNkcsSUFBR1gsQ0FBQyxDQUFDVSxFQUFGLElBQU0sQ0FBVCxFQUM3SztBQUFDLGFBQUtuQixPQUFMLENBQWFvQixXQUFiLEdBQTJCLEtBQUtiLFFBQUwsQ0FBYyxDQUFkLEVBQWlCYSxXQUE1QztBQUF3RCxPQURvSCxNQUMvRyxJQUFHWCxDQUFDLENBQUNVLEVBQUYsSUFBTSxDQUFULEVBQzlEO0FBQUMsYUFBS25CLE9BQUwsQ0FBYW9CLFdBQWIsR0FBMkIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTVDO0FBQXdEO0FBQUM7O0FBQUE7QUFDeEQsR0FoS0k7QUFpS1RhLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNaeEMsSUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLFlBQXRCO0FBQ05KLElBQUFBLENBQUMsQ0FBQ3lCLEdBQUYsR0FBUSxJQUFSO0FBQ0Z6QixJQUFBQSxDQUFDLENBQUMwQixPQUFGLEdBQVUsQ0FBVjtBQUNBMUIsSUFBQUEsQ0FBQyxDQUFDMkIsT0FBRixHQUFVLENBQVY7QUFDQTNCLElBQUFBLENBQUMsQ0FBQzRCLE9BQUYsR0FBVSxDQUFWO0FBQ0E1QixJQUFBQSxDQUFDLENBQUM2QixHQUFGLEdBQU0sQ0FBTjtBQUNBN0IsSUFBQUEsQ0FBQyxDQUFDOEIsTUFBRixHQUFTLElBQVQ7QUFDQTlCLElBQUFBLENBQUMsQ0FBQytCLEtBQUYsR0FBUSxJQUFSO0FBQ0EvQixJQUFBQSxDQUFDLENBQUNnQyxTQUFGLEdBQVksQ0FBWjtBQUNBaEMsSUFBQUEsQ0FBQyxDQUFDaUMsUUFBRixHQUFXLENBQVg7QUFDQWpDLElBQUFBLENBQUMsQ0FBQ2tDLEdBQUYsR0FBTSxDQUFOO0FBQ0FsQyxJQUFBQSxDQUFDLENBQUNtQyxHQUFGLEdBQU0sQ0FBTjtBQUNBbkMsSUFBQUEsQ0FBQyxDQUFDb0MsR0FBRixHQUFNLENBQU47QUFDQXBDLElBQUFBLENBQUMsQ0FBQ3FDLEdBQUYsR0FBTSxDQUFOO0FBQ0FyQyxJQUFBQSxDQUFDLENBQUNzQyxHQUFGLEdBQU0sQ0FBTjtBQUNBdEMsSUFBQUEsQ0FBQyxDQUFDdUMsR0FBRixHQUFNLENBQU47QUFDQXZDLElBQUFBLENBQUMsQ0FBQ3dDLEtBQUY7QUFDQXhDLElBQUFBLENBQUMsQ0FBQ1EsSUFBRixHQUFPLENBQVA7QUFDQVIsSUFBQUEsQ0FBQyxDQUFDeUMsUUFBRjtBQUNBekMsSUFBQUEsQ0FBQyxDQUFDTyxHQUFGLEdBQU0sSUFBTjtBQUNBUCxJQUFBQSxDQUFDLENBQUNNLEdBQUYsR0FBTSxLQUFOO0FBQ0FOLElBQUFBLENBQUMsQ0FBQzBDLEVBQUYsR0FBSyxDQUFMO0FBQ0ExQyxJQUFBQSxDQUFDLENBQUNVLEVBQUYsR0FBSyxDQUFMO0FBQ0FWLElBQUFBLENBQUMsQ0FBQ0MsRUFBRixHQUFLLENBQUw7QUFDSyxHQTFMSTtBQTJMUjBDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNiM0QsSUFBQUEsRUFBRSxDQUFDbUIsUUFBSCxDQUFZQyxTQUFaLENBQXNCLE1BQXRCO0FBQ0gsR0E3TEk7QUErTFJ3QyxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDZjVDLElBQUFBLENBQUMsQ0FBQ0MsRUFBRixHQUFLLENBQUw7QUFDRCxHQWpNSTtBQWtNUjRDLEVBQUFBLElBQUksRUFBRSxnQkFBWTtBQUNsQjdDLElBQUFBLENBQUMsQ0FBQ0MsRUFBRixHQUFLLENBQUw7QUFFSSxHQXJNSTtBQXNNUjZDLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNwQixTQUFLbkQsT0FBTCxDQUFhb0QsR0FBYixHQUFpQixtRkFBakI7QUFFSSxHQXpNSTtBQTBNUkMsRUFBQUEsTUFBTSxFQUFFLGtCQUFZO0FBQ3BCLFNBQUtyRCxPQUFMLENBQWFvRCxHQUFiLEdBQWlCLG1GQUFqQjtBQUVJLEdBN01JO0FBOE1SRSxFQUFBQSxNQUFNLEVBQUUsa0JBQVk7QUFDcEIsU0FBS3RELE9BQUwsQ0FBYW9ELEdBQWIsR0FBaUIsbUZBQWpCO0FBRUksR0FqTkk7QUFrTkpHLEVBQUFBLElBQUksRUFBRSxnQkFBWTtBQUNwQixTQUFLOUQsTUFBTCxDQUFZK0QsS0FBWixJQUFxQixFQUFyQjtBQUNBbkQsSUFBQUEsQ0FBQyxDQUFDMkIsT0FBRixJQUFZLENBQVo7O0FBQ0EsUUFBRzNCLENBQUMsQ0FBQzJCLE9BQUYsSUFBYSxDQUFDLENBQWpCLEVBQW1CO0FBQUMzQixNQUFBQSxDQUFDLENBQUMyQixPQUFGLEdBQVUsRUFBVjtBQUFjO0FBQUMsR0FyTjdCO0FBc05QeUIsRUFBQUEsTUFBTSxFQUFFLGtCQUFZO0FBQ25CcEQsSUFBQUEsQ0FBQyxDQUFDeUIsR0FBRixHQUFRLElBQVI7QUFBYyxHQXZOUjtBQXdOTjRCLEVBQUFBLE1BQU0sRUFBRSxrQkFBWTtBQUNwQnJELElBQUFBLENBQUMsQ0FBQ3lCLEdBQUYsR0FBUSxLQUFSO0FBQ0NOLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEtBQVo7QUFBb0IsR0ExTmY7QUEyTk5rQyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDZHRELElBQUFBLENBQUMsQ0FBQzBCLE9BQUYsR0FBVSxDQUFWO0FBQ0gsU0FBS3RDLE1BQUwsQ0FBWXVCLFdBQVosR0FBMEIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTNDO0FBQ0UsR0E5Tkk7QUErTk40QyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDWnZELElBQUFBLENBQUMsQ0FBQzBCLE9BQUYsR0FBVSxDQUFWO0FBQ1AsU0FBS3RDLE1BQUwsQ0FBWXVCLFdBQVosR0FBMEIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTNDO0FBQ0ksR0FsT0k7QUFtT042QyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDWnhELElBQUFBLENBQUMsQ0FBQzBCLE9BQUYsR0FBVSxDQUFWO0FBQ04sU0FBS3RDLE1BQUwsQ0FBWXVCLFdBQVosR0FBMEIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTNDO0FBQ0csR0F0T0k7QUF1T044QyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDYnpELElBQUFBLENBQUMsQ0FBQzBCLE9BQUYsR0FBVSxDQUFWO0FBQ0gsU0FBS3RDLE1BQUwsQ0FBWXVCLFdBQVosR0FBMEIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTNDO0FBQ0MsR0ExT0k7QUEyT04rQyxFQUFBQSxJQUFJLEVBQUUsZ0JBQVc7QUFDWjFELElBQUFBLENBQUMsQ0FBQzBCLE9BQUYsR0FBVSxDQUFWO0FBQ04sU0FBS3RDLE1BQUwsQ0FBWXVCLFdBQVosR0FBMEIsS0FBS2IsUUFBTCxDQUFjLENBQWQsRUFBaUJhLFdBQTNDO0FBQ0csR0E5T0k7QUFnUFJnRCxFQUFBQSxLQUFLLEVBQUUsaUJBQVk7QUFDakIsU0FBS3ZFLE1BQUwsQ0FBWStELEtBQVosSUFBcUIsRUFBckI7QUFDQW5ELElBQUFBLENBQUMsQ0FBQzJCLE9BQUYsSUFBWSxDQUFaOztBQUNBLFFBQUczQixDQUFDLENBQUMyQixPQUFGLElBQWEsRUFBaEIsRUFBbUI7QUFBQzNCLE1BQUFBLENBQUMsQ0FBQzJCLE9BQUYsR0FBVSxDQUFWO0FBQWE7QUFDaEMsR0FwUEs7QUFzUFRpQyxFQUFBQSxPQUFPLEVBQUUsbUJBQVk7QUFDZDVFLElBQUFBLEVBQUUsQ0FBQ21CLFFBQUgsQ0FBWUMsU0FBWixDQUFzQixTQUF0QjtBQUNGLEdBeFBJLENBNlBMO0FBQ0E7O0FBOVBLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuXHRcclxuXHRwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsICAgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgICBzZXJpYWxpemFibGU6IHRydWUsICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gYmFyOiB7XHJcbiAgICAgICAgLy8gICAgIGdldCAoKSB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xyXG4gICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgIC8vICAgICBzZXQgKHZhbHVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0sXHJcblx0XHRcclxuXHRcdHBsYXllcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5TcHJpdGUsXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlLFxyXG4gICAgICAgIH0sXHJcblx0XHRcdHBsYXllcjM6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlLFxyXG4gICAgICAgIH0sXHJcblx0XHRcdHBsYXllcjQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlLFxyXG4gICAgICAgIH0sXHJcblx0XHRcdHBsYXllcjU6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuU3ByaXRlLFxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXI2OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLldlYlZpZXcsXHJcbiAgICAgICAgfSxcclxuXHRcdCBpbWdJZHggOiAxLFxyXG4gc3ByQXJyYXkgOntcclxuICAgICAgICAgICAgZGVmYXVsdDpbXSxcclxuICAgICAgICAgICAgdHlwZTpjYy5TcHJpdGUsXHJcbiAgICAgICAgfSxcclxuXHRcdFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyBMSUZFLUNZQ0xFIENBTExCQUNLUzpcclxuXHJcbiAgICAvLyBvbkxvYWQgKCkge30sXHJcblxyXG4gICAgc3RhcnQgKCkge1xyXG5HLnB0ID0xO1xyXG4gIH0sXHJcbiAgIHRvbmV3OiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgaWYoRy5wdD09MSl7Y2MuZGlyZWN0b3IubG9hZFNjZW5lKFwiTmV3IFNjZW5lXCIpfWVsc2V7aWYoRy5wdD09Mil7Y2MuZGlyZWN0b3IubG9hZFNjZW5lKFwib3NcIil9fTtcclxuICAgIH0sXHJcblx0IHRvY2gxOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgXHJcblx0XHQgRy5jaDIgPSBmYWxzZTtcclxuXHRcdCAgRy5jaDEgPSB0cnVlO1xyXG5cdFx0ICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuICAgIH0sXHJcblx0IHRvY2gyOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgXHJcblx0XHQgRy5jaDEgPSBmYWxzZTtcclxuXHRcdCAgRy5jaDIgPSB0cnVlO1xyXG5cdFx0ICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuICAgIH0sXHJcblx0IHRvbW9kZTE6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuXHRcdCBHLm1vZGUgPSAxO1xyXG5cdFx0ICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuICAgIH0sXHJcblx0IHRvbW9kZTI6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuXHRcdCBHLm1vZGUgPSAyO1xyXG5cdFx0ICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuXHRcdCAgXHJcbiAgICB9LCBcclxuXHR0b3ZvMTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIFxyXG5cdFx0IEcuVk8gPSAxO1xyXG5cdFx0ICAgIGlmICggRy5tb2RlID09MSAmIEcuc291cmNlID09MSAmRy5jaDEgPT10cnVlKXtpZihHLlZPPT0xKXt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzFdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MilcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzJdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MylcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzNdLnNwcml0ZUZyYW1lfX1lbHNlIHtpZiAoIEcubW9kZSA9PSAxICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PSB0cnVlKXt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzFdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MilcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzJdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MylcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzNdLnNwcml0ZUZyYW1lfX07XHJcblx0XHQgIFxyXG4gICAgfSxcclxuXHR0b3ZvMjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIFxyXG5cdFx0IEcuVk8gPSAyO1xyXG5cdFx0ICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuXHRcdCAgXHJcbiAgICB9LFxyXG5cdHRvdm8zOiBmdW5jdGlvbiAoKSB7XHJcbiAgICAgICAgXHJcblx0XHQgRy5WTyA9IDM7XHJcblx0XHQgICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuICAgIH0sXHJcblx0IHRvc291MTogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIFxyXG5cdFx0IEcuc291cmNlID0gMTtcclxuXHRcdCAgIGlmICggRy5tb2RlID09MSAmIEcuc291cmNlID09MSAmRy5jaDEgPT10cnVlKXtjb25zb2xlLmxvZyhcImRhc2Rhc1wiKTtpZihHLlZPPT0xKXtjb25zb2xlLmxvZyhcImRhc2Rhc1wiKTt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzFdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MilcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzJdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MylcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzNdLnNwcml0ZUZyYW1lfX1lbHNlIHtpZiAoIEcubW9kZSA9PSAxICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PSB0cnVlKXt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzFdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MilcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzJdLnNwcml0ZUZyYW1lfWVsc2UgaWYoRy5WTz09MylcclxuXHQgIHt0aGlzLnBsYXllcjIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzNdLnNwcml0ZUZyYW1lfX07XHJcbiAgICB9LFxyXG5cdHNsaWRlcjogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgXHJcblx0XHJcbiAgICB9LFxyXG5cdCB0b3NvdTI6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgICBcclxuXHRcdCBHLnNvdXJjZSA9IDI7XHJcblx0XHQgICBpZiAoIEcubW9kZSA9PTEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09dHJ1ZSl7aWYoRy5WTz09MSl7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVsxXS5zcHJpdGVGcmFtZX1lbHNlIGlmKEcuVk89PTIpXHJcblx0ICB7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVsyXS5zcHJpdGVGcmFtZX1lbHNlIGlmKEcuVk89PTMpXHJcblx0ICB7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVszXS5zcHJpdGVGcmFtZX19ZWxzZSB7aWYgKCBHLm1vZGUgPT0gMSAmIEcuc291cmNlID09MSAmRy5jaDEgPT0gdHJ1ZSl7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVsxXS5zcHJpdGVGcmFtZX1lbHNlIGlmKEcuVk89PTIpXHJcblx0ICB7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVsyXS5zcHJpdGVGcmFtZX1lbHNlIGlmKEcuVk89PTMpXHJcblx0ICB7dGhpcy5wbGF5ZXIyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVszXS5zcHJpdGVGcmFtZX19O1xyXG5cdFx0ICBcclxuICAgIH0sXHJcblx0bmV3b3M6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgaWYgKCBHLm1vZGUgPT0xICYgRy5zb3VyY2UgPT0xICZHLmNoMSA9PXRydWUpe2lmKEcuVk89PTEpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fWVsc2Uge2lmICggRy5tb2RlID09IDEgJiBHLnNvdXJjZSA9PTEgJkcuY2gxID09IHRydWUpe3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMV0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0yKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMl0uc3ByaXRlRnJhbWV9ZWxzZSBpZihHLlZPPT0zKVxyXG5cdCAge3RoaXMucGxheWVyMi5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWV9fTtcclxuICAgIH0sXHJcbnRvbG9nbzogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcImhlbGxvd29ybGRcIik7XHJcblx0XHRHLnJlZCA9IHRydWU7XHJcbkcueGlhbmdtdT0xO1xyXG5HLmRhbmd3ZWk9MDtcclxuRy54aWFuc2hpPTE7XHJcbkcudGlwPTE7XHJcbkcuaG9uZ2JpPW51bGw7XHJcbkcuaGVpYmk9bnVsbDtcclxuRy5ob25nYml5ZXM9MDtcclxuRy5oZWliaXllcz0wO1xyXG5HLmJ0cj0wO1xyXG5HLmJ0Yj0wO1xyXG5HLnJ0cj0wO1xyXG5HLnJ0Yj0wO1xyXG5HLnhscz0wO1xyXG5HLnJ0Zz0wO1xyXG5HLmJ0Z1YwO1xyXG5HLm1vZGU9MTtcclxuRy5zb3VyY2VWMTtcclxuRy5jaDE9dHJ1ZTtcclxuRy5jaDI9ZmFsc2U7XHJcbkcucHA9MDtcclxuRy5WTz0xO1xyXG5HLnB0PTE7XHJcbiAgICB9LFxyXG5cdHRvaGVscDogZnVuY3Rpb24gKCkge1xyXG4gICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcImhlbHBcIik7XHJcbiAgICB9LFxyXG5cdFxyXG5cdHRvbWlsaTogZnVuY3Rpb24gKCkge1xyXG4gICAgICBHLnB0PTE7XHJcbiAgICB9LFxyXG5cdHRvb3M6IGZ1bmN0aW9uICgpIHtcclxuXHRHLnB0PTI7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG5cdHRvd2ViMTogZnVuY3Rpb24gKCkge1xyXG5cdHRoaXMucGxheWVyNi5Vcmw9XCJodHRwczovL3d3dy5iaWxpYmlsaS5jb20vdmlkZW8vQlYxR3g0MTF6N3gyP2Zyb209c2VhcmNoJnNlaWQ9MTQ3MDQzNDI2NjUwODMxMDUxMjJcIjtcclxuICAgICAgICBcclxuICAgIH0sXHJcblx0dG93ZWIyOiBmdW5jdGlvbiAoKSB7XHJcblx0dGhpcy5wbGF5ZXI2LlVybD1cImh0dHBzOi8vd3d3LmJpbGliaWxpLmNvbS92aWRlby9CVjFRNDQxMWY3UVI/ZnJvbT1zZWFyY2gmc2VpZD0xMDY2MDY3NzY2MzU1MDc3NzkwOVwiO1xyXG4gICAgICAgIFxyXG4gICAgfSxcclxuXHR0b3dlYjM6IGZ1bmN0aW9uICgpIHtcclxuXHR0aGlzLnBsYXllcjYuVXJsPVwiaHR0cHM6Ly93d3cuYmlsaWJpbGkuY29tL3ZpZGVvL0JWMXVXNDExZzc2Vj9mcm9tPXNlYXJjaCZzZWlkPTEwNjYwNjc3NjYzNTUwNzc3OTA5XCI7XHJcbiAgICAgICAgXHJcbiAgICB9LFxyXG4gICAgIHRvcm86IGZ1bmN0aW9uICgpIHtcclxuXHQgIHRoaXMucGxheWVyLmFuZ2VsIC09IDE4O1xyXG5cdCAgRy5kYW5nd2VpIC09MTtcclxuXHQgIGlmKEcuZGFuZ3dlaSA9PSAtMSl7Ry5kYW5nd2VpPTE5O319LFxyXG5cdCB0b3JlZDE6IGZ1bmN0aW9uICgpIHtcclxuXHQgIEcucmVkID0gdHJ1ZTt9LFxyXG5cdCAgdG9yZWQyOiBmdW5jdGlvbiAoKSB7XHJcblx0ICBHLnJlZCA9IGZhbHNlO1xyXG5cdCAgIGNvbnNvbGUubG9nKFwic2hpXCIpO30sXHJcblx0ICB0b3gxOiBmdW5jdGlvbiAoKXtcclxuICAgICAgRy54aWFuZ211PTE7XHJcblx0ICB0aGlzLnBsYXllci5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbMF0uc3ByaXRlRnJhbWVcclxuICAgIH0sXHJcblx0ICB0b3gyOiBmdW5jdGlvbiAoKXtcclxuICAgICAgICBHLnhpYW5nbXU9MjsgIFxyXG5cdHRoaXMucGxheWVyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVsxXS5zcHJpdGVGcmFtZVxyXG4gICAgfSxcclxuXHQgIHRveDM6IGZ1bmN0aW9uICgpe1xyXG4gICAgICAgIEcueGlhbmdtdT0zO1xyXG5cdFx0dGhpcy5wbGF5ZXIuc3ByaXRlRnJhbWUgPSB0aGlzLnNwckFycmF5WzJdLnNwcml0ZUZyYW1lXHJcbiAgICB9LFxyXG5cdCAgdG94NDogZnVuY3Rpb24gKCl7XHJcbiAgICAgICBHLnhpYW5nbXU9NDtcclxuXHQgICB0aGlzLnBsYXllci5zcHJpdGVGcmFtZSA9IHRoaXMuc3ByQXJyYXlbM10uc3ByaXRlRnJhbWVcclxuICAgIH0sXHJcblx0ICB0b3g1OiBmdW5jdGlvbiAoKXtcclxuICAgICAgICBHLnhpYW5nbXU9NTtcclxuXHRcdHRoaXMucGxheWVyLnNwcml0ZUZyYW1lID0gdGhpcy5zcHJBcnJheVs0XS5zcHJpdGVGcmFtZVxyXG4gICAgfSxcclxuXHQgIFxyXG4gdG9ybzI6IGZ1bmN0aW9uICgpIHtcclxuXHQgIHRoaXMucGxheWVyLmFuZ2VsICs9IDE4O1xyXG5cdCAgRy5kYW5nd2VpICs9MTtcclxuXHQgIGlmKEcuZGFuZ3dlaSA9PSAyMCl7Ry5kYW5nd2VpPTA7fVxyXG5cdCAgfSxcclxuXHQgXHJcbnRvaGVscDI6IGZ1bmN0aW9uICgpIHtcclxuICAgICAgIGNjLmRpcmVjdG9yLmxvYWRTY2VuZShcImhlbHAtMjJcIik7XHJcbiAgICB9LFxyXG5cclxuXHJcblxyXG5cdCBcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG4gICAgLy8gdXBkYXRlIChkdCkge30sXHJcbn0pO1xyXG4iXX0=
//------QC-SOURCE-SPLIT------

                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/tip2.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6419asQFxJHr6sGmlk9wlRC', 'tip2');
// Script/tip2.js

"use strict";

var tp = cc.Class({
  "extends": cc.Component,
  ts: function ts() {
    if (G.tip = 1) {
      G.xianshi = '将黑红表笔放置到加亮的标记处';
    }

    ;

    if (G.tip = 2) {
      G.xianshi = '数字式万用表的红表笔接正极';
    }

    ;

    if (G.tip = 3) {
      G.xianshi = '当前量程过大';
    }

    if (G.tip = 4) {
      G.xianshi = '当前量程过小';
    }

    if (G.tip = 5) {
      G.xianshi = '通路';
    }

    if (G.tip = 6) {
      G.xianshi = '当前量程档位错误';
    }

    if (G.tip = 7) {
      G.xianshi = '万用表关闭时选择关闭档或者电压最高档';
    }

    if (G.tip = 8) {
      G.xianshi = '测量高电压时使用错误档位会造成危险';
    }

    if (G.tip = 9) {
      G.xianshi = '测量电压时红表笔选择电流档会损坏万用表';
    }

    if (G.tip = 10) {
      G.xianshi = '当前红表笔档位错误';
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFx0aXAyLmpzIl0sIm5hbWVzIjpbInRwIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInRzIiwiRyIsInRpcCIsInhpYW5zaGkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsRUFBRSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNsQixhQUFTRCxFQUFFLENBQUNFLFNBRE07QUFHbEJDLEVBQUFBLEVBQUUsRUFBQyxjQUFVO0FBRWIsUUFBR0MsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLGdCQUFaO0FBQTZCOztBQUFBOztBQUM3QyxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVksZUFBWjtBQUE2Qjs7QUFBQTs7QUFDN0MsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLFFBQVo7QUFBc0I7O0FBQ3RDLFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVgsRUFBYTtBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxRQUFaO0FBQXNCOztBQUN0QyxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVksSUFBWjtBQUFrQjs7QUFDbEMsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLFVBQVo7QUFBd0I7O0FBQ3hDLFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVgsRUFBYTtBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxvQkFBWjtBQUFrQzs7QUFDbEQsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLG1CQUFaO0FBQWlDOztBQUNqRCxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVkscUJBQVo7QUFBbUM7O0FBQ25ELFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLEVBQVgsRUFBYztBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxXQUFaO0FBQXlCO0FBQ3pDO0FBZmlCLENBQVQsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIHRwID0gY2MuQ2xhc3Moe1xyXG5leHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG50czpmdW5jdGlvbigpe1xyXG4gICBcclxuaWYoRy50aXAgPSAxKXsgIEcueGlhbnNoaSA9ICflsIbpu5HnuqLooajnrJTmlL7nva7liLDliqDkuq7nmoTmoIforrDlpIQnfTtcclxuaWYoRy50aXAgPSAyKXsgIEcueGlhbnNoaSA9ICfmlbDlrZflvI/kuIfnlKjooajnmoTnuqLooajnrJTmjqXmraPmnoEnO307XHJcbmlmKEcudGlwID0gMyl7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL6L+H5aSnJzt9XHJcbmlmKEcudGlwID0gNCl7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL6L+H5bCPJzt9XHJcbmlmKEcudGlwID0gNSl7ICBHLnhpYW5zaGkgPSAn6YCa6LevJzt9XHJcbmlmKEcudGlwID0gNil7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJzt9XHJcbmlmKEcudGlwID0gNyl7ICBHLnhpYW5zaGkgPSAn5LiH55So6KGo5YWz6Zet5pe26YCJ5oup5YWz6Zet5qGj5oiW6ICF55S15Y6L5pyA6auY5qGjJzt9XHJcbmlmKEcudGlwID0gOCl7ICBHLnhpYW5zaGkgPSAn5rWL6YeP6auY55S15Y6L5pe25L2/55So6ZSZ6K+v5qGj5L2N5Lya6YCg5oiQ5Y2x6ZmpJzt9XHJcbmlmKEcudGlwID0gOSl7ICBHLnhpYW5zaGkgPSAn5rWL6YeP55S15Y6L5pe257qi6KGo56yU6YCJ5oup55S15rWB5qGj5Lya5o2f5Z2P5LiH55So6KGoJzt9XHJcbmlmKEcudGlwID0gMTApeyAgRy54aWFuc2hpID0gJ+W9k+WJjee6ouihqOeslOaho+S9jemUmeivryc7fVxyXG59XHJcblxyXG5cclxufSk7XHJcblxyXG4iXX0=
//------QC-SOURCE-SPLIT------
