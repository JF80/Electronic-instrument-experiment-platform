
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/huaxian.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '4ff717BZCpMQZb6oaFScaaP', 'huaxian');
// Script/huaxian.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    mainCanvas: cc.Node,
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {//var apx = 1;
    //console.log(tmpPath)
  },
  start: function start() {
    console.log("SASDA");
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
    this.player2.on(cc.Node.EventType.START, function (t) {
      this.fu();
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      this.fu();
    }, this);
  },
  fu: function fu() {
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    this.mainContext.clear();
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxodWF4aWFuLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwibWFpbkNhbnZhcyIsIk5vZGUiLCJwbGF5ZXIiLCJ0eXBlIiwicGxheWVyMiIsIm9uTG9hZCIsInN0YXJ0IiwiY29uc29sZSIsImxvZyIsIm1haW5Db250ZXh0IiwiZ2V0Q29tcG9uZW50IiwiR3JhcGhpY3MiLCJhcCIsImNvbnZlcnRUb1dvcmxkU3BhY2VBUiIsInYyIiwiYnAiLCJhcHgiLCJ4IiwiYXB5IiwieSIsIm1vdmVUbyIsImJweCIsImJweSIsImxpbmVUbyIsInN0cm9rZSIsIm9uIiwiRXZlbnRUeXBlIiwiU1RBUlQiLCJ0IiwiZnUiLCJUT1VDSF9NT1ZFIiwiY2xlYXIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSQyxJQUFBQSxVQUFVLEVBQUVKLEVBQUUsQ0FBQ0ssSUFEUDtBQUVkQyxJQUFBQSxNQUFNLEVBQUU7QUFDRSxpQkFBUyxJQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRVAsRUFBRSxDQUFDSztBQUZYLEtBRk07QUFNZEcsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDRCxNQUFBQSxJQUFJLEVBQUVQLEVBQUUsQ0FBQ0s7QUFGVjtBQU5LLEdBSFA7QUFpQkw7QUFFQUksRUFBQUEsTUFuQkssb0JBbUJLLENBRVo7QUFJQTtBQUVBLEdBM0JPO0FBNkJMQyxFQUFBQSxLQTdCSyxtQkE2Qkk7QUFBQ0MsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUFzQixTQUFLQyxXQUFMLEdBQW1CLEtBQUtULFVBQUwsQ0FBZ0JVLFlBQWhCLENBQTZCZCxFQUFFLENBQUNlLFFBQWhDLENBQW5CO0FBRWxDSixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsUUFBSUksRUFBRSxHQUFHLEtBQUtWLE1BQUwsQ0FBWVcscUJBQVosQ0FBa0NqQixFQUFFLENBQUNrQixFQUFILENBQU0sQ0FBTixFQUFRLENBQVIsQ0FBbEMsQ0FBVDtBQUNBLFFBQUlDLEVBQUUsR0FBRyxLQUFLWCxPQUFMLENBQWFTLHFCQUFiLENBQW1DakIsRUFBRSxDQUFDa0IsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQW5DLENBQVQ7QUFDQVAsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNHLFFBQUlRLEdBQUcsR0FBR0osRUFBRSxDQUFDSyxDQUFiO0FBQ0gsUUFBSUMsR0FBRyxHQUFHTixFQUFFLENBQUNPLENBQWI7QUFDTSxTQUFLVixXQUFMLENBQWlCVyxNQUFqQixDQUF3QkosR0FBeEIsRUFBNEJFLEdBQTVCO0FBQ05YLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE1BQVo7QUFFQUQsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlPLEVBQUUsQ0FBQ0UsQ0FBZjtBQUNBLFFBQUlJLEdBQUcsR0FBR04sRUFBRSxDQUFDRSxDQUFILEdBQU0sRUFBaEI7QUFFQSxRQUFJSyxHQUFHLEdBQUdQLEVBQUUsQ0FBQ0ksQ0FBSCxHQUFNLEVBQWhCO0FBQ00sU0FBS1YsV0FBTCxDQUFpQmMsTUFBakIsQ0FBd0JGLEdBQXhCLEVBQTRCQyxHQUE1QjtBQUNOZixJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0MsUUFBSVosRUFBRSxDQUFDZSxRQUFQLEdBQWtCWSxNQUFsQjtBQUNDLFNBQUtkLFdBQUwsQ0FBaUJlLE1BQWpCO0FBQ0osU0FBS3BCLE9BQUwsQ0FBYXFCLEVBQWIsQ0FBZ0I3QixFQUFFLENBQUNLLElBQUgsQ0FBUXlCLFNBQVIsQ0FBa0JDLEtBQWxDLEVBQXlDLFVBQVNDLENBQVQsRUFBWTtBQUNwRCxXQUFLQyxFQUFMO0FBQVcsS0FEWixFQUNjLElBRGQ7QUFFRyxTQUFLekIsT0FBTCxDQUFhcUIsRUFBYixDQUFnQjdCLEVBQUUsQ0FBQ0ssSUFBSCxDQUFReUIsU0FBUixDQUFrQkksVUFBbEMsRUFBOEMsVUFBU0YsQ0FBVCxFQUFZO0FBQzVELFdBQUtDLEVBQUw7QUFDQSxLQUZFLEVBRUEsSUFGQTtBQUdFLEdBckRJO0FBc0RSQSxFQUFBQSxFQXREUSxnQkFzREo7QUFDSCxTQUFLcEIsV0FBTCxHQUFtQixLQUFLVCxVQUFMLENBQWdCVSxZQUFoQixDQUE2QmQsRUFBRSxDQUFDZSxRQUFoQyxDQUFuQjtBQUNBLFNBQUtGLFdBQUwsQ0FBaUJzQixLQUFqQjtBQUNBeEIsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUNBLFFBQUlJLEVBQUUsR0FBRyxLQUFLVixNQUFMLENBQVlXLHFCQUFaLENBQWtDakIsRUFBRSxDQUFDa0IsRUFBSCxDQUFNLENBQU4sRUFBUSxDQUFSLENBQWxDLENBQVQ7QUFDQSxRQUFJQyxFQUFFLEdBQUcsS0FBS1gsT0FBTCxDQUFhUyxxQkFBYixDQUFtQ2pCLEVBQUUsQ0FBQ2tCLEVBQUgsQ0FBTSxDQUFOLEVBQVEsQ0FBUixDQUFuQyxDQUFUO0FBQ0FQLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFDRyxRQUFJUSxHQUFHLEdBQUdKLEVBQUUsQ0FBQ0ssQ0FBYjtBQUNILFFBQUlDLEdBQUcsR0FBR04sRUFBRSxDQUFDTyxDQUFiO0FBQ00sU0FBS1YsV0FBTCxDQUFpQlcsTUFBakIsQ0FBd0JKLEdBQXhCLEVBQTRCRSxHQUE1QjtBQUNOWCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaO0FBRUFELElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZTyxFQUFFLENBQUNFLENBQWY7QUFDQSxRQUFJSSxHQUFHLEdBQUdOLEVBQUUsQ0FBQ0UsQ0FBSCxHQUFNLEVBQWhCO0FBRUEsUUFBSUssR0FBRyxHQUFHUCxFQUFFLENBQUNJLENBQUgsR0FBTSxFQUFoQjtBQUNNLFNBQUtWLFdBQUwsQ0FBaUJjLE1BQWpCLENBQXdCRixHQUF4QixFQUE0QkMsR0FBNUI7QUFDTmYsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVDLFFBQUlaLEVBQUUsQ0FBQ2UsUUFBUCxHQUFrQlksTUFBbEI7QUFDQyxTQUFLZCxXQUFMLENBQWlCZSxNQUFqQjtBQUNGLEdBM0VPLENBNkVMOztBQTdFSyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyJjYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIG1haW5DYW52YXM6IGNjLk5vZGUsXHJcblx0XHRwbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0XHJcbiAgICB9LFxyXG5cdFxyXG5cclxuICAgIC8vIExJRkUtQ1lDTEUgQ0FMTEJBQ0tTOlxyXG5cclxuICAgIG9uTG9hZCAoKSB7XHJcblx0XHRcclxuXHRcdC8vdmFyIGFweCA9IDE7XHJcblx0XHJcblx0XHJcblxyXG5cdFx0Ly9jb25zb2xlLmxvZyh0bXBQYXRoKVxyXG5cdFx0XHJcblx0fSxcclxuXHJcbiAgICBzdGFydCAoKSB7Y29uc29sZS5sb2coXCJTQVNEQVwiKTtcdHRoaXMubWFpbkNvbnRleHQgPSB0aGlzLm1haW5DYW52YXMuZ2V0Q29tcG9uZW50KGNjLkdyYXBoaWNzKTtcclxuXHRcdFxyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhcCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBicCA9IHRoaXMucGxheWVyMi5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/OCcpO1xyXG5cdCAgICB2YXIgYXB4ID0gYXAueDtcclxuXHRcdHZhciBhcHkgPSBhcC55O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGFweCxhcHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vycpO1xyXG5cdFx0XHJcblx0XHRjb25zb2xlLmxvZyhicC54KTtcclxuXHRcdHZhciBicHggPSBicC54IC02NjtcclxuXHRcdFxyXG5cdFx0dmFyIGJweSA9IGJwLnkgKzQ1O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGJweCxicHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzInKTtcclxuXHRcdCBuZXcgY2MuR3JhcGhpY3MoKS5saW5lVG8oKTtcclxuICAgIHRoaXMubWFpbkNvbnRleHQuc3Ryb2tlKCk7XHJcbnRoaXMucGxheWVyMi5vbihjYy5Ob2RlLkV2ZW50VHlwZS5TVEFSVCwgZnVuY3Rpb24odCkge1xyXG5cdHRoaXMuZnUoKTt9LCB0aGlzKTtcclxuXHRcdFx0dGhpcy5wbGF5ZXIyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIGZ1bmN0aW9uKHQpIHtcclxuXHR0aGlzLmZ1KCk7XHJcbn0sIHRoaXMpO1xyXG4gICAgfSxcclxuXHRmdSgpe1xyXG5cdFx0dGhpcy5tYWluQ29udGV4dCA9IHRoaXMubWFpbkNhbnZhcy5nZXRDb21wb25lbnQoY2MuR3JhcGhpY3MpO1xyXG5cdFx0dGhpcy5tYWluQ29udGV4dC5jbGVhcigpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzcnKTtcclxuXHRcdHZhciBhcCA9IHRoaXMucGxheWVyLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLDApKTtcclxuXHRcdHZhciBicCA9IHRoaXMucGxheWVyMi5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwwKSk7XHJcblx0XHRjb25zb2xlLmxvZygn5byA5aeL55S757q/OCcpO1xyXG5cdCAgICB2YXIgYXB4ID0gYXAueDtcclxuXHRcdHZhciBhcHkgPSBhcC55O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubW92ZVRvKGFweCxhcHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vycpO1xyXG5cdFx0XHJcblx0XHRjb25zb2xlLmxvZyhicC54KTtcclxuXHRcdHZhciBicHggPSBicC54IC02NjtcclxuXHRcdFxyXG5cdFx0dmFyIGJweSA9IGJwLnkgKzQ1O1xyXG4gICAgICAgIHRoaXMubWFpbkNvbnRleHQubGluZVRvKGJweCxicHkpO1xyXG5cdFx0Y29uc29sZS5sb2coJ+W8gOWni+eUu+e6vzInKTtcclxuICAgIFxyXG4gICBuZXcgY2MuR3JhcGhpY3MoKS5saW5lVG8oKTtcclxuICAgIHRoaXMubWFpbkNvbnRleHQuc3Ryb2tlKCk7XHJcblx0fSxcclxuXHRcclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG5cdFxyXG5cclxuXHRcclxufSk7XHJcbiJdfQ==