
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/tip.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, 'daf93JwsK5KwLD8srSWa0z7', 'tip');
// Script/tip.js

"use strict";

var _properties;

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Global = require("tip2");

cc.Class({
  "extends": cc.Component,
  Global: Global,
  properties: (_properties = {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties),
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  start: function start() {
    var tipObj = new Global();
    this.myLabel = this.node.getComponent(cc.Label);
    this.myLabel.string = G.xianshi;
    tipObj.ts();
  } // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFx0aXAuanMiXSwibmFtZXMiOlsiR2xvYmFsIiwicmVxdWlyZSIsImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwicGxheWVyIiwidHlwZSIsIk5vZGUiLCJwbGF5ZXIyIiwib25Mb2FkIiwic3RhcnQiLCJ0aXBPYmoiLCJteUxhYmVsIiwibm9kZSIsImdldENvbXBvbmVudCIsIkxhYmVsIiwic3RyaW5nIiwiRyIsInhpYW5zaGkiLCJ0cyJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBLElBQUlBLE1BQU0sR0FBRUMsT0FBTyxDQUFDLE1BQUQsQ0FBbkI7O0FBRUFDLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBQ2lCSixFQUFBQSxNQUFNLEVBQU5BLE1BRGpCO0FBR0xLLEVBQUFBLFVBQVU7QUFDTjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDTEMsSUFBQUEsTUFBTSxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWpCRztBQXFCWkMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVjtBQXJCRyw4QkF5Qkg7QUFDQyxlQUFTLElBRFY7QUFFQ0QsSUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlYsR0F6QkcsMkJBNkJIO0FBQ0MsZUFBUyxJQURWO0FBRUNELElBQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZWLEdBN0JHLDJCQWlDSDtBQUNDLGVBQVMsSUFEVjtBQUVDRCxJQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixHQWpDRyxjQUhMO0FBMENMO0FBS0FFLEVBQUFBLE1BL0NLLG9CQStDSyxDQUVaLENBakRPO0FBb0RMQyxFQUFBQSxLQXBESyxtQkFvREk7QUFDYixRQUFJQyxNQUFNLEdBQUcsSUFBSVosTUFBSixFQUFiO0FBR0csU0FBS2EsT0FBTCxHQUFlLEtBQUtDLElBQUwsQ0FBVUMsWUFBVixDQUF1QmIsRUFBRSxDQUFDYyxLQUExQixDQUFmO0FBQ0YsU0FBS0gsT0FBTCxDQUFhSSxNQUFiLEdBQXNCQyxDQUFDLENBQUNDLE9BQXhCO0FBRURQLElBQUFBLE1BQU0sQ0FBQ1EsRUFBUDtBQUVLLEdBN0RJLENBK0RMOztBQS9ESyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxudmFyIEdsb2JhbCA9cmVxdWlyZShcInRpcDJcIik7XHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsR2xvYmFsLFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcblx0XHRcclxuICAgICAgICAvLyB9LFxyXG5cdCAgcGxheWVyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG5cclxuXHJcblxyXG4gICAgb25Mb2FkICgpIHtcclxuXHRcclxuXHR9LFxyXG5cdFxyXG4gXHJcbiAgICBzdGFydCAoKSB7XHJcbmxldCB0aXBPYmogPSBuZXcgR2xvYmFsKCk7XHJcblxyXG5cclxuXHQgIHRoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSBHLnhpYW5zaGk7XHJcblx0XHJcbnRpcE9iai50cygpO1xyXG5cdFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==