
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript - 004.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '7d6c2wC1hBPsrSw5gT7LMCf', 'NewScript - 004');
// Script/NewScript - 004.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    }
  },
  ontm: function ontm(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    var del = t.getDelta();
    this.node.x += del.x;
    this.node.y += del.y;
  },
  ontm2: function ontm2(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.node.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("1");
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.ontm, this);
    this.player.on(cc.Node.EventType.TOUCH_MOVE, this.ontm2, this);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQgLSAwMDQuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiTm9kZSIsIm9udG0iLCJ0IiwidyIsIm5vZGUiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJ2MiIsInkiLCJHIiwiaG9uZ2JpIiwiZGVsIiwiZ2V0RGVsdGEiLCJ4Iiwib250bTIiLCJvbkxvYWQiLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwiY29uc29sZSIsImxvZyIsIlRPVUNIX01PVkUiLCJzdGFydCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQUEsRUFBRSxDQUFDQyxLQUFILENBQVM7QUFDTCxhQUFTRCxFQUFFLENBQUNFLFNBRFA7QUFHTEMsRUFBQUEsVUFBVSxFQUFFO0FBQ1I7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ05DLElBQUFBLE1BQU0sRUFBRTtBQUNFLGlCQUFTLElBRFg7QUFFRUMsTUFBQUEsSUFBSSxFQUFFTCxFQUFFLENBQUNNO0FBRlg7QUFoQk0sR0FIUDtBQXlCVEMsRUFBQUEsSUFBSSxFQUFDLGNBQVNDLENBQVQsRUFBVztBQUNiLFFBQUlDLENBQUMsR0FBRSxLQUFLQyxJQUFMLENBQVVDLHFCQUFWLENBQWdDWCxFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFoQyxDQUFQO0FBRUFILElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNSixDQUFDLENBQUNJLENBQUYsR0FBSSxLQUFWO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsTUFBRixHQUFTTixDQUFUO0FBRUEsUUFBSU8sR0FBRyxHQUFHUixDQUFDLENBQUNTLFFBQUYsRUFBVjtBQUNBLFNBQUtQLElBQUwsQ0FBVVEsQ0FBVixJQUFlRixHQUFHLENBQUNFLENBQW5CO0FBQ0EsU0FBS1IsSUFBTCxDQUFVRyxDQUFWLElBQWVHLEdBQUcsQ0FBQ0gsQ0FBbkI7QUFFQSxHQW5DTTtBQW9DVE0sRUFBQUEsS0FBSyxFQUFDLGVBQVNYLENBQVQsRUFBVztBQUNkLFFBQUlDLENBQUMsR0FBRSxLQUFLQyxJQUFMLENBQVVDLHFCQUFWLENBQWdDWCxFQUFFLENBQUNZLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFoQyxDQUFQO0FBRUFILElBQUFBLENBQUMsQ0FBQ0ksQ0FBRixHQUFNSixDQUFDLENBQUNJLENBQUYsR0FBSSxLQUFWO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsTUFBRixHQUFTTixDQUFUO0FBSUEsR0E1Q007QUE2Q0w7QUFDSFcsRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2xCLFNBQUtWLElBQUwsQ0FBVVcsRUFBVixDQUFhckIsRUFBRSxDQUFDTSxJQUFILENBQVFnQixTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxVQUFTZixDQUFULEVBQVc7QUFBQ2dCLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLEdBQVo7QUFBa0IsS0FBMUUsRUFBMkUsSUFBM0U7QUFDQSxTQUFLZixJQUFMLENBQVVXLEVBQVYsQ0FBYXJCLEVBQUUsQ0FBQ00sSUFBSCxDQUFRZ0IsU0FBUixDQUFrQkksVUFBL0IsRUFBMkMsS0FBS25CLElBQWhELEVBQXFELElBQXJEO0FBQ0EsU0FBS0gsTUFBTCxDQUFZaUIsRUFBWixDQUFlckIsRUFBRSxDQUFDTSxJQUFILENBQVFnQixTQUFSLENBQWtCSSxVQUFqQyxFQUE2QyxLQUFLUCxLQUFsRCxFQUF3RCxJQUF4RDtBQUVLLEdBbkRJO0FBb0RMO0FBRUFRLEVBQUFBLEtBdERLLG1CQXNESSxDQUVSLENBeERJLENBMERMOztBQTFESyxDQUFUIiwic291cmNlUm9vdCI6Ii8iLCJzb3VyY2VzQ29udGVudCI6WyIvLyBMZWFybiBjYy5DbGFzczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvY2xhc3MuaHRtbFxyXG4vLyBMZWFybiBBdHRyaWJ1dGU6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL3JlZmVyZW5jZS9hdHRyaWJ1dGVzLmh0bWxcclxuLy8gTGVhcm4gbGlmZS1jeWNsZSBjYWxsYmFja3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2xpZmUtY3ljbGUtY2FsbGJhY2tzLmh0bWxcclxuXHJcbmNjLkNsYXNzKHtcclxuICAgIGV4dGVuZHM6IGNjLkNvbXBvbmVudCxcclxuXHJcbiAgICBwcm9wZXJ0aWVzOiB7XHJcbiAgICAgICAgLy8gZm9vOiB7XHJcbiAgICAgICAgLy8gICAgIC8vIEFUVFJJQlVURVM6XHJcbiAgICAgICAgLy8gICAgIGRlZmF1bHQ6IG51bGwsICAgICAgICAvLyBUaGUgZGVmYXVsdCB2YWx1ZSB3aWxsIGJlIHVzZWQgb25seSB3aGVuIHRoZSBjb21wb25lbnQgYXR0YWNoaW5nXHJcbiAgICAgICAgLy8gICAgICAgICAgICAgICAgICAgICAgICAgICAvLyB0byBhIG5vZGUgZm9yIHRoZSBmaXJzdCB0aW1lXHJcbiAgICAgICAgLy8gICAgIHR5cGU6IGNjLlNwcml0ZUZyYW1lLCAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0eXBlb2YgZGVmYXVsdFxyXG4gICAgICAgIC8vICAgICBzZXJpYWxpemFibGU6IHRydWUsICAgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHJ1ZVxyXG4gICAgICAgIC8vIH0sXHJcbiAgICAgICAgLy8gYmFyOiB7XHJcbiAgICAgICAgLy8gICAgIGdldCAoKSB7XHJcbiAgICAgICAgLy8gICAgICAgICByZXR1cm4gdGhpcy5fYmFyO1xyXG4gICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgIC8vICAgICBzZXQgKHZhbHVlKSB7XHJcbiAgICAgICAgLy8gICAgICAgICB0aGlzLl9iYXIgPSB2YWx1ZTtcclxuICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgIC8vIH0sXHJcblx0XHRwbGF5ZXI6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRcclxuICAgIH0sXHJcbm9udG06ZnVuY3Rpb24odCl7XHJcblx0XHRcdHZhciB3ID10aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRcdFx0XHJcblx0XHRcdHZhciBkZWwgPSB0LmdldERlbHRhKCk7XHJcblx0XHRcdHRoaXMubm9kZS54ICs9IGRlbC54O1xyXG5cdFx0XHR0aGlzLm5vZGUueSArPSBkZWwueTtcclxuXHRcdFxyXG5cdFx0fSxcclxub250bTI6ZnVuY3Rpb24odCl7XHJcblx0XHRcdHZhciB3ID10aGlzLm5vZGUuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRcdFx0XHJcblx0XHRcdFxyXG5cdFx0XHJcblx0XHR9LFxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcbiBvbkxvYWQ6ZnVuY3Rpb24oKXtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcIjFcIik7fSx0aGlzKTtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub250bSx0aGlzKTtcclxudGhpcy5wbGF5ZXIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vbnRtMix0aGlzKTtcclxuXHJcbiAgICB9LFxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19