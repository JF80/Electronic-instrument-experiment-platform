
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/CC.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '00fa9yqF9lNM7oBcwMsQ59b', 'CC');
// Script/CC.js

"use strict";

var _window$G;

window.G = (_window$G = {
  red: true,
  xiangmu: 1,
  dangwei: 0,
  xianshi: 1,
  tip: 1,
  hongbi: null,
  heibi: null,
  hongbiyes: 0,
  heibiyes: 0,
  btr: 0,
  btb: 0,
  rtr: 0,
  rtb: 0,
  xls: 0,
  rtg: 0,
  btg: 0,
  mode: 1,
  source: 1,
  ch1: true,
  ch2: false
}, _window$G["xianshi"] = '万用表关闭时选择关闭档或者电压最高档', _window$G);

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxDQy5qcyJdLCJuYW1lcyI6WyJ3aW5kb3ciLCJHIiwicmVkIiwieGlhbmdtdSIsImRhbmd3ZWkiLCJ4aWFuc2hpIiwidGlwIiwiaG9uZ2JpIiwiaGVpYmkiLCJob25nYml5ZXMiLCJoZWliaXllcyIsImJ0ciIsImJ0YiIsInJ0ciIsInJ0YiIsInhscyIsInJ0ZyIsImJ0ZyIsIm1vZGUiLCJzb3VyY2UiLCJjaDEiLCJjaDIiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQUEsTUFBTSxDQUFDQyxDQUFQO0FBRUFDLEVBQUFBLEdBQUcsRUFBRyxJQUZOO0FBR0FDLEVBQUFBLE9BQU8sRUFBQyxDQUhSO0FBSUFDLEVBQUFBLE9BQU8sRUFBQyxDQUpSO0FBS0FDLEVBQUFBLE9BQU8sRUFBQyxDQUxSO0FBTUFDLEVBQUFBLEdBQUcsRUFBQyxDQU5KO0FBT0FDLEVBQUFBLE1BQU0sRUFBQyxJQVBQO0FBUUFDLEVBQUFBLEtBQUssRUFBQyxJQVJOO0FBU0FDLEVBQUFBLFNBQVMsRUFBQyxDQVRWO0FBVUFDLEVBQUFBLFFBQVEsRUFBQyxDQVZUO0FBV0FDLEVBQUFBLEdBQUcsRUFBQyxDQVhKO0FBWUFDLEVBQUFBLEdBQUcsRUFBQyxDQVpKO0FBYUFDLEVBQUFBLEdBQUcsRUFBQyxDQWJKO0FBY0FDLEVBQUFBLEdBQUcsRUFBQyxDQWRKO0FBZUFDLEVBQUFBLEdBQUcsRUFBQyxDQWZKO0FBZ0JBQyxFQUFBQSxHQUFHLEVBQUMsQ0FoQko7QUFpQkFDLEVBQUFBLEdBQUcsRUFBQyxDQWpCSjtBQWtCQUMsRUFBQUEsSUFBSSxFQUFDLENBbEJMO0FBbUJBQyxFQUFBQSxNQUFNLEVBQUMsQ0FuQlA7QUFvQkFDLEVBQUFBLEdBQUcsRUFBQyxJQXBCSjtBQXFCQUMsRUFBQUEsR0FBRyxFQUFDO0FBckJKLDBCQXdCUSxvQkF4QlIiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIndpbmRvdy5HID0ge1xyXG5cclxucmVkIDogdHJ1ZSxcclxueGlhbmdtdToxLFxyXG5kYW5nd2VpOjAsXHJcbnhpYW5zaGk6MSxcclxudGlwOjEsXHJcbmhvbmdiaTpudWxsLFxyXG5oZWliaTpudWxsLFxyXG5ob25nYml5ZXM6MCxcclxuaGVpYml5ZXM6MCxcclxuYnRyOjAsXHJcbmJ0YjowLFxyXG5ydHI6MCxcclxucnRiOjAsXHJcbnhsczowLFxyXG5ydGc6MCxcclxuYnRnOjAsXHJcbm1vZGU6MSxcclxuc291cmNlOjEsXHJcbmNoMTp0cnVlLFxyXG5jaDI6ZmFsc2UsXHJcblxyXG5cclxueGlhbnNoaTon5LiH55So6KGo5YWz6Zet5pe26YCJ5oup5YWz6Zet5qGj5oiW6ICF55S15Y6L5pyA6auY5qGjJyxcclxufSJdfQ==