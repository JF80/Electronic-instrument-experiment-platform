
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/tip2.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '6419asQFxJHr6sGmlk9wlRC', 'tip2');
// Script/tip2.js

"use strict";

var tp = cc.Class({
  "extends": cc.Component,
  ts: function ts() {
    if (G.tip = 1) {
      G.xianshi = '将黑红表笔放置到加亮的标记处';
    }

    ;

    if (G.tip = 2) {
      G.xianshi = '数字式万用表的红表笔接正极';
    }

    ;

    if (G.tip = 3) {
      G.xianshi = '当前量程过大';
    }

    if (G.tip = 4) {
      G.xianshi = '当前量程过小';
    }

    if (G.tip = 5) {
      G.xianshi = '通路';
    }

    if (G.tip = 6) {
      G.xianshi = '当前量程档位错误';
    }

    if (G.tip = 7) {
      G.xianshi = '万用表关闭时选择关闭档或者电压最高档';
    }

    if (G.tip = 8) {
      G.xianshi = '测量高电压时使用错误档位会造成危险';
    }

    if (G.tip = 9) {
      G.xianshi = '测量电压时红表笔选择电流档会损坏万用表';
    }

    if (G.tip = 10) {
      G.xianshi = '当前红表笔档位错误';
    }
  }
});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFx0aXAyLmpzIl0sIm5hbWVzIjpbInRwIiwiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInRzIiwiRyIsInRpcCIsInhpYW5zaGkiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsSUFBSUEsRUFBRSxHQUFHQyxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNsQixhQUFTRCxFQUFFLENBQUNFLFNBRE07QUFHbEJDLEVBQUFBLEVBQUUsRUFBQyxjQUFVO0FBRWIsUUFBR0MsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLGdCQUFaO0FBQTZCOztBQUFBOztBQUM3QyxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVksZUFBWjtBQUE2Qjs7QUFBQTs7QUFDN0MsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLFFBQVo7QUFBc0I7O0FBQ3RDLFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVgsRUFBYTtBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxRQUFaO0FBQXNCOztBQUN0QyxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVksSUFBWjtBQUFrQjs7QUFDbEMsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLFVBQVo7QUFBd0I7O0FBQ3hDLFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVgsRUFBYTtBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxvQkFBWjtBQUFrQzs7QUFDbEQsUUFBR0YsQ0FBQyxDQUFDQyxHQUFGLEdBQVEsQ0FBWCxFQUFhO0FBQUdELE1BQUFBLENBQUMsQ0FBQ0UsT0FBRixHQUFZLG1CQUFaO0FBQWlDOztBQUNqRCxRQUFHRixDQUFDLENBQUNDLEdBQUYsR0FBUSxDQUFYLEVBQWE7QUFBR0QsTUFBQUEsQ0FBQyxDQUFDRSxPQUFGLEdBQVkscUJBQVo7QUFBbUM7O0FBQ25ELFFBQUdGLENBQUMsQ0FBQ0MsR0FBRixHQUFRLEVBQVgsRUFBYztBQUFHRCxNQUFBQSxDQUFDLENBQUNFLE9BQUYsR0FBWSxXQUFaO0FBQXlCO0FBQ3pDO0FBZmlCLENBQVQsQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsidmFyIHRwID0gY2MuQ2xhc3Moe1xyXG5leHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG50czpmdW5jdGlvbigpe1xyXG4gICBcclxuaWYoRy50aXAgPSAxKXsgIEcueGlhbnNoaSA9ICflsIbpu5HnuqLooajnrJTmlL7nva7liLDliqDkuq7nmoTmoIforrDlpIQnfTtcclxuaWYoRy50aXAgPSAyKXsgIEcueGlhbnNoaSA9ICfmlbDlrZflvI/kuIfnlKjooajnmoTnuqLooajnrJTmjqXmraPmnoEnO307XHJcbmlmKEcudGlwID0gMyl7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL6L+H5aSnJzt9XHJcbmlmKEcudGlwID0gNCl7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL6L+H5bCPJzt9XHJcbmlmKEcudGlwID0gNSl7ICBHLnhpYW5zaGkgPSAn6YCa6LevJzt9XHJcbmlmKEcudGlwID0gNil7ICBHLnhpYW5zaGkgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJzt9XHJcbmlmKEcudGlwID0gNyl7ICBHLnhpYW5zaGkgPSAn5LiH55So6KGo5YWz6Zet5pe26YCJ5oup5YWz6Zet5qGj5oiW6ICF55S15Y6L5pyA6auY5qGjJzt9XHJcbmlmKEcudGlwID0gOCl7ICBHLnhpYW5zaGkgPSAn5rWL6YeP6auY55S15Y6L5pe25L2/55So6ZSZ6K+v5qGj5L2N5Lya6YCg5oiQ5Y2x6ZmpJzt9XHJcbmlmKEcudGlwID0gOSl7ICBHLnhpYW5zaGkgPSAn5rWL6YeP55S15Y6L5pe257qi6KGo56yU6YCJ5oup55S15rWB5qGj5Lya5o2f5Z2P5LiH55So6KGoJzt9XHJcbmlmKEcudGlwID0gMTApeyAgRy54aWFuc2hpID0gJ+W9k+WJjee6ouihqOeslOaho+S9jemUmeivryc7fVxyXG59XHJcblxyXG5cclxufSk7XHJcblxyXG4iXX0=