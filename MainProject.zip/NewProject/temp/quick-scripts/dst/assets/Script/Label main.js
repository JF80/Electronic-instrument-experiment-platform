
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/Label main.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '375d9gN9YZAZbZAwd7sVlSv', 'Label main');
// Script/Label main.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    playerred: {
      "default": null,
      type: cc.Node
    },
    playerblack: {
      "default": null,
      type: cc.Node
    },
    playerblack1: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    },
    player3: {
      "default": null,
      type: cc.Node
    },
    player4: {
      "default": null,
      type: cc.Node
    },
    player5: {
      "default": null,
      type: cc.AudioClip
    },
    player6: {
      "default": null,
      type: cc.Node
    },
    player7: {
      "default": null,
      type: cc.Node
    },
    tipp: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  time1: function time1() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '万用表关闭时选择关闭档或者电压最高档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;

    if (G.red == false) {
      console.log("s5sd");

      if (G.dangwei > 9 & G.dangwei < 15) {
        console.log("sadd545sd");
        var pu1 = cc.v2(629, 302);
        var pu2 = cc.v2(G.hongbi);
        var redtox = Math.abs(pu2.x - pu1.x);
        var redtoy = Math.abs(pu2.y - pu1.y);
        console.log("saddasd");
        console.log(pu2);

        if (redtox <= 50 & redtoy <= 50) {
          G.rtr = 1;
        }

        ;
        var py1 = cc.v2(629, 320);
        var py2 = cc.v2(G.heibi);
        var redtpx = Math.abs(py2.x - py1.x);
        var redtpy = Math.abs(py2.y - py1.y);
        console.log("saddasd");

        if (redtpx <= 50 & redtpy <= 50) {
          G.btr = 1;
        }

        ;
        var ps1 = cc.v2(858, 379);
        var ps2 = cc.v2(G.hongbi);
        var redtqx = Math.abs(ps2.x - ps1.x);
        var redtqy = Math.abs(ps2.y - ps1.y);
        console.log("saddasd");

        if (redtqx <= 50 & redtqy <= 50) {
          G.rtb = 1;
        }

        ;
        var pl1 = cc.v2(858, 379);
        var pl2 = cc.v2(G.heibi);
        var redtc = Math.abs(pl2.x - pl1.x);
        var redtg = Math.abs(pl2.y - pl1.y);
        console.log("saddasd");

        if (redtc <= 50 & redtg <= 50) {
          G.btb = 1;
        }

        ;
        console.log(G.rtr);
        console.log(G.btb);

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '数字式万用表的红表笔接正极';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请调至电阻档';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '当前量程档位错误';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将红表笔调至电阻位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前红表笔档位错误';
    }
  },
  time2: function time2() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电流时要和负载串联\n万用表只能测量微小电流';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("99d");

    if (G.dangwei > 2 & G.dangwei < 7) {
      var pu1 = cc.v2(733, 301);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(733, 301);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(762, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 13 & redtpy <= 13) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(762, 303);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 13 & redtqy <= 13) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '25.30mA';
        } else if (G.rtb == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-25.30mA';
        }
      } else if (G.rtr == 1 & G.btb == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '0.025A';
      } else if (G.rtb == 1 & G.btr == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '-0.025A';
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请接触黑红表笔';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '数字式万用表的红表笔接正极';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将调至直流电流档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前量程档位错误';
    }
  },
  time3: function time3() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("85475");

    if (G.dangwei > 16 & G.dangwei < 20) {
      console.log("sadd545sd");
      var pu1 = cc.v2(826, 303);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 30 & redtoy <= 30) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(826, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(766, 261);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(766, 261);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 30 & redtqy <= 30) {
        G.rtr = 1;
      }

      ;
      console.log("55");

      if (G.red == false) {
        console.log("sa55555");

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '6.15V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-6.15V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '将黑红表笔放置到加亮的标记处';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔调至电压位', this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei > 12) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '超量程', this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '低电压档测高电压可能会损坏万用表';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至直流电压位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量电压时使用错误档位会损坏万用表';
    }
  },
  time4: function time4() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '警告：使用万用表测量较高电压时\n必须使用交流档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    G.rtg = 0;
    G.btg = 0;

    if (G.dangwei > 0 & G.dangwei < 2) {
      console.log("sadd545sd");
      var pu1 = cc.v2(740, 345);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtg = 1;
      }

      ;
      var py1 = cc.v2(740, 345);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btg = 1;
      }

      ;
      var py1 = cc.v2(724, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var ps1 = cc.v2(724, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(759, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(759, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.btb == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btg == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.rtg == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '0V';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔接至交流电压位';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei == 2) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '当前量程太小';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '必须使用交流档位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量高电压时使用错误档位会造成危险!\n当前万用表已自动断路';
    }
  },
  time5: function time5() {
    if (G.dangwei == 9) {
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '将红黑表笔短接以测量通路';
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '准备自检';
      console.log("sadd545sd");
      var pu1 = cc.v2(G.hongbi);
      var pu2 = cc.v2(G.heibi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log(G.hongbi);
      console.log(G.heibi);

      if (redtox <= 10 & redtoy <= 10) {
        this.current = cc.audioEngine.play(this.player5, false, 1);
        ;
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '通过';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '仅验证为通路';
      }

      ;
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至自检档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '错误档位红黑表笔短接可能会算坏万用表';
    }
  },
  onLoad: function onLoad() {
    G.dangwei == 0;
    console.log("sad5sd");
    var p = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
    var w = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    this.playerred.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.playerblack.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerred.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pccp");
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;
      var del = t.getDelta();
      this.playerred.x += del.x;
      this.playerred.y += del.y;
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerblack.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pc2cp");
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      var del = t.getDelta();
      this.playerblack.x += del.x;
      this.playerblack.y += del.y;
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player4.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p2ccp");
      this.player7.rotation -= 18;
      G.dangwei -= 1;

      if (G.dangwei == -1) {
        G.dangwei = 19;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    console.log("scccd");
    this.player6.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("pcc5p");
      this.player7.rotation += 18;
      G.dangwei += 1;

      if (G.dangwei == 20) {
        G.dangwei = 0;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxMYWJlbCBtYWluLmpzIl0sIm5hbWVzIjpbImNjIiwiQ2xhc3MiLCJDb21wb25lbnQiLCJwcm9wZXJ0aWVzIiwicGxheWVycmVkIiwidHlwZSIsIk5vZGUiLCJwbGF5ZXJibGFjayIsInBsYXllcmJsYWNrMSIsInBsYXllcjIiLCJwbGF5ZXIzIiwicGxheWVyNCIsInBsYXllcjUiLCJBdWRpb0NsaXAiLCJwbGF5ZXI2IiwicGxheWVyNyIsInRpcHAiLCJ0aW1lMSIsIm15TGFiZWwiLCJnZXRDb21wb25lbnQiLCJMYWJlbCIsInN0cmluZyIsIkciLCJidHIiLCJidGIiLCJydHIiLCJydGIiLCJyZWQiLCJjb25zb2xlIiwibG9nIiwiZGFuZ3dlaSIsInB1MSIsInYyIiwicHUyIiwiaG9uZ2JpIiwicmVkdG94IiwiTWF0aCIsImFicyIsIngiLCJyZWR0b3kiLCJ5IiwicHkxIiwicHkyIiwiaGVpYmkiLCJyZWR0cHgiLCJyZWR0cHkiLCJwczEiLCJwczIiLCJyZWR0cXgiLCJyZWR0cXkiLCJwbDEiLCJwbDIiLCJyZWR0YyIsInJlZHRnIiwibm9kZSIsInRpbWUyIiwidGltZTMiLCJ0aW1lNCIsInJ0ZyIsImJ0ZyIsInRpbWU1IiwiY3VycmVudCIsImF1ZGlvRW5naW5lIiwicGxheSIsIm9uTG9hZCIsInAiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJwcCIsInciLCJvbiIsIkV2ZW50VHlwZSIsIlRPVUNIX1NUQVJUIiwidCIsInhpYW5nbXUiLCJUT1VDSF9NT1ZFIiwiZGVsIiwiZ2V0RGVsdGEiLCJUT1VDSF9FTkQiLCJyb3RhdGlvbiIsInN0YXJ0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7OztBQUFBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBQSxFQUFFLENBQUNDLEtBQUgsQ0FBUztBQUNMLGFBQVNELEVBQUUsQ0FBQ0UsU0FEUDtBQUdMQyxFQUFBQSxVQUFVLEVBQUU7QUFDUjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDTkMsSUFBQUEsU0FBUyxFQUFFO0FBQ0QsaUJBQVMsSUFEUjtBQUVEQyxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGUixLQWhCRztBQW9CZEMsSUFBQUEsV0FBVyxFQUFFO0FBQ0gsaUJBQVMsSUFETjtBQUVIRixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTixLQXBCQztBQXdCZEUsSUFBQUEsWUFBWSxFQUFFO0FBQ0osaUJBQVMsSUFETDtBQUVKSCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGTCxLQXhCQTtBQTRCZEcsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDSixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQTVCSztBQWdDZEksSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDTCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWhDSztBQW9DZEssSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDTixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQXBDSztBQXdDZE0sSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDUCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ2E7QUFGVixLQXhDSztBQTRDZEMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDVCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQTVDSztBQWlEZFMsSUFBQUEsT0FBTyxFQUFFO0FBQ0MsaUJBQVMsSUFEVjtBQUVDVixNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGVixLQWpESztBQXNEZFUsSUFBQUEsSUFBSSxFQUFFO0FBQ0ksaUJBQVMsSUFEYjtBQUVJWCxNQUFBQSxJQUFJLEVBQUVMLEVBQUUsQ0FBQ007QUFGYjtBQXREUSxHQUhQO0FBaUVMO0FBR0hXLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUtDLE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hCLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixvQkFBdEI7QUFDRkMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNBRCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjs7QUFFRSxRQUFHSixDQUFDLENBQUNLLEdBQUYsSUFBUyxLQUFaLEVBQWtCO0FBQ2pCQyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxNQUFaOztBQUNELFVBQUdQLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBZVIsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsRUFBNUIsRUFBZ0M7QUFFaENGLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVo7QUFDRCxZQUFJRSxHQUFHLEdBQUcvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVHLFlBQUlDLEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFFSixZQUFJQyxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNLLENBQUosR0FBTVAsR0FBRyxDQUFDTyxDQUFuQixDQUFiO0FBQ0MsWUFBSUMsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDTyxDQUFKLEdBQU1ULEdBQUcsQ0FBQ1MsQ0FBbkIsQ0FBYjtBQUNDWixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0FELFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxHQUFaOztBQUVBLFlBQUlFLE1BQU0sSUFBSSxFQUFWLEdBQWVJLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFDakIsVUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQVEsQ0FBUjtBQUFXOztBQUFBO0FBQzVDLFlBQUlnQixHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVFLFlBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUosWUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNBLFlBQUtPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWQ7QUFFRVosUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixZQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBQ3ZCLFVBQUFBLENBQUMsQ0FBQ0MsR0FBRixHQUFRLENBQVI7QUFBVzs7QUFBQTtBQUU1QyxZQUFJdUIsR0FBRyxHQUFHOUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDRyxZQUFJZSxHQUFHLEdBQUUvQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBQ0gsWUFBSWMsTUFBTSxHQUFHWixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDVCxDQUFKLEdBQU1RLEdBQUcsQ0FBQ1IsQ0FBbkIsQ0FBYjtBQUNDLFlBQUlXLE1BQU0sR0FBR2IsSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1AsQ0FBSixHQUFNTSxHQUFHLENBQUNOLENBQW5CLENBQWI7QUFDQ1osUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFQSxZQUFJbUIsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUMzQixVQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBUSxDQUFSO0FBQVc7O0FBQUE7QUFFOUMsWUFBSXdCLEdBQUcsR0FBR2xELEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csWUFBSW1CLEdBQUcsR0FBRW5ELEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBQ0gsWUFBSVMsS0FBSyxHQUFHaEIsSUFBSSxDQUFDQyxHQUFMLENBQVNjLEdBQUcsQ0FBQ2IsQ0FBSixHQUFNWSxHQUFHLENBQUNaLENBQW5CLENBQVo7QUFDQyxZQUFJZSxLQUFLLEdBQUdqQixJQUFJLENBQUNDLEdBQUwsQ0FBU2MsR0FBRyxDQUFDWCxDQUFKLEdBQU1VLEdBQUcsQ0FBQ1YsQ0FBbkIsQ0FBWjtBQUNDWixRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVBLFlBQUl1QixLQUFLLElBQUksRUFBVCxHQUFjQyxLQUFLLElBQUcsRUFBMUIsRUFBOEI7QUFBQy9CLFVBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFRLENBQVI7QUFBVzs7QUFBQTtBQUU1Q0ksUUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLENBQUMsQ0FBQ0csR0FBZDtBQUNDRyxRQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVAsQ0FBQyxDQUFDRSxHQUFkOztBQUNBLFlBQUlGLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixRQUF0QjtBQUFnQyxTQURqQyxNQUN1QyxJQUFJQyxDQUFDLENBQUNDLEdBQUYsSUFBTyxDQUFQLEdBQVdELENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQXRCLEVBQXdCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUMvRCxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBZ0MsU0FETSxNQUNGO0FBQUMsZUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNyQyxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsU0FBdEI7QUFBZ0MsZUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDaEMsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGVBQXRCO0FBQXVDO0FBQUMsT0E5Q3hDLE1BZ0RBO0FBQUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixRQUF0QjtBQUErQixhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUMvQixhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsVUFBdEI7QUFBa0M7QUFBQyxLQXBEbkMsTUFxREk7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ04sV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFlBQXRCO0FBQW1DLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixXQUF0QjtBQUFtQztBQUVsQyxHQXBJTTtBQXNJVGtDLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUtyQyxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNmLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQiwwQkFBdEI7QUFDREMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNERCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjtBQUNFRSxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxLQUFaOztBQUNBLFFBQUdQLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBZVIsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsQ0FBNUIsRUFBK0I7QUFHaEMsVUFBSUMsR0FBRyxHQUFHL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRyxVQUFJQyxHQUFHLEdBQUVqQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBRUosVUFBSUMsTUFBTSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDSyxDQUFKLEdBQU1QLEdBQUcsQ0FBQ08sQ0FBbkIsQ0FBYjtBQUNDLFVBQUlDLE1BQU0sR0FBR0gsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ08sQ0FBSixHQUFNVCxHQUFHLENBQUNTLENBQW5CLENBQWI7QUFDQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjtBQUNBRCxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWUksR0FBWjs7QUFFQSxVQUFJRSxNQUFNLElBQUksRUFBVixHQUFlSSxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRWpCLFFBQUFBLENBQUMsQ0FBQ0ksR0FBRixHQUFPLENBQVA7QUFBUzs7QUFBQTtBQUMzQyxVQUFJZSxHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVFLFVBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUosVUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNDLFVBQUlPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWI7QUFFQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixVQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRXZCLFFBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFPLENBQVA7QUFBUzs7QUFBQTtBQUMxQyxVQUFJaUIsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDQyxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVGLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQyxVQUFJTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFiO0FBRUNaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNDLEdBQUYsR0FBTyxDQUFQO0FBQVM7O0FBQUE7QUFDM0MsVUFBSXVCLEdBQUcsR0FBRzlDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csVUFBSWUsR0FBRyxHQUFFL0MsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUNILFVBQUljLE1BQU0sR0FBR1osSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1QsQ0FBSixHQUFNUSxHQUFHLENBQUNSLENBQW5CLENBQWI7QUFDQyxVQUFJVyxNQUFNLEdBQUdiLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNQLENBQUosR0FBTU0sR0FBRyxDQUFDTixDQUFuQixDQUFiO0FBQ0NaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUEsVUFBSW1CLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFM0IsUUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQU8sQ0FBUDtBQUFTOztBQUFBOztBQUk1QyxVQUFJSCxDQUFDLENBQUNLLEdBQUYsSUFBUSxLQUFaLEVBQWtCO0FBQ2xCLFlBQUlMLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFpQyxTQURsQyxNQUVNLElBQUdDLENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQVAsR0FBV0osQ0FBQyxDQUFDQyxHQUFGLElBQU8sQ0FBckIsRUFBdUI7QUFBQyxlQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzlCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQztBQUFDLE9BSmxDLE1BTUEsSUFBSUMsQ0FBQyxDQUFDRyxHQUFGLElBQU8sQ0FBUCxHQUFXSCxDQUFDLENBQUNFLEdBQUYsSUFBTyxDQUF0QixFQUF3QjtBQUFDLGFBQUtOLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDekIsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQStCLE9BRC9CLE1BQ29DLElBQUdDLENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQVAsR0FBV0osQ0FBQyxDQUFDQyxHQUFGLElBQU8sQ0FBckIsRUFBdUI7QUFBQyxhQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzVELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFnQyxPQURJLE1BQ0U7QUFBQyxhQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3RDLGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixTQUF0QjtBQUFnQyxhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNqQyxhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsZUFBdEI7QUFBc0M7QUFBQyxLQXBEdEMsTUFxREc7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0wsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFdBQXRCO0FBQWtDLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQztBQUUvQixHQXRNTTtBQXlNVG1DLEVBQUFBLEtBQUssRUFBQyxpQkFBVTtBQUFDLFNBQUt0QyxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNoQixTQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IscUJBQXRCO0FBQ0FDLElBQUFBLENBQUMsQ0FBQ0MsR0FBRixHQUFNLENBQU47QUFDREQsSUFBQUEsQ0FBQyxDQUFDRSxHQUFGLEdBQU0sQ0FBTjtBQUNBRixJQUFBQSxDQUFDLENBQUNHLEdBQUYsR0FBTSxDQUFOO0FBQ0FILElBQUFBLENBQUMsQ0FBQ0ksR0FBRixHQUFNLENBQU47QUFDQUUsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjs7QUFDRSxRQUFHUCxDQUFDLENBQUNRLE9BQUYsR0FBVyxFQUFYLEdBQWdCUixDQUFDLENBQUNRLE9BQUYsR0FBVSxFQUE3QixFQUFpQztBQUVqQ0YsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksV0FBWjtBQUNELFVBQUlFLEdBQUcsR0FBRy9CLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBRUcsVUFBSUMsR0FBRyxHQUFFakMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR0MsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ0ssQ0FBSixHQUFNUCxHQUFHLENBQUNPLENBQW5CLENBQWI7QUFDQyxVQUFJQyxNQUFNLEdBQUdILElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNPLENBQUosR0FBTVQsR0FBRyxDQUFDUyxDQUFuQixDQUFiO0FBQ0NaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7QUFDQUQsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlJLEdBQVo7O0FBRUEsVUFBSUUsTUFBTSxJQUFJLEVBQVYsR0FBY0ksTUFBTSxJQUFHLEVBQTNCLEVBQStCO0FBQUVqQixRQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBTSxDQUFOO0FBQVE7O0FBQUE7QUFDekMsVUFBSWUsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRSxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQyxVQUFJTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFiO0FBRUNaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFJLEVBQTdCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQVE7O0FBQUE7QUFDekMsVUFBSWlCLEdBQUcsR0FBR3pDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0MsVUFBSVUsR0FBRyxHQUFFMUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNxQixLQUFSLENBQVQ7QUFFRixVQUFJQyxNQUFNLEdBQUdSLElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNKLENBQUosR0FBTUcsR0FBRyxDQUFDSCxDQUFuQixDQUFiO0FBQ0MsVUFBSU8sTUFBTSxHQUFHVCxJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDRixDQUFKLEdBQU1DLEdBQUcsQ0FBQ0QsQ0FBbkIsQ0FBYjtBQUVDWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVGLFVBQUllLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFdkIsUUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUFROztBQUFBO0FBQzFDLFVBQUl1QixHQUFHLEdBQUc5QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUNHLFVBQUllLEdBQUcsR0FBRS9DLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFDSCxVQUFJYyxNQUFNLEdBQUdaLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNULENBQUosR0FBTVEsR0FBRyxDQUFDUixDQUFuQixDQUFiO0FBQ0MsVUFBSVcsTUFBTSxHQUFHYixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDUCxDQUFKLEdBQU1NLEdBQUcsQ0FBQ04sQ0FBbkIsQ0FBYjtBQUNDWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaOztBQUVBLFVBQUltQixNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBRTNCLFFBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFBUTs7QUFBQTtBQUV6Q0csTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksSUFBWjs7QUFDRixVQUFJUCxDQUFDLENBQUNLLEdBQUYsSUFBTyxLQUFYLEVBQWlCO0FBQUVDLFFBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBQ25CLFlBQUlQLENBQUMsQ0FBQ0csR0FBRixJQUFPLENBQVAsR0FBV0gsQ0FBQyxDQUFDRSxHQUFGLElBQU8sQ0FBdEIsRUFBd0I7QUFBQyxlQUFLTixPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3hCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixPQUF0QjtBQUErQixTQURoQyxNQUNxQyxJQUFHQyxDQUFDLENBQUNDLEdBQUYsSUFBTyxDQUFQLEdBQVdELENBQUMsQ0FBQ0ksR0FBRixJQUFPLENBQXJCLEVBQXVCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUM1RCxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBK0IsU0FESyxNQUNBO0FBQUMsZUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNyQyxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsU0FBdEI7QUFBZ0MsZUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDakMsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGdCQUF0QjtBQUF1QztBQUFDLE9BTHhDLE1BT0E7QUFBQyxhQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0EsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFlBQXRCLEVBQW1DLEtBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFsRDtBQUNELGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixxQkFBdEI7QUFBNEM7QUFBRSxLQWxEN0MsTUFtREksSUFBR0MsQ0FBQyxDQUFDUSxPQUFGLEdBQVcsRUFBZCxFQUFpQjtBQUFDLFdBQUtaLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDdkIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLEtBQXRCLEVBQTRCLEtBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUEzQztBQUNBLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixrQkFBdEI7QUFBMEMsS0FGckMsTUFFMkM7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2xELFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQyxXQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNoQyxXQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsbUJBQXRCO0FBQTJDO0FBRXpDLEdBelFNO0FBNFFUb0MsRUFBQUEsS0FBSyxFQUFDLGlCQUFVO0FBQUMsU0FBS3ZDLE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hCLFNBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQiwwQkFBdEI7QUFDQUMsSUFBQUEsQ0FBQyxDQUFDQyxHQUFGLEdBQU0sQ0FBTjtBQUNERCxJQUFBQSxDQUFDLENBQUNFLEdBQUYsR0FBTSxDQUFOO0FBQ0FGLElBQUFBLENBQUMsQ0FBQ0csR0FBRixHQUFNLENBQU47QUFDQUgsSUFBQUEsQ0FBQyxDQUFDSSxHQUFGLEdBQU0sQ0FBTjtBQUFRSixJQUFBQSxDQUFDLENBQUNvQyxHQUFGLEdBQU0sQ0FBTjtBQUFRcEMsSUFBQUEsQ0FBQyxDQUFDcUMsR0FBRixHQUFNLENBQU47O0FBQ2QsUUFBR3JDLENBQUMsQ0FBQ1EsT0FBRixHQUFXLENBQVgsR0FBY1IsQ0FBQyxDQUFDUSxPQUFGLEdBQVUsQ0FBM0IsRUFBNkI7QUFFN0JGLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFdBQVo7QUFDRCxVQUFJRSxHQUFHLEdBQUcvQixFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUVHLFVBQUlDLEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDWSxNQUFSLENBQVQ7QUFFSixVQUFJQyxNQUFNLEdBQUdDLElBQUksQ0FBQ0MsR0FBTCxDQUFTSixHQUFHLENBQUNLLENBQUosR0FBTVAsR0FBRyxDQUFDTyxDQUFuQixDQUFiO0FBQ0EsVUFBS0MsTUFBTSxHQUFHSCxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDTyxDQUFKLEdBQU1ULEdBQUcsQ0FBQ1MsQ0FBbkIsQ0FBZDtBQUNFWixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxTQUFaO0FBQ0FELE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZSSxHQUFaOztBQUVBLFVBQUlFLE1BQU0sSUFBSSxFQUFWLEdBQWNJLE1BQU0sSUFBRyxFQUEzQixFQUErQjtBQUFFakIsUUFBQUEsQ0FBQyxDQUFDb0MsR0FBRixHQUFNLENBQU47QUFBUTs7QUFBQTtBQUN6QyxVQUFJakIsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFFRSxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVKLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQSxVQUFLTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFkO0FBRUVaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNxQyxHQUFGLEdBQU0sQ0FBTjtBQUFROztBQUFBO0FBQ3pDLFVBQUlsQixHQUFHLEdBQUd6QyxFQUFFLENBQUNnQyxFQUFILENBQU0sR0FBTixFQUFVLEdBQVYsQ0FBVjtBQUNDLFVBQUlVLEdBQUcsR0FBRTFDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUYsVUFBSUMsTUFBTSxHQUFHUixJQUFJLENBQUNDLEdBQUwsQ0FBU0ssR0FBRyxDQUFDSixDQUFKLEdBQU1HLEdBQUcsQ0FBQ0gsQ0FBbkIsQ0FBYjtBQUNBLFVBQUtPLE1BQU0sR0FBR1QsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0YsQ0FBSixHQUFNQyxHQUFHLENBQUNELENBQW5CLENBQWQ7QUFFRVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFRixVQUFJZSxNQUFNLElBQUksRUFBVixHQUFlQyxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFBQ3ZCLFFBQUFBLENBQUMsQ0FBQ0UsR0FBRixHQUFNLENBQU47QUFBUzs7QUFBQTtBQUMxQyxVQUFJc0IsR0FBRyxHQUFHOUMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDRyxVQUFJZSxHQUFHLEdBQUUvQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ1ksTUFBUixDQUFUO0FBQ0gsVUFBSWMsTUFBTSxHQUFHWixJQUFJLENBQUNDLEdBQUwsQ0FBU1UsR0FBRyxDQUFDVCxDQUFKLEdBQU1RLEdBQUcsQ0FBQ1IsQ0FBbkIsQ0FBYjtBQUNBLFVBQUtXLE1BQU0sR0FBR2IsSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1AsQ0FBSixHQUFNTSxHQUFHLENBQUNOLENBQW5CLENBQWQ7QUFDRVosTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksU0FBWjs7QUFFQSxVQUFJbUIsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUUzQixRQUFBQSxDQUFDLENBQUNJLEdBQUYsR0FBTSxDQUFOO0FBQVM7O0FBQUE7QUFDNUMsVUFBSWUsR0FBRyxHQUFHekMsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLEdBQU4sRUFBVSxHQUFWLENBQVY7QUFDQyxVQUFJVSxHQUFHLEdBQUUxQyxFQUFFLENBQUNnQyxFQUFILENBQU1WLENBQUMsQ0FBQ3FCLEtBQVIsQ0FBVDtBQUVGLFVBQUlDLE1BQU0sR0FBR1IsSUFBSSxDQUFDQyxHQUFMLENBQVNLLEdBQUcsQ0FBQ0osQ0FBSixHQUFNRyxHQUFHLENBQUNILENBQW5CLENBQWI7QUFDQSxVQUFLTyxNQUFNLEdBQUdULElBQUksQ0FBQ0MsR0FBTCxDQUFTSyxHQUFHLENBQUNGLENBQUosR0FBTUMsR0FBRyxDQUFDRCxDQUFuQixDQUFkO0FBRUVaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUYsVUFBSWUsTUFBTSxJQUFJLEVBQVYsR0FBZUMsTUFBTSxJQUFHLEVBQTVCLEVBQWdDO0FBQUV2QixRQUFBQSxDQUFDLENBQUNDLEdBQUYsR0FBTyxDQUFQO0FBQVM7O0FBQUE7QUFDM0MsVUFBSXVCLEdBQUcsR0FBRzlDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxHQUFOLEVBQVUsR0FBVixDQUFWO0FBQ0csVUFBSWUsR0FBRyxHQUFFL0MsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVDtBQUNILFVBQUljLE1BQU0sR0FBR1osSUFBSSxDQUFDQyxHQUFMLENBQVNVLEdBQUcsQ0FBQ1QsQ0FBSixHQUFNUSxHQUFHLENBQUNSLENBQW5CLENBQWI7QUFDQSxVQUFLVyxNQUFNLEdBQUdiLElBQUksQ0FBQ0MsR0FBTCxDQUFTVSxHQUFHLENBQUNQLENBQUosR0FBTU0sR0FBRyxDQUFDTixDQUFuQixDQUFkO0FBQ0VaLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFNBQVo7O0FBRUEsVUFBSW1CLE1BQU0sSUFBSSxFQUFWLEdBQWVDLE1BQU0sSUFBRyxFQUE1QixFQUFnQztBQUFFM0IsUUFBQUEsQ0FBQyxDQUFDRyxHQUFGLEdBQU8sQ0FBUDtBQUFTOztBQUFBOztBQUU1QyxVQUFJSCxDQUFDLENBQUNLLEdBQUYsSUFBUSxLQUFaLEVBQWtCO0FBQ2xCLFlBQUlMLENBQUMsQ0FBQ0UsR0FBRixJQUFTLENBQVQsR0FBYUYsQ0FBQyxDQUFDRyxHQUFGLElBQVEsQ0FBekIsRUFBNEI7QUFBQyxlQUFLUCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQzVCLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFrQyxTQURuQyxNQUN3QyxJQUFJQyxDQUFDLENBQUNDLEdBQUYsSUFBUyxDQUFULEdBQWFELENBQUMsQ0FBQ0ksR0FBRixJQUFRLENBQXpCLEVBQTRCO0FBQUMsZUFBS1IsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNwRSxlQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsVUFBdEI7QUFBa0MsU0FESyxNQUNBLElBQUlDLENBQUMsQ0FBQ3FDLEdBQUYsSUFBUyxDQUFULEdBQWFyQyxDQUFDLENBQUNHLEdBQUYsSUFBUSxDQUF6QixFQUE0QjtBQUFDLGVBQUtQLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDcEUsZUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFVBQXRCO0FBQWtDLFNBREssTUFDQSxJQUFJQyxDQUFDLENBQUNvQyxHQUFGLElBQVMsQ0FBVCxHQUFhcEMsQ0FBQyxDQUFDQyxHQUFGLElBQVEsQ0FBekIsRUFBNEI7QUFBQyxlQUFLTCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3BFLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFrQyxTQURLLE1BQ0Q7QUFBQyxlQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ3ZDLGVBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixJQUF0QjtBQUEyQjtBQUFFLE9BTjlCLE1BTWtDO0FBQUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNwQyxhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsY0FBdEI7QUFBcUMsYUFBS0gsT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDcEMsYUFBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLHFCQUF0QjtBQUE2QztBQUFDLEtBaEU3QyxNQWlFSSxJQUFHQyxDQUFDLENBQUNRLE9BQUYsSUFBYSxDQUFoQixFQUFtQjtBQUFDLFdBQUtaLE9BQUwsR0FBZSxLQUFLb0MsSUFBTCxDQUFVbkMsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDeEIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQ0MsS0FGRyxNQUdMO0FBQUMsV0FBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNBLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixVQUF0QjtBQUFpQyxXQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNsQyxXQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsZ0NBQXRCO0FBQXdEO0FBSXRELEdBNVZNO0FBOFZUdUMsRUFBQUEsS0FBSyxFQUFDLGlCQUFVO0FBQ2hCLFFBQUd0QyxDQUFDLENBQUNRLE9BQUYsSUFBWSxDQUFmLEVBQWtCO0FBQUMsV0FBS1osT0FBTCxHQUFlLEtBQUtGLElBQUwsQ0FBVUcsWUFBVixDQUF1Qm5CLEVBQUUsQ0FBQ29CLEtBQTFCLENBQWY7QUFDbEIsV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLGNBQXRCO0FBQ0MsV0FBS0gsT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNELFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixNQUF0QjtBQUNDTyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxXQUFaO0FBQ0QsVUFBSUUsR0FBRyxHQUFHL0IsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNVixDQUFDLENBQUNZLE1BQVIsQ0FBVjtBQUVFLFVBQUlELEdBQUcsR0FBRWpDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTVYsQ0FBQyxDQUFDcUIsS0FBUixDQUFUO0FBRUgsVUFBSVIsTUFBTSxHQUFHQyxJQUFJLENBQUNDLEdBQUwsQ0FBU0osR0FBRyxDQUFDSyxDQUFKLEdBQU1QLEdBQUcsQ0FBQ08sQ0FBbkIsQ0FBYjtBQUNDLFVBQUlDLE1BQU0sR0FBR0gsSUFBSSxDQUFDQyxHQUFMLENBQVNKLEdBQUcsQ0FBQ08sQ0FBSixHQUFNVCxHQUFHLENBQUNTLENBQW5CLENBQWI7QUFDQ1osTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVlQLENBQUMsQ0FBQ1ksTUFBZDtBQUNBTixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWVAsQ0FBQyxDQUFDcUIsS0FBZDs7QUFFQSxVQUFJUixNQUFNLElBQUksRUFBVixHQUFlSSxNQUFNLElBQUcsRUFBNUIsRUFBZ0M7QUFDbEMsYUFBS3NCLE9BQUwsR0FBZTdELEVBQUUsQ0FBQzhELFdBQUgsQ0FBZUMsSUFBZixDQUFvQixLQUFLbkQsT0FBekIsRUFBa0MsS0FBbEMsRUFBeUMsQ0FBekMsQ0FBZjtBQUNBO0FBQUMsYUFBS00sT0FBTCxHQUFlLEtBQUtvQyxJQUFMLENBQVVuQyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUNDLGFBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixJQUF0QjtBQUEyQixhQUFLSCxPQUFMLEdBQWUsS0FBS0YsSUFBTCxDQUFVRyxZQUFWLENBQXVCbkIsRUFBRSxDQUFDb0IsS0FBMUIsQ0FBZjtBQUM1QixhQUFLRixPQUFMLENBQWFHLE1BQWIsR0FBc0IsUUFBdEI7QUFBZ0M7O0FBQUE7QUFFaEMsS0FwQkQsTUFzQks7QUFBQyxXQUFLSCxPQUFMLEdBQWUsS0FBS29DLElBQUwsQ0FBVW5DLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ0osV0FBS0YsT0FBTCxDQUFhRyxNQUFiLEdBQXNCLFFBQXRCO0FBQStCLFdBQUtILE9BQUwsR0FBZSxLQUFLRixJQUFMLENBQVVHLFlBQVYsQ0FBdUJuQixFQUFFLENBQUNvQixLQUExQixDQUFmO0FBQ2hDLFdBQUtGLE9BQUwsQ0FBYUcsTUFBYixHQUFzQixvQkFBdEI7QUFBNEM7QUFDNUMsR0F4WFE7QUEyWFIyQyxFQUFBQSxNQUFNLEVBQUMsa0JBQVU7QUFBQzFDLElBQUFBLENBQUMsQ0FBQ1EsT0FBRixJQUFhLENBQWI7QUFDakJGLElBQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLFFBQVo7QUFDQSxRQUFJb0MsQ0FBQyxHQUFFLEtBQUs3RCxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBQ0MsUUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLElBQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLElBQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLElBQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUNELFFBQUlHLENBQUMsR0FBRSxLQUFLN0QsV0FBTCxDQUFpQjJELHFCQUFqQixDQUF1Q2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUF2QyxDQUFQO0FBRUNvQyxJQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsSUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUO0FBQ0YsU0FBS2hFLFNBQUwsQ0FBZWlFLEVBQWYsQ0FBa0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JDLFdBQXBDLEVBQWlELFVBQVNDLENBQVQsRUFBVztBQUFDLFVBQUlsRCxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ2pHLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSWxDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2hCLEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUR4RyxFQUN5RyxJQUR6RztBQUdBLFNBQUtyRCxXQUFMLENBQWlCOEQsRUFBakIsQ0FBb0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JDLFdBQXRDLEVBQW1ELFVBQVNDLENBQVQsRUFBVztBQUFDLFVBQUlsRCxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ25HLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBRnBFLEVBRXFFLElBRnJFO0FBSUFoQyxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsU0FBS3pCLFNBQUwsQ0FBZWlFLEVBQWYsQ0FBa0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JJLFVBQXBDLEVBQStDLFVBQVNGLENBQVQsRUFBVztBQUFDNUMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksTUFBWjtBQUczRCxVQUFJdUMsQ0FBQyxHQUFFLEtBQUtoRSxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBRUVvQyxNQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsTUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUO0FBRUEsVUFBSU8sR0FBRyxHQUFHSCxDQUFDLENBQUNJLFFBQUYsRUFBVjtBQUNBLFdBQUt4RSxTQUFMLENBQWVrQyxDQUFmLElBQW9CcUMsR0FBRyxDQUFDckMsQ0FBeEI7QUFDQSxXQUFLbEMsU0FBTCxDQUFlb0MsQ0FBZixJQUFvQm1DLEdBQUcsQ0FBQ25DLENBQXhCO0FBTUYsVUFBSXlCLENBQUMsR0FBRSxLQUFLMUQsV0FBTCxDQUFpQjJELHFCQUFqQixDQUF1Q2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUF2QyxDQUFQO0FBQ0UsVUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLE1BQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLE1BQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLE1BQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUNGOztBQUFDLFVBQUkzQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ3JDLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBeEJwRSxFQXdCcUUsSUF4QnJFO0FBeUJBaEMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVBLFNBQUt0QixXQUFMLENBQWlCOEQsRUFBakIsQ0FBb0JyRSxFQUFFLENBQUNNLElBQUgsQ0FBUWdFLFNBQVIsQ0FBa0JJLFVBQXRDLEVBQWlELFVBQVNGLENBQVQsRUFBVztBQUFDNUMsTUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUFxQixVQUFJb0MsQ0FBQyxHQUFFLEtBQUsxRCxXQUFMLENBQWlCMkQscUJBQWpCLENBQXVDbEUsRUFBRSxDQUFDZ0MsRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQXZDLENBQVA7QUFDaEYsVUFBSW1DLEVBQUUsR0FBR25FLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxJQUFOLEVBQVcsQ0FBQyxJQUFaLENBQVQ7QUFDR2lDLE1BQUFBLENBQUMsQ0FBQzNCLENBQUYsSUFBTzZCLEVBQUUsQ0FBQzdCLENBQVY7QUFDSDJCLE1BQUFBLENBQUMsQ0FBQ3pCLENBQUYsSUFBTzJCLEVBQUUsQ0FBQzNCLENBQVY7QUFFQWxCLE1BQUFBLENBQUMsQ0FBQ3FCLEtBQUYsR0FBUzNDLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTWlDLENBQU4sQ0FBVDtBQUVBLFVBQUlVLEdBQUcsR0FBR0gsQ0FBQyxDQUFDSSxRQUFGLEVBQVY7QUFDQSxXQUFLckUsV0FBTCxDQUFpQitCLENBQWpCLElBQXNCcUMsR0FBRyxDQUFDckMsQ0FBMUI7QUFDQSxXQUFLL0IsV0FBTCxDQUFpQmlDLENBQWpCLElBQXNCbUMsR0FBRyxDQUFDbkMsQ0FBMUI7QUFDQSxVQUFJNEIsQ0FBQyxHQUFFLEtBQUtoRSxTQUFMLENBQWU4RCxxQkFBZixDQUFxQ2xFLEVBQUUsQ0FBQ2dDLEVBQUgsQ0FBTSxDQUFOLEVBQVMsQ0FBVCxDQUFyQyxDQUFQO0FBRUFvQyxNQUFBQSxDQUFDLENBQUM1QixDQUFGLEdBQU00QixDQUFDLENBQUM1QixDQUFGLEdBQUksS0FBVjtBQUNBbEIsTUFBQUEsQ0FBQyxDQUFDWSxNQUFGLEdBQVNrQyxDQUFUOztBQUNGLFVBQUk5QyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUt4RCxLQUFMO0FBQWEsT0FBL0IsTUFBb0MsSUFBSUssQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLbEIsS0FBTDtBQUFhLE9BQS9CLE1BQ3BDLElBQUlqQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtqQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbEMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLaEIsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBaEJwRSxFQWdCcUUsSUFoQnJFO0FBaUJBLFNBQUtuRCxPQUFMLENBQWE0RCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCQyxXQUFsQyxFQUE4QyxVQUFTQyxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQzFELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtuRCxPQUFMLENBQWE0RCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQ3hELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtsRCxPQUFMLENBQWEyRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCQyxXQUFsQyxFQUE4QyxVQUFTQyxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQzFELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUpoQyxFQUlpQyxJQUpqQztBQUtBLFNBQUtsRCxPQUFMLENBQWEyRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7O0FBQ3hELFVBQUlQLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFFcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQUxoQyxFQUtpQyxJQUxqQztBQU1BLFNBQUtqRCxPQUFMLENBQWEwRCxFQUFiLENBQWdCckUsRUFBRSxDQUFDTSxJQUFILENBQVFnRSxTQUFSLENBQWtCTyxTQUFsQyxFQUE0QyxVQUFTTCxDQUFULEVBQVc7QUFBQzVDLE1BQUFBLE9BQU8sQ0FBQ0MsR0FBUixDQUFZLE9BQVo7QUFBcUIsV0FBS2QsT0FBTCxDQUFhK0QsUUFBYixJQUF5QixFQUF6QjtBQUMzRXhELE1BQUFBLENBQUMsQ0FBQ1EsT0FBRixJQUFZLENBQVo7O0FBQ0EsVUFBR1IsQ0FBQyxDQUFDUSxPQUFGLElBQWEsQ0FBQyxDQUFqQixFQUFtQjtBQUFDUixRQUFBQSxDQUFDLENBQUNRLE9BQUYsR0FBVSxFQUFWO0FBQWM7O0FBQUE7O0FBQ3BDLFVBQUlSLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS3hELEtBQUw7QUFBYSxPQUEvQixNQUFvQyxJQUFJSyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtsQixLQUFMO0FBQWEsT0FBL0IsTUFDcEMsSUFBSWpDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2pCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUlsQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtoQixLQUFMO0FBQWEsT0FBL0IsTUFDQSxJQUFJbkMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLYixLQUFMO0FBQWE7QUFBQyxLQU5oQyxFQU1pQyxJQU5qQztBQU9BaEMsSUFBQUEsT0FBTyxDQUFDQyxHQUFSLENBQVksT0FBWjtBQUVBRCxJQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQ0EsU0FBS2YsT0FBTCxDQUFhdUQsRUFBYixDQUFnQnJFLEVBQUUsQ0FBQ00sSUFBSCxDQUFRZ0UsU0FBUixDQUFrQk8sU0FBbEMsRUFBNEMsVUFBU0wsQ0FBVCxFQUFXO0FBQUM1QyxNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxPQUFaO0FBQXNCLFdBQUtkLE9BQUwsQ0FBYStELFFBQWIsSUFBeUIsRUFBekI7QUFDNUV4RCxNQUFBQSxDQUFDLENBQUNRLE9BQUYsSUFBWSxDQUFaOztBQUNBLFVBQUdSLENBQUMsQ0FBQ1EsT0FBRixJQUFhLEVBQWhCLEVBQW1CO0FBQUNSLFFBQUFBLENBQUMsQ0FBQ1EsT0FBRixHQUFVLENBQVY7QUFBYTs7QUFBQTs7QUFDbkMsVUFBSVIsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLeEQsS0FBTDtBQUFhLE9BQS9CLE1BQW9DLElBQUlLLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2xCLEtBQUw7QUFBYSxPQUEvQixNQUNwQyxJQUFJakMsQ0FBQyxDQUFDbUQsT0FBRixJQUFXLENBQWYsRUFBaUI7QUFBQyxhQUFLakIsS0FBTDtBQUFhLE9BQS9CLE1BQ0EsSUFBSWxDLENBQUMsQ0FBQ21ELE9BQUYsSUFBVyxDQUFmLEVBQWlCO0FBQUMsYUFBS2hCLEtBQUw7QUFBYSxPQUEvQixNQUNBLElBQUluQyxDQUFDLENBQUNtRCxPQUFGLElBQVcsQ0FBZixFQUFpQjtBQUFDLGFBQUtiLEtBQUw7QUFBYTtBQUFDLEtBTmhDLEVBTWlDLElBTmpDO0FBUUMsR0FsZU87QUFtZUxtQixFQUFBQSxLQW5lSyxtQkFtZUksQ0FFUixDQXJlSSxDQXVlTDs7QUF2ZUssQ0FBVCIsInNvdXJjZVJvb3QiOiIvIiwic291cmNlc0NvbnRlbnQiOlsiLy8gTGVhcm4gY2MuQ2xhc3M6XHJcbi8vICAtIGh0dHBzOi8vZG9jcy5jb2Nvcy5jb20vY3JlYXRvci9tYW51YWwvZW4vc2NyaXB0aW5nL2NsYXNzLmh0bWxcclxuLy8gTGVhcm4gQXR0cmlidXRlOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9yZWZlcmVuY2UvYXR0cmlidXRlcy5odG1sXHJcbi8vIExlYXJuIGxpZmUtY3ljbGUgY2FsbGJhY2tzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9saWZlLWN5Y2xlLWNhbGxiYWNrcy5odG1sXHJcblxyXG5jYy5DbGFzcyh7XHJcbiAgICBleHRlbmRzOiBjYy5Db21wb25lbnQsXHJcblxyXG4gICAgcHJvcGVydGllczoge1xyXG4gICAgICAgIC8vIGZvbzoge1xyXG4gICAgICAgIC8vICAgICAvLyBBVFRSSUJVVEVTOlxyXG4gICAgICAgIC8vICAgICBkZWZhdWx0OiBudWxsLCAgICAgICAgLy8gVGhlIGRlZmF1bHQgdmFsdWUgd2lsbCBiZSB1c2VkIG9ubHkgd2hlbiB0aGUgY29tcG9uZW50IGF0dGFjaGluZ1xyXG4gICAgICAgIC8vICAgICAgICAgICAgICAgICAgICAgICAgICAgLy8gdG8gYSBub2RlIGZvciB0aGUgZmlyc3QgdGltZVxyXG4gICAgICAgIC8vICAgICB0eXBlOiBjYy5TcHJpdGVGcmFtZSwgLy8gb3B0aW9uYWwsIGRlZmF1bHQgaXMgdHlwZW9mIGRlZmF1bHRcclxuICAgICAgICAvLyAgICAgc2VyaWFsaXphYmxlOiB0cnVlLCAgIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHRydWVcclxuICAgICAgICAvLyB9LFxyXG4gICAgICAgIC8vIGJhcjoge1xyXG4gICAgICAgIC8vICAgICBnZXQgKCkge1xyXG4gICAgICAgIC8vICAgICAgICAgcmV0dXJuIHRoaXMuX2JhcjtcclxuICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAvLyAgICAgc2V0ICh2YWx1ZSkge1xyXG4gICAgICAgIC8vICAgICAgICAgdGhpcy5fYmFyID0gdmFsdWU7XHJcbiAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAvLyB9LFxyXG5cdFx0cGxheWVycmVkOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyYmxhY2s6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXJibGFjazE6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXIyOiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuICAgICAgICB9LFxyXG5cdFx0cGxheWVyMzoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjQ6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXI1OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLkF1ZGlvQ2xpcFxyXG4gICAgICAgIH0sXHJcblx0XHRwbGF5ZXI2OiB7XHJcbiAgICAgICAgICAgIGRlZmF1bHQ6IG51bGwsXHJcbiAgICAgICAgICAgIHR5cGU6IGNjLk5vZGVcclxuXHRcdFx0XHJcbiAgICAgICAgfSxcclxuXHRcdHBsYXllcjc6IHtcclxuICAgICAgICAgICAgZGVmYXVsdDogbnVsbCxcclxuICAgICAgICAgICAgdHlwZTogY2MuTm9kZVxyXG5cdFx0XHRcclxuICAgICAgICB9LFxyXG5cdFx0dGlwcDoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcblx0XHRcdFxyXG4gICAgICAgIH0sXHJcblx0XHRcclxuICAgIH0sXHJcblxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcblxyXG4gICAgXHJcbiB0aW1lMTpmdW5jdGlvbigpe3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+S4h+eUqOihqOWFs+mXreaXtumAieaLqeWFs+mXreaho+aIluiAheeUteWOi+acgOmrmOahoyc7XHJcbkcuYnRyPTA7XHJcbkcuYnRiPTA7XHJcbkcucnRyPTA7XHJcbkcucnRiPTA7XHJcblx0IFxyXG5cdCBpZihHLnJlZCA9PSBmYWxzZSl7XHJcblx0ICBjb25zb2xlLmxvZyhcInM1c2RcIik7XHJcblx0IGlmKEcuZGFuZ3dlaSA+OSAmIEcuZGFuZ3dlaTwxNSApe1xyXG5cdFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGQ1NDVzZFwiKTtcclxuXHR2YXIgcHUxID0gY2MudjIoNjI5LDMwMik7XHJcblx0ICBcclxuXHQgICB2YXIgcHUyID1jYy52MihHLmhvbmdiaSk7XHJcblx0ICAgXHJcbnZhciByZWR0b3ggPSBNYXRoLmFicyhwdTIueC1wdTEueCk7IFxyXG4gdmFyIHJlZHRveSA9KE1hdGguYWJzKHB1Mi55LXB1MS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgY29uc29sZS5sb2cocHUyKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gNTAgJiByZWR0b3kgPD01MCApe0cucnRyID0gMTt9O1xyXG5cdCB2YXIgcHkxID0gY2MudjIoNjI5LDMyMCk7XHJcblx0ICBcclxuXHQgICB2YXIgcHkyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRweCA9IE1hdGguYWJzKHB5Mi54LXB5MS54KTsgXHJcbnZhciAgcmVkdHB5ID0oTWF0aC5hYnMocHkyLnktcHkxLnkpKTtcclxuXHQgXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgXHJcbmlmIChyZWR0cHggPD0gNTAgJiByZWR0cHkgPD01MCApe0cuYnRyID0gMTt9O1xyXG5cclxudmFyIHBzMSA9IGNjLnYyKDg1OCwzNzkpO1xyXG5cdCAgdmFyIHBzMiA9Y2MudjIoRy5ob25nYmkpO1xyXG52YXIgcmVkdHF4ID0gTWF0aC5hYnMocHMyLngtcHMxLngpOyBcclxuIHZhciByZWR0cXkgPShNYXRoLmFicyhwczIueS1wczEueSkpO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblxyXG5cdCBpZiAocmVkdHF4IDw9IDUwICYgcmVkdHF5IDw9NTAgKXtHLnJ0YiA9IDE7fTtcclxuXHJcbnZhciBwbDEgPSBjYy52Mig4NTgsMzc5KTtcclxuXHQgIHZhciBwbDIgPWNjLnYyKEcuaGVpYmkpO1xyXG52YXIgcmVkdGMgPSBNYXRoLmFicyhwbDIueC1wbDEueCk7IFxyXG4gdmFyIHJlZHRnID0oTWF0aC5hYnMocGwyLnktcGwxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdFxyXG5cdCBpZiAocmVkdGMgPD0gNTAgJiByZWR0ZyA8PTUwICl7Ry5idGIgPSAxO307XHJcblxyXG5jb25zb2xlLmxvZyhHLnJ0cik7XHJcbiBjb25zb2xlLmxvZyhHLmJ0Yik7XHJcbiBpZiAoRy5ydHI9PTEgJiBHLmJ0Yj09MSl7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAnNTAuMDDOqSc7fSBlbHNlIGlmIChHLmJ0cj09MSAmIEcucnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICc1MC4wMM6pJzt9ZWxzZXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+aVsOWtl+W8j+S4h+eUqOihqOeahOe6ouihqOeslOaOpeato+aegSc7fX1cclxuIGVsc2VcclxuXHQge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+iwg+iHs+eUtemYu+ahoyc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJzt9fVxyXG5cdCBlbHNle3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7flsIbnuqLooajnrJTosIPoh7PnlLXpmLvkvY0nO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+W9k+WJjee6ouihqOeslOaho+S9jemUmeivryc7fVxyXG5cdCBcclxuXHQgfSxcclxuXHQgXHJcbnRpbWUyOmZ1bmN0aW9uKCl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5rWL6YeP55S15rWB5pe26KaB5ZKM6LSf6L295Liy6IGUXFxu5LiH55So6KGo5Y+q6IO95rWL6YeP5b6u5bCP55S15rWBJztcclxuXHRHLmJ0cj0wO1xyXG5HLmJ0Yj0wO1xyXG5HLnJ0cj0wO1xyXG5HLnJ0Yj0wO1xyXG5cdCBjb25zb2xlLmxvZyhcIjk5ZFwiKTtcclxuXHQgaWYoRy5kYW5nd2VpID4yICYgRy5kYW5nd2VpPDcgKXtcclxuXHRcdFxyXG5cdCBcclxuXHR2YXIgcHUxID0gY2MudjIoNzMzLDMwMSk7XHJcblx0ICBcclxuXHQgICB2YXIgcHUyID1jYy52MihHLmhvbmdiaSk7XHJcblx0ICAgXHJcbnZhciByZWR0b3ggPSBNYXRoLmFicyhwdTIueC1wdTEueCk7IFxyXG4gdmFyIHJlZHRveSA9KE1hdGguYWJzKHB1Mi55LXB1MS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgY29uc29sZS5sb2cocHUyKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gMTAgJiByZWR0b3kgPD0xMCApeyBHLnJ0YiA9MX07XHJcblx0IHZhciBweTEgPSBjYy52Mig3MzMsMzAxKTtcclxuXHQgIFxyXG5cdCAgIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxuIHZhciByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7IEcuYnRiID0xfTtcclxuIHZhciBweTEgPSBjYy52Mig3NjIsMzAzKTtcclxuICB2YXIgcHkyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRweCA9IE1hdGguYWJzKHB5Mi54LXB5MS54KTsgXHJcbiB2YXIgcmVkdHB5ID0oTWF0aC5hYnMocHkyLnktcHkxLnkpKTtcclxuXHQgXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHQgXHJcbmlmIChyZWR0cHggPD0gMTMgJiByZWR0cHkgPD0xMyApeyBHLmJ0ciA9MX07XHJcbnZhciBwczEgPSBjYy52Mig3NjIsMzAzKTtcclxuXHQgIHZhciBwczIgPWNjLnYyKEcuaG9uZ2JpKTtcclxudmFyIHJlZHRxeCA9IE1hdGguYWJzKHBzMi54LXBzMS54KTsgXHJcbiB2YXIgcmVkdHF5ID0oTWF0aC5hYnMocHMyLnktcHMxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cclxuXHQgaWYgKHJlZHRxeCA8PSAxMyAmIHJlZHRxeSA8PTEzICl7IEcucnRyID0xfTtcclxuXHJcblxyXG5cclxuXHRpZiAoRy5yZWQgPT1mYWxzZSl7XHJcblx0aWYgKEcucnRyPT0xICYgRy5idGI9PTEpe3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJzI1LjMwbUEnO31cclxuXHQgZWxzZSBpZihHLnJ0Yj09MSAmIEcuYnRyPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJy0yNS4zMG1BJ319IFxyXG4gZWxzZVxyXG5cdGlmIChHLnJ0cj09MSAmIEcuYnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJzAuMDI1QSd9ZWxzZSBpZihHLnJ0Yj09MSAmIEcuYnRyPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJy0wLjAyNUEnfSBlbHNlIHt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5pWw5a2X5byP5LiH55So6KGo55qE57qi6KGo56yU5o6l5q2j5p6BJ319IFxyXG5cdGVsc2V7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7flsIbosIPoh7Pnm7TmtYHnlLXmtYHmoaMnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5qGj5L2N6ZSZ6K+vJ31cclxuXHRcclxuXHQgfSxcclxuXHQgXHRcclxuXHRcdFxyXG50aW1lMzpmdW5jdGlvbigpe3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5rWL6YeP55S15Y6L5pe257qi6KGo56yU6YCJ5oup55S15rWB5qGj5Lya5o2f5Z2P5LiH55So6KGoJztcclxuXHRHLmJ0cj0wO1xyXG5HLmJ0Yj0wO1xyXG5HLnJ0cj0wO1xyXG5HLnJ0Yj0wO1xyXG5jb25zb2xlLmxvZyhcIjg1NDc1XCIpO1xyXG5cdCBpZihHLmRhbmd3ZWkgPjE2ICYgRy5kYW5nd2VpPDIwICl7XHJcblx0XHRcclxuXHQgY29uc29sZS5sb2coXCJzYWRkNTQ1c2RcIik7XHJcblx0dmFyIHB1MSA9IGNjLnYyKDgyNiwzMDMpO1xyXG5cdCAgXHJcblx0ICAgdmFyIHB1MiA9Y2MudjIoRy5ob25nYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdG94ID0gTWF0aC5hYnMocHUyLngtcHUxLngpOyBcclxuIHZhciByZWR0b3kgPShNYXRoLmFicyhwdTIueS1wdTEueSkpO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IGNvbnNvbGUubG9nKHB1Mik7XHJcblx0IFxyXG5cdCBpZiAocmVkdG94IDw9IDMwJiByZWR0b3kgPD0zMCApeyBHLnJ0Yj0xfTtcclxuXHQgdmFyIHB5MSA9IGNjLnYyKDgyNiwzMDMpO1xyXG5cdCAgXHJcblx0ICAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG4gdmFyIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDMwICYgcmVkdHB5IDw9IDMwKXsgRy5idGI9MX07XHJcbiB2YXIgcHkxID0gY2MudjIoNzY2LDI2MSk7XHJcbiAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG4gdmFyIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDMwICYgcmVkdHB5IDw9MzAgKXsgRy5idHI9MX07XHJcbnZhciBwczEgPSBjYy52Mig3NjYsMjYxKTtcclxuXHQgIHZhciBwczIgPWNjLnYyKEcuaG9uZ2JpKTtcclxudmFyIHJlZHRxeCA9IE1hdGguYWJzKHBzMi54LXBzMS54KTsgXHJcbiB2YXIgcmVkdHF5ID0oTWF0aC5hYnMocHMyLnktcHMxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cclxuXHQgaWYgKHJlZHRxeCA8PSAzMCAmIHJlZHRxeSA8PTMwICl7IEcucnRyPTF9O1xyXG5cclxuICAgY29uc29sZS5sb2coXCI1NVwiKTtcclxuXHRpZiAoRy5yZWQ9PWZhbHNlKXsgY29uc29sZS5sb2coXCJzYTU1NTU1XCIpO1xyXG5cdGlmIChHLnJ0cj09MSAmIEcuYnRiPT0xKXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICc2LjE1Vic7fWVsc2UgaWYoRy5idHI9PTEgJiBHLnJ0Yj09MSl7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAnLTYuMTVWJ31lbHNlIHt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICfor7fmjqXop6bpu5HnuqLooajnrJQnO3RoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5bCG6buR57qi6KGo56yU5pS+572u5Yiw5Yqg5Lqu55qE5qCH6K6w5aSEJ319XHJcbiBlbHNlXHJcblx0e3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+Wwhue6ouihqOeslOiwg+iHs+eUteWOi+S9jScsdGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bnuqLooajnrJTpgInmi6nnlLXmtYHmoaPkvJrmjZ/lnY/kuIfnlKjooagnfSB9XHJcbiBlbHNlIGlmKEcuZGFuZ3dlaSA+MTIpe3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG4gdGhpcy5teUxhYmVsLnN0cmluZyA9ICfotoXph4/nqIsnLHRoaXMubXlMYWJlbCA9IHRoaXMudGlwcC5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5L2O55S15Y6L5qGj5rWL6auY55S15Y6L5Y+v6IO95Lya5o2f5Z2P5LiH55So6KGoJzt9IGVsc2Uge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG50aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+iwg+iHs+ebtOa1geeUteWOi+S9jSc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bkvb/nlKjplJnor6/moaPkvY3kvJrmjZ/lnY/kuIfnlKjooagnO31cclxuXHRcclxuXHQgfSxcclxuXHQgICBcclxuXHQgXHJcbnRpbWU0OmZ1bmN0aW9uKCl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICforablkYrvvJrkvb/nlKjkuIfnlKjooajmtYvph4/ovoPpq5jnlLXljovml7ZcXG7lv4Xpobvkvb/nlKjkuqTmtYHmoaMnO1xyXG5cdEcuYnRyPTA7XHJcbkcuYnRiPTA7XHJcbkcucnRyPTA7XHJcbkcucnRiPTA7Ry5ydGc9MDtHLmJ0Zz0wO1xyXG5cdCBpZihHLmRhbmd3ZWkgPjAmIEcuZGFuZ3dlaTwyKXtcclxuXHJcblx0IGNvbnNvbGUubG9nKFwic2FkZDU0NXNkXCIpO1xyXG5cdHZhciBwdTEgPSBjYy52Mig3NDAsMzQ1KTtcclxuXHQgIFxyXG5cdCAgIHZhciBwdTIgPWNjLnYyKEcuaG9uZ2JpKTtcclxuXHQgICBcclxudmFyIHJlZHRveCA9IE1hdGguYWJzKHB1Mi54LXB1MS54KTsgXHJcbnZhciAgcmVkdG95ID0oTWF0aC5hYnMocHUyLnktcHUxLnkpKTtcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBjb25zb2xlLmxvZyhwdTIpO1xyXG5cdCBcclxuXHQgaWYgKHJlZHRveCA8PSAxMCYgcmVkdG95IDw9MTAgKXsgRy5ydGc9MX07XHJcblx0IHZhciBweTEgPSBjYy52Mig3NDAsMzQ1KTtcclxuXHQgIFxyXG5cdCAgIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxudmFyICByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7IEcuYnRnPTF9O1xyXG4gdmFyIHB5MSA9IGNjLnYyKDcyNCwzMTkpO1xyXG4gIHZhciBweTIgPWNjLnYyKEcuaGVpYmkpO1xyXG5cdCAgIFxyXG52YXIgcmVkdHB4ID0gTWF0aC5hYnMocHkyLngtcHkxLngpOyBcclxudmFyICByZWR0cHkgPShNYXRoLmFicyhweTIueS1weTEueSkpO1xyXG5cdCBcclxuXHQgY29uc29sZS5sb2coXCJzYWRkYXNkXCIpO1xyXG5cdCBcclxuaWYgKHJlZHRweCA8PSAxMCAmIHJlZHRweSA8PTEwICl7Ry5idGI9MTt9O1xyXG52YXIgcHMxID0gY2MudjIoNzI0LDMxOSk7XHJcblx0ICB2YXIgcHMyID1jYy52MihHLmhvbmdiaSk7XHJcbnZhciByZWR0cXggPSBNYXRoLmFicyhwczIueC1wczEueCk7IFxyXG52YXIgIHJlZHRxeSA9KE1hdGguYWJzKHBzMi55LXBzMS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHJcblx0IGlmIChyZWR0cXggPD0gMTAgJiByZWR0cXkgPD0xMCApeyBHLnJ0Yj0xO307XHJcbiB2YXIgcHkxID0gY2MudjIoNzU5LDMxOSk7XHJcbiAgdmFyIHB5MiA9Y2MudjIoRy5oZWliaSk7XHJcblx0ICAgXHJcbnZhciByZWR0cHggPSBNYXRoLmFicyhweTIueC1weTEueCk7IFxyXG52YXIgIHJlZHRweSA9KE1hdGguYWJzKHB5Mi55LXB5MS55KSk7XHJcblx0IFxyXG5cdCBjb25zb2xlLmxvZyhcInNhZGRhc2RcIik7XHJcblx0IFxyXG5pZiAocmVkdHB4IDw9IDEwICYgcmVkdHB5IDw9MTAgKXsgRy5idHIgPTF9O1xyXG52YXIgcHMxID0gY2MudjIoNzU5LDMxOSk7XHJcblx0ICB2YXIgcHMyID1jYy52MihHLmhvbmdiaSk7XHJcbnZhciByZWR0cXggPSBNYXRoLmFicyhwczIueC1wczEueCk7IFxyXG52YXIgIHJlZHRxeSA9KE1hdGguYWJzKHBzMi55LXBzMS55KSk7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkZGFzZFwiKTtcclxuXHJcblx0IGlmIChyZWR0cXggPD0gMTAgJiByZWR0cXkgPD0xMCApeyBHLnJ0ciA9MX07XHJcblxyXG5cdGlmIChHLnJlZCA9PWZhbHNlKXtcclxuXHRpZiAoRy5idGIgPT0gMSAmIEcucnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5idHIgPT0gMSAmIEcucnRiID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5idGcgPT0gMSAmIEcucnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZSBpZiAoRy5ydGcgPT0gMSAmIEcuYnRyID09MSkge3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG5cdCB0aGlzLm15TGFiZWwuc3RyaW5nID0gJ34yMjQuMjBWJzt9ZWxzZXt0aGlzLm15TGFiZWwgPSB0aGlzLm5vZGUuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHQgdGhpcy5teUxhYmVsLnN0cmluZyA9ICcwVid9IH1lbHNle3RoaXMubXlMYWJlbCA9IHRoaXMubm9kZS5nZXRDb21wb25lbnQoY2MuTGFiZWwpO1xyXG50aGlzLm15TGFiZWwuc3RyaW5nID0gJ+ivt+Wwhue6ouihqOeslOaOpeiHs+S6pOa1geeUteWOi+S9jSc7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICfmtYvph4/nlLXljovml7bnuqLooajnrJTpgInmi6nnlLXmtYHmoaPkvJrmjZ/lnY/kuIfnlKjooagnO319XHJcbiBlbHNlIGlmKEcuZGFuZ3dlaSA9PSAyKSB7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b2T5YmN6YeP56iL5aSq5bCPJztcclxuXHQgfWVsc2VcclxuXHR7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn5b+F6aG75L2/55So5Lqk5rWB5qGj5L2NJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+a1i+mHj+mrmOeUteWOi+aXtuS9v+eUqOmUmeivr+aho+S9jeS8mumAoOaIkOWNsemZqSFcXG7lvZPliY3kuIfnlKjooajlt7Loh6rliqjmlq3ot68nO30gXHJcblx0IFxyXG4gXHJcblx0XHJcblx0IH0sXHJcblxyXG50aW1lNTpmdW5jdGlvbigpe1xyXG5pZihHLmRhbmd3ZWkgPT05ICl7dGhpcy5teUxhYmVsID0gdGhpcy50aXBwLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICflsIbnuqLpu5HooajnrJTnn63mjqXku6XmtYvph4/pgJrot68nO1xyXG5cdFx0dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0dGhpcy5teUxhYmVsLnN0cmluZyA9ICflh4blpIfoh6rmo4AnO1xyXG5cdCBjb25zb2xlLmxvZyhcInNhZGQ1NDVzZFwiKTtcclxuXHR2YXIgcHUxID0gY2MudjIoRy5ob25nYmkpO1xyXG5cdCAgXHJcblx0ICB2YXIgcHUyID1jYy52MihHLmhlaWJpKTtcclxuXHQgICBcclxudmFyIHJlZHRveCA9IE1hdGguYWJzKHB1Mi54LXB1MS54KTsgXHJcbiB2YXIgcmVkdG95ID0oTWF0aC5hYnMocHUyLnktcHUxLnkpKTtcclxuXHQgY29uc29sZS5sb2coRy5ob25nYmkpO1xyXG5cdCBjb25zb2xlLmxvZyhHLmhlaWJpKTtcclxuXHQgXHJcblx0IGlmIChyZWR0b3ggPD0gMTAgJiByZWR0b3kgPD0xMCApe1xyXG50aGlzLmN1cnJlbnQgPSBjYy5hdWRpb0VuZ2luZS5wbGF5KHRoaXMucGxheWVyNSwgZmFsc2UsIDEpO1xyXG47dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn6YCa6L+HJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+S7hemqjOivgeS4uumAmui3ryc7fTtcclxuXHRcclxufVxyXG5cclxuZWxzZSB7dGhpcy5teUxhYmVsID0gdGhpcy5ub2RlLmdldENvbXBvbmVudChjYy5MYWJlbCk7XHJcblx0IHRoaXMubXlMYWJlbC5zdHJpbmcgPSAn6K+36LCD6Iez6Ieq5qOA5qGjJzt0aGlzLm15TGFiZWwgPSB0aGlzLnRpcHAuZ2V0Q29tcG9uZW50KGNjLkxhYmVsKTtcclxuXHR0aGlzLm15TGFiZWwuc3RyaW5nID0gJ+mUmeivr+aho+S9jee6oum7keihqOeslOefreaOpeWPr+iDveS8mueul+Wdj+S4h+eUqOihqCc7fVxyXG59LFxyXG5cclxuIFxyXG4gb25Mb2FkOmZ1bmN0aW9uKCl7Ry5kYW5nd2VpID09IDA7XHJcblx0IGNvbnNvbGUubG9nKFwic2FkNXNkXCIpO1xyXG5cdCB2YXIgcCA9dGhpcy5wbGF5ZXJyZWQuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0dmFyIHBwID0gY2MudjIoNDUuNCwtNDUuNSk7XHJcblx0XHQgICAgcC54ICs9IHBwLng7XHJcblx0XHRcdHAueSArPSBwcC55O1xyXG5cdFx0XHRcclxuXHRcdFx0Ry5oZWliaT0gY2MudjIocCk7XHJcblx0XHR2YXIgdyA9dGhpcy5wbGF5ZXJibGFjay5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHRcclxuXHRcdFx0dy55ID0gdy55KzY1LjI3O1xyXG5cdFx0XHRHLmhvbmdiaT13O1x0XHJcblx0dGhpcy5wbGF5ZXJyZWQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsIGZ1bmN0aW9uKHQpe2lmIChHLnhpYW5nbXU9PTEpe3RoaXMudGltZTEoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTIpe3RoaXMudGltZTIoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09Myl7dGhpcy50aW1lMygpfWVsc2UgaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0XHJcblx0dGhpcy5wbGF5ZXJibGFjay5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9TVEFSVCwgZnVuY3Rpb24odCl7aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuXHRpZiAoRy54aWFuZ211PT00KXt0aGlzLnRpbWU0KCl9ZWxzZSBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHRcclxuXHRjb25zb2xlLmxvZyhcInNjY2NkXCIpO1xyXG5cdHRoaXMucGxheWVycmVkLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwY2NwXCIpO1xyXG5cdFxyXG5cdFxyXG5cdHZhciB3ID10aGlzLnBsYXllcnJlZC5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHRcclxuXHRcdFx0dy55ID0gdy55KzY1LjI3O1xyXG5cdFx0XHRHLmhvbmdiaT13O1xyXG5cdFx0XHRcclxuXHRcdFx0dmFyIGRlbCA9IHQuZ2V0RGVsdGEoKTtcclxuXHRcdFx0dGhpcy5wbGF5ZXJyZWQueCArPSBkZWwueDtcclxuXHRcdFx0dGhpcy5wbGF5ZXJyZWQueSArPSBkZWwueTtcclxuXHRcclxuXHRcclxuXHRcclxuXHRcclxuXHRcclxuIHZhciBwID10aGlzLnBsYXllcmJsYWNrLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLCAwKSk7XHJcblx0XHRcdHZhciBwcCA9IGNjLnYyKDQ1LjQsLTQ1LjUpO1xyXG5cdFx0ICAgIHAueCArPSBwcC54O1xyXG5cdFx0XHRwLnkgKz0gcHAueTtcclxuXHRcdFx0XHJcblx0XHRcdEcuaGVpYmk9IGNjLnYyKHApO1xyXG5cdDtpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG5cdGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTUpe3RoaXMudGltZTUoKX19LHRoaXMpO1xyXG5cdGNvbnNvbGUubG9nKFwic2NjY2RcIik7XHJcblx0XHJcbiB0aGlzLnBsYXllcmJsYWNrLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwYzJjcFwiKTt2YXIgcCA9dGhpcy5wbGF5ZXJibGFjay5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHR2YXIgcHAgPSBjYy52Mig0NS40LC00NS41KTtcclxuXHRcdCAgICBwLnggKz0gcHAueDtcclxuXHRcdFx0cC55ICs9IHBwLnk7XHJcblx0XHRcdFxyXG5cdFx0XHRHLmhlaWJpPSBjYy52MihwKTtcclxuXHRcdCAgXHJcblx0XHRcdHZhciBkZWwgPSB0LmdldERlbHRhKCk7XHJcblx0XHRcdHRoaXMucGxheWVyYmxhY2sueCArPSBkZWwueDtcclxuXHRcdFx0dGhpcy5wbGF5ZXJibGFjay55ICs9IGRlbC55O1xyXG5cdFx0XHR2YXIgdyA9dGhpcy5wbGF5ZXJyZWQuY29udmVydFRvV29ybGRTcGFjZUFSKGNjLnYyKDAsIDApKTtcclxuXHRcdFx0XHJcblx0XHRcdHcueSA9IHcueSs2NS4yNztcclxuXHRcdFx0Ry5ob25nYmk9dztcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0dGhpcy5wbGF5ZXIyLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDVjY3BcIik7XHJcblx0aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcbiB0aGlzLnBsYXllcjIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDVjY3BcIik7ICBcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHR0aGlzLnBsYXllcjMub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfU1RBUlQsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwM2NjcFwiKTtcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuIHRoaXMucGxheWVyMy5vbihjYy5Ob2RlLkV2ZW50VHlwZS5UT1VDSF9FTkQsZnVuY3Rpb24odCl7Y29uc29sZS5sb2coXCJwM2NjcFwiKTtcclxuXHRpZiAoRy54aWFuZ211PT0xKXt0aGlzLnRpbWUxKCl9ZWxzZSBpZiAoRy54aWFuZ211PT0yKXt0aGlzLnRpbWUyKCl9ZWxzZSBcclxuXHRcclxuIGlmIChHLnhpYW5nbXU9PTMpe3RoaXMudGltZTMoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NCl7dGhpcy50aW1lNCgpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT01KXt0aGlzLnRpbWU1KCl9fSx0aGlzKTtcclxuXHR0aGlzLnBsYXllcjQub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfRU5ELGZ1bmN0aW9uKHQpe2NvbnNvbGUubG9nKFwicDJjY3BcIik7dGhpcy5wbGF5ZXI3LnJvdGF0aW9uIC09IDE4O1xyXG5cdCAgRy5kYW5nd2VpIC09MTtcclxuXHQgIGlmKEcuZGFuZ3dlaSA9PSAtMSl7Ry5kYW5nd2VpPTE5O307XHJcblx0aWYgKEcueGlhbmdtdT09MSl7dGhpcy50aW1lMSgpfWVsc2UgaWYgKEcueGlhbmdtdT09Mil7dGhpcy50aW1lMigpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT0zKXt0aGlzLnRpbWUzKCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTQpe3RoaXMudGltZTQoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09NSl7dGhpcy50aW1lNSgpfX0sdGhpcyk7XHJcblx0Y29uc29sZS5sb2coXCJzY2NjZFwiKTtcclxuXHRcclxuXHRjb25zb2xlLmxvZyhcInNjY2NkXCIpO1xyXG4gdGhpcy5wbGF5ZXI2Lm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX0VORCxmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcInBjYzVwXCIpOyB0aGlzLnBsYXllcjcucm90YXRpb24gKz0gMTg7XHJcblx0ICBHLmRhbmd3ZWkgKz0xO1xyXG5cdCAgaWYoRy5kYW5nd2VpID09IDIwKXtHLmRhbmd3ZWk9MDt9O1xyXG5cdGlmIChHLnhpYW5nbXU9PTEpe3RoaXMudGltZTEoKX1lbHNlIGlmIChHLnhpYW5nbXU9PTIpe3RoaXMudGltZTIoKX1lbHNlIFxyXG4gaWYgKEcueGlhbmdtdT09Myl7dGhpcy50aW1lMygpfWVsc2UgXHJcbiBpZiAoRy54aWFuZ211PT00KXt0aGlzLnRpbWU0KCl9ZWxzZSBcclxuIGlmIChHLnhpYW5nbXU9PTUpe3RoaXMudGltZTUoKX19LHRoaXMpO1xyXG4gXHJcblx0fSxcclxuICAgIHN0YXJ0ICgpIHtcclxuXHRcdFxyXG4gICAgfSxcclxuXHJcbiAgICAvLyB1cGRhdGUgKGR0KSB7fSxcclxufSk7XHJcbiJdfQ==