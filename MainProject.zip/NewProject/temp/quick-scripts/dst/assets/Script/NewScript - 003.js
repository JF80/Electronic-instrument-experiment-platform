
                (function() {
                    var nodeEnv = typeof require !== 'undefined' && typeof process !== 'undefined';
                    var __module = nodeEnv ? module : {exports:{}};
                    var __filename = 'preview-scripts/assets/Script/NewScript - 003.js';
                    var __require = nodeEnv ? function (request) {
                        return cc.require(request);
                    } : function (request) {
                        return __quick_compile_project__.require(request, __filename);
                    };
                    function __define (exports, require, module) {
                        if (!nodeEnv) {__quick_compile_project__.registerModule(__filename, module);}"use strict";
cc._RF.push(module, '335b8Zf3VZEo6BPG9iAFSw5', 'NewScript - 003');
// Script/NewScript - 003.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    }
  },
  ontm: function ontm(t) {
    var p = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
    var del = t.getDelta();
    this.node.x += del.x;
    this.node.y += del.y;
  },
  ontm2: function ontm2(t) {
    var p = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.node.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("1");
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.ontm, this);
    this.player.on(cc.Node.EventType.TOUCH_MOVE, this.ontm2, this);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();
                    }
                    if (nodeEnv) {
                        __define(__module.exports, __require, __module);
                    }
                    else {
                        __quick_compile_project__.registerModuleFunc(__filename, function () {
                            __define(__module.exports, __require, __module);
                        });
                    }
                })();
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImFzc2V0c1xcU2NyaXB0XFxOZXdTY3JpcHQgLSAwMDMuanMiXSwibmFtZXMiOlsiY2MiLCJDbGFzcyIsIkNvbXBvbmVudCIsInByb3BlcnRpZXMiLCJwbGF5ZXIiLCJ0eXBlIiwiTm9kZSIsIm9udG0iLCJ0IiwicCIsIm5vZGUiLCJjb252ZXJ0VG9Xb3JsZFNwYWNlQVIiLCJ2MiIsInBwIiwieCIsInkiLCJHIiwiaGVpYmkiLCJkZWwiLCJnZXREZWx0YSIsIm9udG0yIiwib25Mb2FkIiwib24iLCJFdmVudFR5cGUiLCJUT1VDSF9TVEFSVCIsImNvbnNvbGUiLCJsb2ciLCJUT1VDSF9NT1ZFIiwic3RhcnQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUFBLEVBQUUsQ0FBQ0MsS0FBSCxDQUFTO0FBQ0wsYUFBU0QsRUFBRSxDQUFDRSxTQURQO0FBR0xDLEVBQUFBLFVBQVUsRUFBRTtBQUNSO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNOQyxJQUFBQSxNQUFNLEVBQUU7QUFDRSxpQkFBUyxJQURYO0FBRUVDLE1BQUFBLElBQUksRUFBRUwsRUFBRSxDQUFDTTtBQUZYO0FBaEJNLEdBSFA7QUF5QlRDLEVBQUFBLElBQUksRUFBQyxjQUFTQyxDQUFULEVBQVc7QUFDYixRQUFJQyxDQUFDLEdBQUUsS0FBS0MsSUFBTCxDQUFVQyxxQkFBVixDQUFnQ1gsRUFBRSxDQUFDWSxFQUFILENBQU0sQ0FBTixFQUFTLENBQVQsQ0FBaEMsQ0FBUDtBQUNBLFFBQUlDLEVBQUUsR0FBR2IsRUFBRSxDQUFDWSxFQUFILENBQU0sSUFBTixFQUFXLENBQUMsSUFBWixDQUFUO0FBQ0dILElBQUFBLENBQUMsQ0FBQ0ssQ0FBRixJQUFPRCxFQUFFLENBQUNDLENBQVY7QUFDSEwsSUFBQUEsQ0FBQyxDQUFDTSxDQUFGLElBQU9GLEVBQUUsQ0FBQ0UsQ0FBVjtBQUVBQyxJQUFBQSxDQUFDLENBQUNDLEtBQUYsR0FBU2pCLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNSCxDQUFOLENBQVQ7QUFFQSxRQUFJUyxHQUFHLEdBQUdWLENBQUMsQ0FBQ1csUUFBRixFQUFWO0FBQ0EsU0FBS1QsSUFBTCxDQUFVSSxDQUFWLElBQWVJLEdBQUcsQ0FBQ0osQ0FBbkI7QUFDQSxTQUFLSixJQUFMLENBQVVLLENBQVYsSUFBZUcsR0FBRyxDQUFDSCxDQUFuQjtBQUNBLEdBcENNO0FBcUNUSyxFQUFBQSxLQUFLLEVBQUMsZUFBU1osQ0FBVCxFQUFXO0FBQ2QsUUFBSUMsQ0FBQyxHQUFFLEtBQUtDLElBQUwsQ0FBVUMscUJBQVYsQ0FBZ0NYLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLENBQU4sRUFBUyxDQUFULENBQWhDLENBQVA7QUFDQSxRQUFJQyxFQUFFLEdBQUdiLEVBQUUsQ0FBQ1ksRUFBSCxDQUFNLElBQU4sRUFBVyxDQUFDLElBQVosQ0FBVDtBQUNHSCxJQUFBQSxDQUFDLENBQUNLLENBQUYsSUFBT0QsRUFBRSxDQUFDQyxDQUFWO0FBQ0hMLElBQUFBLENBQUMsQ0FBQ00sQ0FBRixJQUFPRixFQUFFLENBQUNFLENBQVY7QUFFQUMsSUFBQUEsQ0FBQyxDQUFDQyxLQUFGLEdBQVNqQixFQUFFLENBQUNZLEVBQUgsQ0FBTUgsQ0FBTixDQUFUO0FBR0EsR0E5Q007QUErQ0w7QUFDSFksRUFBQUEsTUFBTSxFQUFDLGtCQUFVO0FBQ2xCLFNBQUtYLElBQUwsQ0FBVVksRUFBVixDQUFhdEIsRUFBRSxDQUFDTSxJQUFILENBQVFpQixTQUFSLENBQWtCQyxXQUEvQixFQUE0QyxVQUFTaEIsQ0FBVCxFQUFXO0FBQUNpQixNQUFBQSxPQUFPLENBQUNDLEdBQVIsQ0FBWSxHQUFaO0FBQWtCLEtBQTFFLEVBQTJFLElBQTNFO0FBQ0EsU0FBS2hCLElBQUwsQ0FBVVksRUFBVixDQUFhdEIsRUFBRSxDQUFDTSxJQUFILENBQVFpQixTQUFSLENBQWtCSSxVQUEvQixFQUEyQyxLQUFLcEIsSUFBaEQsRUFBcUQsSUFBckQ7QUFDQSxTQUFLSCxNQUFMLENBQVlrQixFQUFaLENBQWV0QixFQUFFLENBQUNNLElBQUgsQ0FBUWlCLFNBQVIsQ0FBa0JJLFVBQWpDLEVBQTZDLEtBQUtQLEtBQWxELEVBQXdELElBQXhEO0FBRUssR0FyREk7QUFzREw7QUFFQVEsRUFBQUEsS0F4REssbUJBd0RJLENBRVIsQ0ExREksQ0E0REw7O0FBNURLLENBQVQiLCJzb3VyY2VSb290IjoiLyIsInNvdXJjZXNDb250ZW50IjpbIi8vIExlYXJuIGNjLkNsYXNzOlxyXG4vLyAgLSBodHRwczovL2RvY3MuY29jb3MuY29tL2NyZWF0b3IvbWFudWFsL2VuL3NjcmlwdGluZy9jbGFzcy5odG1sXHJcbi8vIExlYXJuIEF0dHJpYnV0ZTpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvcmVmZXJlbmNlL2F0dHJpYnV0ZXMuaHRtbFxyXG4vLyBMZWFybiBsaWZlLWN5Y2xlIGNhbGxiYWNrczpcclxuLy8gIC0gaHR0cHM6Ly9kb2NzLmNvY29zLmNvbS9jcmVhdG9yL21hbnVhbC9lbi9zY3JpcHRpbmcvbGlmZS1jeWNsZS1jYWxsYmFja3MuaHRtbFxyXG5cclxuY2MuQ2xhc3Moe1xyXG4gICAgZXh0ZW5kczogY2MuQ29tcG9uZW50LFxyXG5cclxuICAgIHByb3BlcnRpZXM6IHtcclxuICAgICAgICAvLyBmb286IHtcclxuICAgICAgICAvLyAgICAgLy8gQVRUUklCVVRFUzpcclxuICAgICAgICAvLyAgICAgZGVmYXVsdDogbnVsbCwgICAgICAgIC8vIFRoZSBkZWZhdWx0IHZhbHVlIHdpbGwgYmUgdXNlZCBvbmx5IHdoZW4gdGhlIGNvbXBvbmVudCBhdHRhY2hpbmdcclxuICAgICAgICAvLyAgICAgICAgICAgICAgICAgICAgICAgICAgIC8vIHRvIGEgbm9kZSBmb3IgdGhlIGZpcnN0IHRpbWVcclxuICAgICAgICAvLyAgICAgdHlwZTogY2MuU3ByaXRlRnJhbWUsIC8vIG9wdGlvbmFsLCBkZWZhdWx0IGlzIHR5cGVvZiBkZWZhdWx0XHJcbiAgICAgICAgLy8gICAgIHNlcmlhbGl6YWJsZTogdHJ1ZSwgICAvLyBvcHRpb25hbCwgZGVmYXVsdCBpcyB0cnVlXHJcbiAgICAgICAgLy8gfSxcclxuICAgICAgICAvLyBiYXI6IHtcclxuICAgICAgICAvLyAgICAgZ2V0ICgpIHtcclxuICAgICAgICAvLyAgICAgICAgIHJldHVybiB0aGlzLl9iYXI7XHJcbiAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgLy8gICAgIHNldCAodmFsdWUpIHtcclxuICAgICAgICAvLyAgICAgICAgIHRoaXMuX2JhciA9IHZhbHVlO1xyXG4gICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgLy8gfSxcclxuXHRcdHBsYXllcjoge1xyXG4gICAgICAgICAgICBkZWZhdWx0OiBudWxsLFxyXG4gICAgICAgICAgICB0eXBlOiBjYy5Ob2RlXHJcbiAgICAgICAgfSxcclxuXHRcdFxyXG4gICAgfSxcclxub250bTpmdW5jdGlvbih0KXtcclxuXHRcdCB2YXIgcCA9dGhpcy5ub2RlLmNvbnZlcnRUb1dvcmxkU3BhY2VBUihjYy52MigwLCAwKSk7XHJcblx0XHRcdHZhciBwcCA9IGNjLnYyKDQ1LjQsLTQ1LjUpO1xyXG5cdFx0ICAgIHAueCArPSBwcC54O1xyXG5cdFx0XHRwLnkgKz0gcHAueTtcclxuXHRcdFx0XHJcblx0XHRcdEcuaGVpYmk9IGNjLnYyKHApO1xyXG5cdFx0ICBcclxuXHRcdFx0dmFyIGRlbCA9IHQuZ2V0RGVsdGEoKTtcclxuXHRcdFx0dGhpcy5ub2RlLnggKz0gZGVsLng7XHJcblx0XHRcdHRoaXMubm9kZS55ICs9IGRlbC55O1xyXG5cdFx0fSxcclxub250bTI6ZnVuY3Rpb24odCl7XHJcblx0XHQgdmFyIHAgPXRoaXMubm9kZS5jb252ZXJ0VG9Xb3JsZFNwYWNlQVIoY2MudjIoMCwgMCkpO1xyXG5cdFx0XHR2YXIgcHAgPSBjYy52Mig0NS40LC00NS41KTtcclxuXHRcdCAgICBwLnggKz0gcHAueDtcclxuXHRcdFx0cC55ICs9IHBwLnk7XHJcblx0XHRcdFxyXG5cdFx0XHRHLmhlaWJpPSBjYy52MihwKTtcclxuXHRcdCAgXHJcblx0XHRcdFxyXG5cdFx0fSxcdFxyXG4gICAgLy8gTElGRS1DWUNMRSBDQUxMQkFDS1M6XHJcbiBvbkxvYWQ6ZnVuY3Rpb24oKXtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX1NUQVJULCBmdW5jdGlvbih0KXtjb25zb2xlLmxvZyhcIjFcIik7fSx0aGlzKTtcclxudGhpcy5ub2RlLm9uKGNjLk5vZGUuRXZlbnRUeXBlLlRPVUNIX01PVkUsIHRoaXMub250bSx0aGlzKTtcclxudGhpcy5wbGF5ZXIub24oY2MuTm9kZS5FdmVudFR5cGUuVE9VQ0hfTU9WRSwgdGhpcy5vbnRtMix0aGlzKTtcclxuXHJcbiAgICB9LFxyXG4gICAgLy8gb25Mb2FkICgpIHt9LFxyXG5cclxuICAgIHN0YXJ0ICgpIHtcclxuXHJcbiAgICB9LFxyXG5cclxuICAgIC8vIHVwZGF0ZSAoZHQpIHt9LFxyXG59KTtcclxuIl19