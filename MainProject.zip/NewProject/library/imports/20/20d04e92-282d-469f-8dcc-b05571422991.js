"use strict";
cc._RF.push(module, '20d046SKC1Gn43MsFVxQimR', 'huaxian - 001');
// Script/huaxian - 001.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    mainCanvas: cc.Node,
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    },
    player3: {
      "default": null,
      type: cc.Node
    },
    player4: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
    this.player3.on(cc.Node.EventType.TOUCH_END, function (t) {
      this.fu1();
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      this.fu();
    }, this);
    this.player4.on(cc.Node.EventType.TOUCH_END, function (t) {
      this.fu2();
    }, this);
  },
  start: function start() {//console.log(tmpPath)
  },
  fu: function fu() {
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  },
  fu1: function fu1() {
    G.red = true;
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  },
  fu2: function fu2() {
    G.red = false;
    this.mainContext.clear();
    console.log('开始画线7');
    var a2p = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var b2p = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var a2px = a2p.x;
    var a2py = 169;

    if (G.red == true) {
      console.log("11");
      a2py = 169;
      console.log("11");
    } else if (G.red == false) {
      a2py = 132;
      console.log("11");
    }

    ;
    this.mainContext.moveTo(a2px, a2py);
    console.log('开始画线');
    console.log(b2p.x);
    var b2px = b2p.x - 26;
    var b2py = b2p.y - 63;
    this.mainContext.lineTo(b2px, b2py);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  } // update (dt) {},

});

cc._RF.pop();