"use strict";
cc._RF.push(module, '375d9gN9YZAZbZAwd7sVlSv', 'Label main');
// Script/Label main.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    playerred: {
      "default": null,
      type: cc.Node
    },
    playerblack: {
      "default": null,
      type: cc.Node
    },
    playerblack1: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    },
    player3: {
      "default": null,
      type: cc.Node
    },
    player4: {
      "default": null,
      type: cc.Node
    },
    player5: {
      "default": null,
      type: cc.AudioClip
    },
    player6: {
      "default": null,
      type: cc.Node
    },
    player7: {
      "default": null,
      type: cc.Node
    },
    tipp: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  time1: function time1() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '万用表关闭时选择关闭档或者电压最高档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;

    if (G.red == false) {
      console.log("s5sd");

      if (G.dangwei > 9 & G.dangwei < 15) {
        console.log("sadd545sd");
        var pu1 = cc.v2(629, 302);
        var pu2 = cc.v2(G.hongbi);
        var redtox = Math.abs(pu2.x - pu1.x);
        var redtoy = Math.abs(pu2.y - pu1.y);
        console.log("saddasd");
        console.log(pu2);

        if (redtox <= 50 & redtoy <= 50) {
          G.rtr = 1;
        }

        ;
        var py1 = cc.v2(629, 320);
        var py2 = cc.v2(G.heibi);
        var redtpx = Math.abs(py2.x - py1.x);
        var redtpy = Math.abs(py2.y - py1.y);
        console.log("saddasd");

        if (redtpx <= 50 & redtpy <= 50) {
          G.btr = 1;
        }

        ;
        var ps1 = cc.v2(858, 379);
        var ps2 = cc.v2(G.hongbi);
        var redtqx = Math.abs(ps2.x - ps1.x);
        var redtqy = Math.abs(ps2.y - ps1.y);
        console.log("saddasd");

        if (redtqx <= 50 & redtqy <= 50) {
          G.rtb = 1;
        }

        ;
        var pl1 = cc.v2(858, 379);
        var pl2 = cc.v2(G.heibi);
        var redtc = Math.abs(pl2.x - pl1.x);
        var redtg = Math.abs(pl2.y - pl1.y);
        console.log("saddasd");

        if (redtc <= 50 & redtg <= 50) {
          G.btb = 1;
        }

        ;
        console.log(G.rtr);
        console.log(G.btb);

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '50.00Ω';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '数字式万用表的红表笔接正极';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请调至电阻档';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '当前量程档位错误';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将红表笔调至电阻位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前红表笔档位错误';
    }
  },
  time2: function time2() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电流时要和负载串联\n万用表只能测量微小电流';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("99d");

    if (G.dangwei > 2 & G.dangwei < 7) {
      var pu1 = cc.v2(733, 301);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(733, 301);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(762, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 13 & redtpy <= 13) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(762, 303);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 13 & redtqy <= 13) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '25.30mA';
        } else if (G.rtb == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-25.30mA';
        }
      } else if (G.rtr == 1 & G.btb == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '0.025A';
      } else if (G.rtb == 1 & G.btr == 1) {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '-0.025A';
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请接触黑红表笔';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '数字式万用表的红表笔接正极';
      }
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请将调至直流电流档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '当前量程档位错误';
    }
  },
  time3: function time3() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    console.log("85475");

    if (G.dangwei > 16 & G.dangwei < 20) {
      console.log("sadd545sd");
      var pu1 = cc.v2(826, 303);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 30 & redtoy <= 30) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(826, 303);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btb = 1;
      }

      ;
      var py1 = cc.v2(766, 261);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 30 & redtpy <= 30) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(766, 261);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 30 & redtqy <= 30) {
        G.rtr = 1;
      }

      ;
      console.log("55");

      if (G.red == false) {
        console.log("sa55555");

        if (G.rtr == 1 & G.btb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '6.15V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '-6.15V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '请接触黑红表笔';
          this.myLabel = this.tipp.getComponent(cc.Label);
          this.myLabel.string = '将黑红表笔放置到加亮的标记处';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔调至电压位', this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei > 12) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '超量程', this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '低电压档测高电压可能会损坏万用表';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至直流电压位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量电压时使用错误档位会损坏万用表';
    }
  },
  time4: function time4() {
    this.myLabel = this.tipp.getComponent(cc.Label);
    this.myLabel.string = '警告：使用万用表测量较高电压时\n必须使用交流档';
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    G.rtg = 0;
    G.btg = 0;

    if (G.dangwei > 0 & G.dangwei < 2) {
      console.log("sadd545sd");
      var pu1 = cc.v2(740, 345);
      var pu2 = cc.v2(G.hongbi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log("saddasd");
      console.log(pu2);

      if (redtox <= 10 & redtoy <= 10) {
        G.rtg = 1;
      }

      ;
      var py1 = cc.v2(740, 345);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btg = 1;
      }

      ;
      var py1 = cc.v2(724, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btb = 1;
      }

      ;
      var ps1 = cc.v2(724, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtb = 1;
      }

      ;
      var py1 = cc.v2(759, 319);
      var py2 = cc.v2(G.heibi);
      var redtpx = Math.abs(py2.x - py1.x);
      var redtpy = Math.abs(py2.y - py1.y);
      console.log("saddasd");

      if (redtpx <= 10 & redtpy <= 10) {
        G.btr = 1;
      }

      ;
      var ps1 = cc.v2(759, 319);
      var ps2 = cc.v2(G.hongbi);
      var redtqx = Math.abs(ps2.x - ps1.x);
      var redtqy = Math.abs(ps2.y - ps1.y);
      console.log("saddasd");

      if (redtqx <= 10 & redtqy <= 10) {
        G.rtr = 1;
      }

      ;

      if (G.red == false) {
        if (G.btb == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btr == 1 & G.rtb == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.btg == 1 & G.rtr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else if (G.rtg == 1 & G.btr == 1) {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '~224.20V';
        } else {
          this.myLabel = this.node.getComponent(cc.Label);
          this.myLabel.string = '0V';
        }
      } else {
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '请将红表笔接至交流电压位';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '测量电压时红表笔选择电流档会损坏万用表';
      }
    } else if (G.dangwei == 2) {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '当前量程太小';
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '必须使用交流档位';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '测量高电压时使用错误档位会造成危险!\n当前万用表已自动断路';
    }
  },
  time5: function time5() {
    if (G.dangwei == 9) {
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '将红黑表笔短接以测量通路';
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '准备自检';
      console.log("sadd545sd");
      var pu1 = cc.v2(G.hongbi);
      var pu2 = cc.v2(G.heibi);
      var redtox = Math.abs(pu2.x - pu1.x);
      var redtoy = Math.abs(pu2.y - pu1.y);
      console.log(G.hongbi);
      console.log(G.heibi);

      if (redtox <= 10 & redtoy <= 10) {
        this.current = cc.audioEngine.play(this.player5, false, 1);
        ;
        this.myLabel = this.node.getComponent(cc.Label);
        this.myLabel.string = '通过';
        this.myLabel = this.tipp.getComponent(cc.Label);
        this.myLabel.string = '仅验证为通路';
      }

      ;
    } else {
      this.myLabel = this.node.getComponent(cc.Label);
      this.myLabel.string = '请调至自检档';
      this.myLabel = this.tipp.getComponent(cc.Label);
      this.myLabel.string = '错误档位红黑表笔短接可能会算坏万用表';
    }
  },
  onLoad: function onLoad() {
    G.dangwei == 0;
    console.log("sad5sd");
    var p = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
    var pp = cc.v2(45.4, -45.5);
    p.x += pp.x;
    p.y += pp.y;
    G.heibi = cc.v2(p);
    var w = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    this.playerred.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.playerblack.on(cc.Node.EventType.TOUCH_START, function (t) {
      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerred.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pccp");
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;
      var del = t.getDelta();
      this.playerred.x += del.x;
      this.playerred.y += del.y;
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    this.playerblack.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      console.log("pc2cp");
      var p = this.playerblack.convertToWorldSpaceAR(cc.v2(0, 0));
      var pp = cc.v2(45.4, -45.5);
      p.x += pp.x;
      p.y += pp.y;
      G.heibi = cc.v2(p);
      var del = t.getDelta();
      this.playerblack.x += del.x;
      this.playerblack.y += del.y;
      var w = this.playerred.convertToWorldSpaceAR(cc.v2(0, 0));
      w.y = w.y + 65.27;
      G.hongbi = w;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p5ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player3.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p3ccp");

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    this.player4.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("p2ccp");
      this.player7.rotation -= 18;
      G.dangwei -= 1;

      if (G.dangwei == -1) {
        G.dangwei = 19;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
    console.log("scccd");
    console.log("scccd");
    this.player6.on(cc.Node.EventType.TOUCH_END, function (t) {
      console.log("pcc5p");
      this.player7.rotation += 18;
      G.dangwei += 1;

      if (G.dangwei == 20) {
        G.dangwei = 0;
      }

      ;

      if (G.xiangmu == 1) {
        this.time1();
      } else if (G.xiangmu == 2) {
        this.time2();
      } else if (G.xiangmu == 3) {
        this.time3();
      } else if (G.xiangmu == 4) {
        this.time4();
      } else if (G.xiangmu == 5) {
        this.time5();
      }
    }, this);
  },
  start: function start() {} // update (dt) {},

});

cc._RF.pop();