"use strict";
cc._RF.push(module, '4ff717BZCpMQZb6oaFScaaP', 'huaxian');
// Script/huaxian.js

"use strict";

cc.Class({
  "extends": cc.Component,
  properties: {
    mainCanvas: cc.Node,
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {//var apx = 1;
    //console.log(tmpPath)
  },
  start: function start() {
    console.log("SASDA");
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
    this.player2.on(cc.Node.EventType.START, function (t) {
      this.fu();
    }, this);
    this.player2.on(cc.Node.EventType.TOUCH_MOVE, function (t) {
      this.fu();
    }, this);
  },
  fu: function fu() {
    this.mainContext = this.mainCanvas.getComponent(cc.Graphics);
    this.mainContext.clear();
    console.log('开始画线7');
    var ap = this.player.convertToWorldSpaceAR(cc.v2(0, 0));
    var bp = this.player2.convertToWorldSpaceAR(cc.v2(0, 0));
    console.log('开始画线8');
    var apx = ap.x;
    var apy = ap.y;
    this.mainContext.moveTo(apx, apy);
    console.log('开始画线');
    console.log(bp.x);
    var bpx = bp.x - 66;
    var bpy = bp.y + 45;
    this.mainContext.lineTo(bpx, bpy);
    console.log('开始画线2');
    new cc.Graphics().lineTo();
    this.mainContext.stroke();
  } // update (dt) {},

});

cc._RF.pop();