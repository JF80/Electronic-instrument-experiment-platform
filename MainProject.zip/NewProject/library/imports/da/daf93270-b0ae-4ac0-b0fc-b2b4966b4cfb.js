"use strict";
cc._RF.push(module, 'daf93JwsK5KwLD8srSWa0z7', 'tip');
// Script/tip.js

"use strict";

var _properties;

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
var Global = require("tip2");

cc.Class({
  "extends": cc.Component,
  Global: Global,
  properties: (_properties = {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    },
    player2: {
      "default": null,
      type: cc.Node
    }
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties["player2"] = {
    "default": null,
    type: cc.Node
  }, _properties),
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {},
  start: function start() {
    var tipObj = new Global();
    this.myLabel = this.node.getComponent(cc.Label);
    this.myLabel.string = G.xianshi;
    tipObj.ts();
  } // update (dt) {},

});

cc._RF.pop();