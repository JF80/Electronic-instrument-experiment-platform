"use strict";
cc._RF.push(module, '7d6c2wC1hBPsrSw5gT7LMCf', 'NewScript - 004');
// Script/NewScript - 004.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Node
    }
  },
  ontm: function ontm(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
    var del = t.getDelta();
    this.node.x += del.x;
    this.node.y += del.y;
  },
  ontm2: function ontm2(t) {
    var w = this.node.convertToWorldSpaceAR(cc.v2(0, 0));
    w.y = w.y + 65.27;
    G.hongbi = w;
  },
  // LIFE-CYCLE CALLBACKS:
  onLoad: function onLoad() {
    this.node.on(cc.Node.EventType.TOUCH_START, function (t) {
      console.log("1");
    }, this);
    this.node.on(cc.Node.EventType.TOUCH_MOVE, this.ontm, this);
    this.player.on(cc.Node.EventType.TOUCH_MOVE, this.ontm2, this);
  },
  // onLoad () {},
  start: function start() {} // update (dt) {},

});

cc._RF.pop();