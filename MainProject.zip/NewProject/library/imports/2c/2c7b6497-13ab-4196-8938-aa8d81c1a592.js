"use strict";
cc._RF.push(module, '2c7b6SXE6tBlok4qo2BwaWS', 'NewScript');
// Script/NewScript.js

"use strict";

// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html
cc.Class({
  "extends": cc.Component,
  properties: {
    // foo: {
    //     // ATTRIBUTES:
    //     default: null,        // The default value will be used only when the component attaching
    //                           // to a node for the first time
    //     type: cc.SpriteFrame, // optional, default is typeof default
    //     serializable: true,   // optional, default is true
    // },
    // bar: {
    //     get () {
    //         return this._bar;
    //     },
    //     set (value) {
    //         this._bar = value;
    //     }
    // },
    player: {
      "default": null,
      type: cc.Sprite
    },
    player2: {
      "default": null,
      type: cc.Sprite
    },
    player3: {
      "default": null,
      type: cc.Sprite
    },
    player4: {
      "default": null,
      type: cc.Sprite
    },
    player5: {
      "default": null,
      type: cc.Sprite
    },
    player6: {
      "default": null,
      type: cc.WebView
    },
    imgIdx: 1,
    sprArray: {
      "default": [],
      type: cc.Sprite
    }
  },
  // LIFE-CYCLE CALLBACKS:
  // onLoad () {},
  start: function start() {
    G.pt = 1;
  },
  tonew: function tonew() {
    if (G.pt == 1) {
      cc.director.loadScene("New Scene");
    } else {
      if (G.pt == 2) {
        cc.director.loadScene("os");
      }
    }

    ;
  },
  toch1: function toch1() {
    G.ch2 = false;
    G.ch1 = true;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  toch2: function toch2() {
    G.ch1 = false;
    G.ch2 = true;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tomode1: function tomode1() {
    G.mode = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tomode2: function tomode2() {
    G.mode = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo1: function tovo1() {
    G.VO = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo2: function tovo2() {
    G.VO = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tovo3: function tovo3() {
    G.VO = 3;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tosou1: function tosou1() {
    G.source = 1;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      console.log("dasdas");

      if (G.VO == 1) {
        console.log("dasdas");
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  slider: function slider() {},
  tosou2: function tosou2() {
    G.source = 2;

    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  newos: function newos() {
    if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
      if (G.VO == 1) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    } else {
      if (G.mode == 1 & G.source == 1 & G.ch1 == true) {
        this.player2.spriteFrame = this.sprArray[1].spriteFrame;
      } else if (G.VO == 2) {
        this.player2.spriteFrame = this.sprArray[2].spriteFrame;
      } else if (G.VO == 3) {
        this.player2.spriteFrame = this.sprArray[3].spriteFrame;
      }
    }

    ;
  },
  tologo: function tologo() {
    cc.director.loadScene("helloworld");
    G.red = true;
    G.xiangmu = 1;
    G.dangwei = 0;
    G.xianshi = 1;
    G.tip = 1;
    G.hongbi = null;
    G.heibi = null;
    G.hongbiyes = 0;
    G.heibiyes = 0;
    G.btr = 0;
    G.btb = 0;
    G.rtr = 0;
    G.rtb = 0;
    G.xls = 0;
    G.rtg = 0;
    G.btgV0;
    G.mode = 1;
    G.sourceV1;
    G.ch1 = true;
    G.ch2 = false;
    G.pp = 0;
    G.VO = 1;
    G.pt = 1;
  },
  tohelp: function tohelp() {
    cc.director.loadScene("help");
  },
  tomili: function tomili() {
    G.pt = 1;
  },
  toos: function toos() {
    G.pt = 2;
  },
  toweb1: function toweb1() {
    this.player6.Url = "https://www.bilibili.com/video/BV1Gx411z7x2?from=search&seid=14704342665083105122";
  },
  toweb2: function toweb2() {
    this.player6.Url = "https://www.bilibili.com/video/BV1Q4411f7QR?from=search&seid=10660677663550777909";
  },
  toweb3: function toweb3() {
    this.player6.Url = "https://www.bilibili.com/video/BV1uW411g76V?from=search&seid=10660677663550777909";
  },
  toro: function toro() {
    this.player.angel -= 18;
    G.dangwei -= 1;

    if (G.dangwei == -1) {
      G.dangwei = 19;
    }
  },
  tored1: function tored1() {
    G.red = true;
  },
  tored2: function tored2() {
    G.red = false;
    console.log("shi");
  },
  tox1: function tox1() {
    G.xiangmu = 1;
    this.player.spriteFrame = this.sprArray[0].spriteFrame;
  },
  tox2: function tox2() {
    G.xiangmu = 2;
    this.player.spriteFrame = this.sprArray[1].spriteFrame;
  },
  tox3: function tox3() {
    G.xiangmu = 3;
    this.player.spriteFrame = this.sprArray[2].spriteFrame;
  },
  tox4: function tox4() {
    G.xiangmu = 4;
    this.player.spriteFrame = this.sprArray[3].spriteFrame;
  },
  tox5: function tox5() {
    G.xiangmu = 5;
    this.player.spriteFrame = this.sprArray[4].spriteFrame;
  },
  toro2: function toro2() {
    this.player.angel += 18;
    G.dangwei += 1;

    if (G.dangwei == 20) {
      G.dangwei = 0;
    }
  },
  tohelp2: function tohelp2() {
    cc.director.loadScene("help-22");
  } // update (dt) {},
  // update (dt) {},

});

cc._RF.pop();