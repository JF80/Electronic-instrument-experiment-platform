var tp = cc.Class({
extends: cc.Component,

ts:function(){
   
if(G.tip = 1){  G.xianshi = '将黑红表笔放置到加亮的标记处'};
if(G.tip = 2){  G.xianshi = '数字式万用表的红表笔接正极';};
if(G.tip = 3){  G.xianshi = '当前量程过大';}
if(G.tip = 4){  G.xianshi = '当前量程过小';}
if(G.tip = 5){  G.xianshi = '通路';}
if(G.tip = 6){  G.xianshi = '当前量程档位错误';}
if(G.tip = 7){  G.xianshi = '万用表关闭时选择关闭档或者电压最高档';}
if(G.tip = 8){  G.xianshi = '测量高电压时使用错误档位会造成危险';}
if(G.tip = 9){  G.xianshi = '测量电压时红表笔选择电流档会损坏万用表';}
if(G.tip = 10){  G.xianshi = '当前红表笔档位错误';}
}


});

