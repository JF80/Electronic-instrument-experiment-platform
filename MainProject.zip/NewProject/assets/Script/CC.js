window.G = {

red : true,
xiangmu:1,
dangwei:0,
xianshi:1,
tip:1,
hongbi:null,
heibi:null,
hongbiyes:0,
heibiyes:0,
btr:0,
btb:0,
rtr:0,
rtb:0,
xls:0,
rtg:0,
btg:0,
mode:1,
source:1,
ch1:true,
ch2:false,


xianshi:'万用表关闭时选择关闭档或者电压最高档',
}