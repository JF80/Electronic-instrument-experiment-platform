// Learn cc.Class:
//  - https://docs.cocos.com/creator/manual/en/scripting/class.html
// Learn Attribute:
//  - https://docs.cocos.com/creator/manual/en/scripting/reference/attributes.html
// Learn life-cycle callbacks:
//  - https://docs.cocos.com/creator/manual/en/scripting/life-cycle-callbacks.html

cc.Class({
    extends: cc.Component,

	
	properties: {
        // foo: {
        //     // ATTRIBUTES:
        //     default: null,        // The default value will be used only when the component attaching
        //                           // to a node for the first time
        //     type: cc.SpriteFrame, // optional, default is typeof default
        //     serializable: true,   // optional, default is true
        // },
        // bar: {
        //     get () {
        //         return this._bar;
        //     },
        //     set (value) {
        //         this._bar = value;
        //     }
        // },
		
		player: {
            default: null,
            type: cc.Sprite,
        },
		player2: {
            default: null,
            type: cc.Sprite,
        },
			player3: {
            default: null,
            type: cc.Sprite,
        },
			player4: {
            default: null,
            type: cc.Sprite,
        },
			player5: {
            default: null,
            type: cc.Sprite,
        },
		player6: {
            default: null,
            type: cc.WebView,
        },
		 imgIdx : 1,
 sprArray :{
            default:[],
            type:cc.Sprite,
        },
		
    },

    // LIFE-CYCLE CALLBACKS:

    // onLoad () {},

    start () {
G.pt =1;
  },
   tonew: function () {
        if(G.pt==1){cc.director.loadScene("New Scene")}else{if(G.pt==2){cc.director.loadScene("os")}};
    },
	 toch1: function () {
        
		 G.ch2 = false;
		  G.ch1 = true;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
	 toch2: function () {
        
		 G.ch1 = false;
		  G.ch2 = true;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
	 tomode1: function () {
        
		 G.mode = 1;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
	 tomode2: function () {
        
		 G.mode = 2;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
		  
    }, 
	tovo1: function () {
        
		 G.VO = 1;
		    if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
		  
    },
	tovo2: function () {
        
		 G.VO = 2;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
		  
    },
	tovo3: function () {
        
		 G.VO = 3;
		    if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
	 tosou1: function () {
        
		 G.source = 1;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){console.log("dasdas");if(G.VO==1){console.log("dasdas");this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
	slider: function () {
       
	
    },
	 tosou2: function () {
        
		 G.source = 2;
		   if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
		  
    },
	newos: function () {
      if ( G.mode ==1 & G.source ==1 &G.ch1 ==true){if(G.VO==1){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}}else {if ( G.mode == 1 & G.source ==1 &G.ch1 == true){this.player2.spriteFrame = this.sprArray[1].spriteFrame}else if(G.VO==2)
	  {this.player2.spriteFrame = this.sprArray[2].spriteFrame}else if(G.VO==3)
	  {this.player2.spriteFrame = this.sprArray[3].spriteFrame}};
    },
tologo: function () {
        cc.director.loadScene("helloworld");
		G.red = true;
G.xiangmu=1;
G.dangwei=0;
G.xianshi=1;
G.tip=1;
G.hongbi=null;
G.heibi=null;
G.hongbiyes=0;
G.heibiyes=0;
G.btr=0;
G.btb=0;
G.rtr=0;
G.rtb=0;
G.xls=0;
G.rtg=0;
G.btgV0;
G.mode=1;
G.sourceV1;
G.ch1=true;
G.ch2=false;
G.pp=0;
G.VO=1;
G.pt=1;
    },
	tohelp: function () {
        cc.director.loadScene("help");
    },
	
	tomili: function () {
      G.pt=1;
    },
	toos: function () {
	G.pt=2;
        
    },
	toweb1: function () {
	this.player6.Url="https://www.bilibili.com/video/BV1Gx411z7x2?from=search&seid=14704342665083105122";
        
    },
	toweb2: function () {
	this.player6.Url="https://www.bilibili.com/video/BV1Q4411f7QR?from=search&seid=10660677663550777909";
        
    },
	toweb3: function () {
	this.player6.Url="https://www.bilibili.com/video/BV1uW411g76V?from=search&seid=10660677663550777909";
        
    },
     toro: function () {
	  this.player.angel -= 18;
	  G.dangwei -=1;
	  if(G.dangwei == -1){G.dangwei=19;}},
	 tored1: function () {
	  G.red = true;},
	  tored2: function () {
	  G.red = false;
	   console.log("shi");},
	  tox1: function (){
      G.xiangmu=1;
	  this.player.spriteFrame = this.sprArray[0].spriteFrame
    },
	  tox2: function (){
        G.xiangmu=2;  
	this.player.spriteFrame = this.sprArray[1].spriteFrame
    },
	  tox3: function (){
        G.xiangmu=3;
		this.player.spriteFrame = this.sprArray[2].spriteFrame
    },
	  tox4: function (){
       G.xiangmu=4;
	   this.player.spriteFrame = this.sprArray[3].spriteFrame
    },
	  tox5: function (){
        G.xiangmu=5;
		this.player.spriteFrame = this.sprArray[4].spriteFrame
    },
	  
 toro2: function () {
	  this.player.angel += 18;
	  G.dangwei +=1;
	  if(G.dangwei == 20){G.dangwei=0;}
	  },
	 
tohelp2: function () {
       cc.director.loadScene("help-22");
    },



	 
    // update (dt) {},
    // update (dt) {},
});
